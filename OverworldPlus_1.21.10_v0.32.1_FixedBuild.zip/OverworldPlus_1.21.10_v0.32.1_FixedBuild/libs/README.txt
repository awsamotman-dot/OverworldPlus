Place only compatible Minecraft 1.21.10 / Fabric / Java 21 dependency JARs here.
The current boss does not require an external model library.
