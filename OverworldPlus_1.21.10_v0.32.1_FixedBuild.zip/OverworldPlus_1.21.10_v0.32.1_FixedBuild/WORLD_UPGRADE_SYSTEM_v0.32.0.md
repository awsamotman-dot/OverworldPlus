# Overworld Plus v0.32.0 — World Enchanter Upgrade System

- 20 upgrade worlds.
- 100 direct upgrades per world = 2,000 total upgrade identities.
- No upgrade books.
- World Enchanter uses an Enchanting Table-style screen with 3 randomized choices.
- Each upgrade has levels I-X.
- XP cost increases with upgrade level and world tier.
- Later dimensions have stronger upgrade amplifiers.
- Upgrades are stored directly on items through the 1.21.x custom-data component.
- Held item, offhand item, and equipped armor are evaluated for upgrade effects.
- Upgrade choices avoid upgrades already stored on the held item.
- Refresh reshuffles the three choices.
- UI is English and uses the existing dark-fantasy Overworld Plus style.

## Dimension order
1. Ashen Abyss
2. Frostveil
3. Everdawn
4. Stormreach
5. Sunken Sands
6. Umbral Wilds
7. Crystal Abyss
8. Deadlands
9. Abyssal Ocean
10. Kingdom of Ruins
11. Astralis
12. Crimson Realm
13. Dragon Isles
14. Wildheart
15. Warforge
16. The Hollow
17. Ghostmoor
18. Eternal Sun
19. Moonfall
20. The Voidlands
