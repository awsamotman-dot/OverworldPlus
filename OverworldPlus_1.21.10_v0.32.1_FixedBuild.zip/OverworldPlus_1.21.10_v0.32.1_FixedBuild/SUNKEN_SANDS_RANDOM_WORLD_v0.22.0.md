# Sunken Sands v0.22.0 — Random World Generation

## Goal
Make Sunken Sands feel like a true Minecraft-style procedural world: the seed determines huge biome regions, cave networks, structures, ores, mobs, cities, dungeons, weather events, and boss sites.

## Biomes
- 20 biomes are selected by a seed-driven warped Voronoi field.
- Biome regions are intentionally large (~720 block cell scale) and are materially different between seeds.
- Domain warping prevents a simple grid look.

## Caves
- 1–4 deterministic cave networks per chunk.
- 9–21 chambers per network.
- Larger chambers and 3-block-radius tunnels.
- Rare mega chambers are 45×27×45-ish carving envelopes.
- Cave decoration and underground water vary by biome.

## Structures
- Structure families are selected from the seed hash instead of being locked to one family per biome.
- Extra rare structures can appear independently of the normal structure roll.
- Cities, landmarks, and dungeons keep independent low-frequency rolls.

## Determinism
Same seed + same coordinates = same world decisions. Different seeds materially change biome regions and content locations.
