# Stormreach v0.18.0 — Seed-Based Main Boss Randomization

- The 10 main bosses are no longer spawned by every generic dungeon.
- Each main boss receives a deterministic world-site coordinate derived from the Stormreach seed.
- Changing the seed changes the boss locations.
- Reusing the same seed reproduces the same boss locations.
- Boss sites are accepted only in suitable themed biomes.
- Each site builds the boss-specific arena and places a persistent dungeon-core marker to prevent respawning the same main boss site after reloads.
- Main bosses remain non-linear: no required kill order.
- Structure/biome mini-bosses remain independent and can still appear throughout the world.

Note: this is source/static implementation only; the environment does not provide the Gradle/Minecraft dependencies needed for a real Fabric build/runtime test.
