# Overworld Plus v0.30.0 — Souls-like Map System

- Dark-fantasy RPG menu styling.
- Explorer Map item opens a large map for the current dimension.
- Map ownership is persistent per dimension via `op_map_<dimension>` tags.
- Map fragments are persistent per dimension/256x256 region.
- Exploration automatically reveals regions once a map is owned.
- Cartographer's Table / Map Shop sells discovered dimension maps for 8 emeralds.
- Current map fragments can be purchased for 3 emeralds.
- Unrevealed regions remain hidden/fogged.
- Player marker is always shown.
- Terrain is sampled from the client world when the region is revealed.
- No map unlock is granted for undiscovered dimensions.
