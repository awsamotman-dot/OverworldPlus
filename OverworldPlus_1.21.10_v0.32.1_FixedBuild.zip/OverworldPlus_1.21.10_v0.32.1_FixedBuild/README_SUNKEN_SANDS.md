# Sunken Sands — World #5

A massive open-world desert civilization buried beneath sand, water and ruins.

See `SUNKEN_SANDS_v0.1_COMPLETE.md` for the full implementation matrix.


## v0.23.0 Creature Visual/Audio Pass
Custom 3D models, per-entity generated sound sets, animations and active skills are included. See SUNKEN_SANDS_CREATURE_3D_AUDIO_SKILLS_v0.23.0.md.
