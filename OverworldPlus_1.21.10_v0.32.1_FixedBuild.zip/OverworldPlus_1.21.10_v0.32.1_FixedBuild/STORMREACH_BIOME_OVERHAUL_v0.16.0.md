# Stormreach v0.16.0 — Biome Overhaul

Stormreach now has a dedicated content layer for all 20 biomes.

## Per-biome content
- 8 registered biome material blocks: bedrock/stone, soil, crystal, wood, leaves, brick, rune, moss.
- Seeded biome-specific terrain shaping remains active.
- Expanded cave chambers, tunnels, cave decoration, underground water for aquatic/marsh/coast biomes, and biome creature encounters.
- A unique city profile per biome with a plaza, 4 houses/buildings, paths/walls, rune centerpiece and NPCs.
- A unique landmark/structure profile per biome using the biome's own block palette.
- A unique 9-room dungeon profile per biome using the biome's own dungeon blocks, enemies and a biome-specific mini-boss.
- 20 biome-specific mini-boss entity types.
- Existing 20 biome creatures remain the regular fauna/monster family for their biome.

## Scale
- 20 biomes × 8 dedicated blocks = 160 new biome blocks.
- 20 biome cities.
- 20 biome landmarks.
- 20 biome dungeons.
- 20 biome mini-bosses.
- Expanded caves and deterministic seed-based placement.

## Validation
- JSON parse audit: 0 invalid JSON files.
- Java delimiter audit: 0 brace mismatches.
- Full Fabric/Gradle build is still not available in this environment, so runtime compilation/testing remains required in a real Minecraft 1.21.10 Fabric workspace.
