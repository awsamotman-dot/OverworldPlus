# Everdawn v0.10.0 — Merge Fixes

Implemented after the v0.9.0 Merge Audit.

## Fixed
1. Mini-bosses: every Everdawn creature kind now has an independent registered Mini-Boss EntityType with dedicated role, health, armor, phases and skill behavior.
2. Structure bosses: every Everdawn creature kind now has an independent registered Structure-Boss EntityType with higher stats, regeneration and phase behavior.
3. Settlements: the 20 settlements now use multiple deterministic layouts (radial, grid, crescent, river-side, terraced), perimeter walls, civic towers, market/farm areas and a local trader.
4. Stormreach gate: intentionally left untouched for the next focused pass, per project instruction.
5. Terrain: Everdawn terrain dressing now uses stronger biome-specific deterministic height/ridge profiles, valleys, highlands, terraces and water features instead of only upward filling.
6. Caves: the six cave themes now generate a connected network of chambers and tunnels, with themed stone/glow blocks and underground pools for suitable themes.
7. Dungeon system: each biome dungeon now has seven rooms, connected passages, branch layouts, dedicated treasure/lore rooms and a dedicated independent Structure Boss chamber. Main bosses are no longer spawned inside these structure dungeons.

## QA
- JSON parsing: 0 errors.
- Java delimiter/static syntax scan: passed.
- Duplicate legacy EverdawnWorldStructures generator disabled; EverdawnWorldSystems is the single population owner.
- Full Fabric compilation/runtime test could not be executed in this environment because Gradle/Minecraft/Fabric dependencies are not installed and network dependency resolution is unavailable.
