# Overworld Plus — Umbral Wilds v0.24.0

World #6: **Umbral Wilds**.

## Included
- 20 seed-driven large biome regions.
- Giant connected root/void cave networks with deep chambers.
- 12 structure families, cities, towers, temples, mines and abandoned kingdoms.
- 20 biome mini-bosses.
- 10 main bosses with phases, skills, custom attack/phase sounds and 3D models.
- 20 hostile wildlife/monsters with individual skills, movement animation, 3D models and unique sound sets.
- Shadow Exposure system with escalating Darkness/Mining Fatigue/Nausea/Slowness effects.
- Umbralite, Shadow Crystal, Bloodroot and Voidshard ores.
- Seven Abyssal Shards tied to the progression toward world #7.
- Rare **The Prismatic Deep** mega-dungeon containing the **Abyssal Crystal Gate**.
- Gate progression: collect seven shards → awaken Crystal Warden → defeat it → use the gate again → enter `overworldplus:crystal_abyss`.
- Crystal Abyss dimension JSON already exists in the project and is ready for world #7 content.

## Seven shards
- Wild Shard — Ancient Treant
- Wraith Shard — Wraith Queen
- Crystal Shard — Eclipse Beast
- Moon Shard — Moonless Guardian
- Blood Shard — Bloodwood Titan
- Shadow Shard — Heart of Darkness
- Crown Shard — Umbral Sovereign

## 3D/audio implementation
All Umbral creature and main-boss entity types have dedicated client model layers and dedicated texture paths. Main creatures and bosses have ambient/hurt/death/attack sounds; bosses additionally have phase sounds. Mini-bosses have dedicated attack audio.

The visual/audio assets in this development build are procedurally generated placeholder assets, not hand-authored AAA art or professionally recorded audio.

## Validation
- Java brace scan: PASS
- JSON parse scan: PASS
- Java source count: 26 Umbral classes
- Entity textures: 75
- Umbral OGG files: 262
- Build command was attempted, but this environment has no Gradle installation, so a real Minecraft/Fabric compilation could not be completed here.
