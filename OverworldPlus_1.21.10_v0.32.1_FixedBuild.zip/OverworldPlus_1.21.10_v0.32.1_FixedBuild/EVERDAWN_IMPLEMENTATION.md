# Everdawn v0.6.0 — Boss Pass

Implemented the approved Everdawn boss pass for Minecraft 1.21.10 / Fabric / Java 21.

## Main bosses
1. The Ancient Treant King
2. The Blossom Empress
3. The Mycelian Overlord
4. The Emerald Colossus
5. The Astral Druid
6. The Fey Queen
7. The Wildheart Beast
8. The Blight Sovereign
9. The Forgotten King
10. The Heart of Everdawn

## Included
- Independent boss entity registrations; no forced boss order.
- Three combat phases with phase transitions.
- Exposed weak-point windows and increased weak-point damage.
- Boss-specific skill rotations, status effects, movement attacks and minion summons.
- Distinct 3D model geometry variants and render scaling per boss.
- Distinct boss texture set.
- Unique sound events for ambient, hurt, death, phase, attack 1, attack 2 and music for every boss.
- Generated OGG audio assets for all 70 boss sound events.
- Boss weapon, relic, material and lore drops for every main boss.
- Four Everdawn armor pieces registered for every boss theme.
- Boss-specific block families for arenas.
- Deterministic, rare Everdawn boss arenas generated while exploring the Everdawn dimension.
- Arena generation spawns the corresponding boss, keeping encounters discoverable and non-linear.

## Quality note
The source now contains the complete gameplay/content foundation for this boss pass. The 3D meshes, textures and audio included in this pass are generated implementation assets, not the final hand-authored AAA art pass. A final art pass can replace the same asset IDs without changing the gameplay architecture.

## Build note
This environment has no Gradle wrapper JAR or cached Fabric/Minecraft dependencies and no outbound Maven access, so compilation was not claimed here. JSON/assets were validated locally.
