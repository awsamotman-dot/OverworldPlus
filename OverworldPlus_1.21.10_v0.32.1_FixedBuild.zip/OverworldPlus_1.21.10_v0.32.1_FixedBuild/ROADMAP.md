# Overworld Plus — full design

## 1. Biomes
1. Ancient Forest — giant trees, ruins, rare relics.
2. Redstone Highlands — red cliffs, abandoned mines.
3. Ash Valley — volcanic terrain, ash storms.
4. Crystal Caves — surface crystal fields and deep caverns.
5. Frozen Wastes — glaciers and ruined fortresses.
6. Sunken Marsh — flooded ruins and swamp dungeons.
7. Golden Desert — huge dunes, buried temples.
8. Windstep Plains — tall grass, giant stone formations.

## 2. Structures
- Ruined Watchtower
- Ancient Temple
- Lost Village
- Bandit Camp
- Giant Mine
- Sunken Shrine
- Warden Outpost
- Crystal Observatory
- Forgotten Castle
- Underground City

Structures are tiered by danger and distance from spawn.

## 3. Dungeons
Each dungeon has its own rooms, traps, keys, loot table and boss encounter.

### Ancient Temple
Puzzle rooms -> trap hall -> guardian chamber -> boss.

### Lost Castle
Courtyard -> barracks -> library -> throne room -> boss.

### Deep Mine
Mine tunnels -> cave arena -> collapsed shaft -> boss.

### Sunken Shrine
Flooded entrance -> underwater halls -> altar -> boss.

## 4. Equipment
Material tiers:
- Ancient
- Crimson
- Crystal
- Frost
- Ashen
- Royal

Each tier gets weapons, armor and relics. Full armor sets grant a set bonus.

## 5. Bosses
- The Ancient Guardian — temple boss; shield phases.
- The Red King — highlands boss; charges and terrain attacks.
- Ash Colossus — volcanic boss; creates lava hazards.
- Frost Matriarch — ice boss; summons frozen minions.
- The Drowned Saint — underwater boss; changes water flow.
- The Fallen King — late-game castle boss; multi-phase fight.

## 6. Progression
Spawn -> exploration -> first dungeon -> first relic -> biome tiers -> harder dungeons -> boss sets -> endgame ruins.

There is no forced linear quest line. Exploration unlocks stronger regions and equipment.

## 7. World-generation rule
World generation will be data-driven where possible. Structures, loot and recipes stay in data/resources; Java code handles registries, events and systems. This keeps the project easier to update and reduces API breakage.
