# Stormreach v0.14.0 — 20 Biome Terrain Profiles

Each Stormreach biome now has a dedicated terrain profile driven by the world seed, with different combinations of continental, macro, detail, ridge and canyon fields. The profile is deterministic per seed and chunk, and includes biome-specific terrain signatures such as mountain ridges, basins, canyons, valleys, coastlines, floating-island fields and storm-eye depressions.

This remains runtime terrain shaping over the configured Minecraft dimension noise settings; it is not a replacement custom DensityFunction/NoiseRouter implementation.
