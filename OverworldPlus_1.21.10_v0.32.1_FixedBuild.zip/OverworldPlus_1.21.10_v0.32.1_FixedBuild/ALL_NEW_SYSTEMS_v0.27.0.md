# Overworld Plus v0.27.0 — All New RPG Systems

This pass layers a living-RPG framework over all 20 dimensions.

## Added
- Six player builds: Warrior, Ranger, Mage, Blood Knight, Shadow, Storm.
- Four faction choices with persistent command-tag reputation state.
- Ancient Codex lore discovery system.
- World Beacon bases: nearby players receive regeneration/resistance.
- World discovery memory tags for every dimension.
- Periodic world events: storms, blood skies, dead rising, crystal blooms, dimensional rifts, settlement calls, eclipses and ancient energy surges.
- Event invasions can spawn dimension-native creatures.
- New Game+ toggle using Nightmare Core.
- Mythic Core boss loot.
- Ashen Abyss boss grants Class Sigil.
- Voidlands boss grants Nightmare Core.
- Boss victories increase faction reputation for the world.
- Expanded generated cities to 12 buildings plus roads, central core and named residents.
- Expanded dungeons to 10–16 randomized rooms with varied placement and connectors.
- Creature and animal generation now appears in small groups.
- Animal renderer registration fixed for the all-dimensions entity.

## Important
The systems are implemented as a data-light procedural framework so they can scale across all 20 dimensions without duplicating thousands of hand-authored classes. Minecraft's normal terrain/noise remains the base world generator; the mod layers its biome/structure/cave/entity/event systems above it.

Build/runtime was not executed in this environment because Gradle/Minecraft dependencies are unavailable locally.
