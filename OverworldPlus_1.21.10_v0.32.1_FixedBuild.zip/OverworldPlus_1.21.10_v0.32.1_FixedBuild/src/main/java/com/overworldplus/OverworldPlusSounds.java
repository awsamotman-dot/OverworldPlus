package com.overworldplus;

import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.Identifier;

import java.util.EnumMap;
import java.util.Map;

public final class OverworldPlusSounds {
    private static final Map<GuardianKind, SoundEvent> AMBIENT = new EnumMap<>(GuardianKind.class);
    private static final Map<GuardianKind, SoundEvent> HURT = new EnumMap<>(GuardianKind.class);
    private static final Map<GuardianKind, SoundEvent> DEATH = new EnumMap<>(GuardianKind.class);
    private static final Map<String, SoundEvent> ATTACKS = new java.util.HashMap<>();
    private static final Map<GuardianKind, SoundEvent> PHASE = new EnumMap<>(GuardianKind.class);
    private static final Map<GuardianKind, SoundEvent> WEAK = new EnumMap<>(GuardianKind.class);

    private OverworldPlusSounds() {}

    public static void register() {
        for (GuardianKind kind : GuardianKind.values()) {
            AMBIENT.put(kind, register(kind.id + ".ambient"));
            HURT.put(kind, register(kind.id + ".hurt"));
            DEATH.put(kind, register(kind.id + ".death"));
            PHASE.put(kind, register(kind.id + ".phase"));
            WEAK.put(kind, register(kind.id + ".weak"));
            for (int i = 1; i <= 4; i++) ATTACKS.put(kind.id + ".attack" + i, register(kind.id + ".attack" + i));
        }
    }

    public static SoundEvent ambient(GuardianKind k) { return AMBIENT.get(k); }
    public static SoundEvent hurt(GuardianKind k) { return HURT.get(k); }
    public static SoundEvent death(GuardianKind k) { return DEATH.get(k); }
    public static SoundEvent phase(GuardianKind k) { return PHASE.get(k); }
    public static SoundEvent weak(GuardianKind k) { return WEAK.get(k); }
    public static SoundEvent attack(GuardianKind k, int n) { return ATTACKS.get(k.id + ".attack" + n); }

    private static SoundEvent register(String path) {
        Identifier id = Identifier.of(OverworldPlus.MOD_ID, path);
        return Registry.register(Registries.SOUND_EVENT, id, SoundEvent.of(id));
    }
}
