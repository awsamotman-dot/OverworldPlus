package com.overworldplus;

import net.minecraft.item.Item;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

import java.util.EnumMap;
import java.util.Map;

public final class ModItems {
    public static final Map<GuardianKind, Item> EYES = new EnumMap<>(GuardianKind.class);
    public static final Map<GuardianKind, Item> FRAGMENTS = new EnumMap<>(GuardianKind.class);
    public static final Map<GuardianKind, Item> ARMOR_REWARDS = new EnumMap<>(GuardianKind.class);
    public static final Item SIXFOLD = register("sixfold", new Item(new Item.Settings().maxCount(1)));
    public static final Item ANCIENT_FRAGMENT = register("ancient_fragment", new Item(new Item.Settings()));
    public static final Item RUIN_KEY = register("ruin_key", new Item(new Item.Settings().maxCount(1)));

    static {
        for (GuardianKind kind : GuardianKind.values()) {
            EYES.put(kind, register(kind.eyeId, new Item(new Item.Settings().maxCount(1))));
            FRAGMENTS.put(kind, register(kind.id + "_blade_fragment", new Item(new Item.Settings().maxCount(16))));
            String armorId = switch (kind) {
                case VOLKARION -> "crown_of_magma";
                case UMBRAAZAR -> "shadowplate";
                case AEROLIX -> "stormgreaves";
                case VERDANTUS -> "verdant_boots";
                case SEKHMAR -> "emperors_gauntlets";
                case GLACIORIS -> "frost_core";
            };
            ARMOR_REWARDS.put(kind, register(armorId, new Item(new Item.Settings().maxCount(1))));
        }
    }

    private static Item register(String id, Item item) {
        return Registry.register(Registries.ITEM, Identifier.of(OverworldPlus.MOD_ID, id), item);
    }

    public static void register() {}
    private ModItems() {}
}
