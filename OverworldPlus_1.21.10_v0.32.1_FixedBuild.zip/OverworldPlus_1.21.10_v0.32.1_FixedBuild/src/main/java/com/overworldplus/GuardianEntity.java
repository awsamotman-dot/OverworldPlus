package com.overworldplus;

import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.goal.ActiveTargetGoal;
import net.minecraft.entity.ai.goal.LookAtEntityGoal;
import net.minecraft.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.entity.ai.goal.RevengeGoal;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.boss.ServerBossBar;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.text.Text;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

public class GuardianEntity extends HostileEntity {
    private final GuardianKind kind;
    private final ServerBossBar bossBar;
    private int phase;
    private int cooldown;
    private int vulnerability;
    private int attackAnimation;
    private int attackTimer;
    private int enrageTimer;

    public GuardianEntity(EntityType<? extends GuardianEntity> type, World world, GuardianKind kind) {
        super(type, world);
        this.kind = kind;
        this.experiencePoints = 250;
        this.setPersistent();
        this.bossBar = new ServerBossBar(Text.literal(kind.title), ServerBossBar.Color.RED, ServerBossBar.Style.NOTCHED_20);
    }

    public GuardianKind getKind() { return kind; }
    public int getPhase() { return phase; }
    public int getAttackAnimation() { return attackAnimation; }
    public float getAttackProgress(float tickDelta) { return MathHelper.clamp((attackTimer - tickDelta) / 18.0f, 0f, 1f); }
    public boolean isWeakPointOpen() { return vulnerability > 0; }

    public static DefaultAttributeContainer.Builder createAttributes() {
        return HostileEntity.createHostileAttributes()
                .add(EntityAttributes.MAX_HEALTH, 600.0)
                .add(EntityAttributes.ATTACK_DAMAGE, 22.0)
                .add(EntityAttributes.ARMOR, 18.0)
                .add(EntityAttributes.ARMOR_TOUGHNESS, 10.0)
                .add(EntityAttributes.KNOCKBACK_RESISTANCE, 1.0)
                .add(EntityAttributes.MOVEMENT_SPEED, 0.24)
                .add(EntityAttributes.FOLLOW_RANGE, 64.0);
    }

    @Override
    protected void initGoals() {
        goalSelector.add(2, new MeleeAttackGoal(this, 1.0, false));
        goalSelector.add(8, new LookAtEntityGoal(this, PlayerEntity.class, 28f));
        targetSelector.add(1, new RevengeGoal(this));
        targetSelector.add(2, new ActiveTargetGoal<>(this, PlayerEntity.class, true));
    }

    @Override
    protected void mobTick() {
        super.mobTick();
        if (getWorld().isClient) return;
        if (cooldown > 0) cooldown--;
        if (vulnerability > 0) vulnerability--;
        if (attackTimer > 0) attackTimer--;
        if (enrageTimer > 0) enrageTimer--;
        updatePhase();
        bossBar.setPercent(Math.max(0f, getHealth() / getMaxHealth()));

        LivingEntity target = getTarget();
        if (target == null || !target.isAlive()) return;
        if (cooldown <= 0) chooseAttack(target);
    }

    private void updatePhase() {
        float ratio = getHealth() / getMaxHealth();
        int next = ratio <= .25f ? 2 : ratio <= .60f ? 1 : 0;
        if (next != phase) {
            phase = next;
            enrageTimer = 60;
            if (getWorld() instanceof ServerWorld sw) {
                sw.playSound(null, getBlockPos(), OverworldPlusSounds.phase(kind), SoundCategory.HOSTILE, 4f, .7f + phase * .15f);
                sw.getPlayers().stream().filter(p -> p.squaredDistanceTo(this) < 56 * 56)
                        .forEach(p -> p.sendMessage(Text.literal("§6" + kind.title.toUpperCase() + " — PHASE " + (phase + 1)), true));
            }
        }
    }

    private void chooseAttack(LivingEntity target) {
        double d = distanceTo(target);
        if (phase == 0) {
            if (d > 7) leap(target); else heavyAttack(target);
        } else if (phase == 1) {
            int roll = random.nextInt(3);
            if (roll == 0) specialAttack(target); else if (roll == 1) leap(target); else heavyAttack(target);
        } else {
            int roll = random.nextInt(4);
            if (roll == 0) specialAttack(target); else if (roll == 1) executeAttack(target); else if (d > 7) leap(target); else heavyAttack(target);
        }
    }

    private void beginAttack(int animation, int ticks) {
        attackAnimation = animation;
        attackTimer = ticks;
        vulnerability = 12;
    }

    private void heavyAttack(LivingEntity target) {
        beginAttack(1, 18);
        playSound(OverworldPlusSounds.attack(kind, 1), 3f, .75f);
        float radius = phase == 2 ? 7.0f : 5.0f;
        float damage = phase == 2 ? 18f : 13f;
        for (LivingEntity e : getWorld().getEntitiesByClass(LivingEntity.class, getBoundingBox().expand(radius), x -> x != this && x.isAlive())) {
            if (e.squaredDistanceTo(this) <= radius * radius) {
                e.damage(getDamageSources().mobAttack(this), damage);
                e.takeKnockback(1.3, getX() - e.getX(), getZ() - e.getZ());
            }
        }
        cooldown = phase == 2 ? 26 : 40;
    }

    private void leap(LivingEntity target) {
        beginAttack(2, 18);
        Vec3d dir = target.getPos().subtract(getPos());
        double len = Math.max(.1, Math.sqrt(dir.x * dir.x + dir.z * dir.z));
        setVelocity(dir.x / len * 1.35, .8, dir.z / len * 1.35);
        velocityDirty = true;
        playSound(OverworldPlusSounds.attack(kind, 2), 3f, .9f);
        cooldown = 52;
    }

    private void specialAttack(LivingEntity target) {
        beginAttack(3, 18);
        playSound(OverworldPlusSounds.attack(kind, 3), 3.5f, .7f);
        float radius = phase == 2 ? 14f : 10f;
        for (LivingEntity e : getWorld().getEntitiesByClass(LivingEntity.class, getBoundingBox().expand(radius), x -> x != this && x.isAlive())) {
            if (e.squaredDistanceTo(this) <= radius * radius) e.damage(getDamageSources().mobAttack(this), phase == 2 ? 16f : 9f);
        }
        cooldown = phase == 2 ? 55 : 68;
    }

    private void executeAttack(LivingEntity target) {
        beginAttack(4, 22);
        playSound(OverworldPlusSounds.attack(kind, 4), 4f, .65f);
        if (target.squaredDistanceTo(this) < 18 * 18) target.damage(getDamageSources().mobAttack(this), 24f);
        cooldown = 86;
    }

    @Override
    protected void dropLoot(ServerWorld world, DamageSource source) {
        if (!(source.getAttacker() instanceof PlayerEntity)) return;
        dropStack(new ItemStack(ModItems.EYES.get(kind)));
        dropStack(new ItemStack(ModItems.ARMOR_REWARDS.get(kind)));
        if (random.nextFloat() < 0.35f) dropStack(new ItemStack(ModItems.FRAGMENTS.get(kind), 1 + random.nextInt(2)));
    }

    @Override
    public boolean damage(DamageSource source, float amount) {
        if (enrageTimer > 0) return false;
        if (source.getAttacker() instanceof PlayerEntity player) {
            if (isWeakPointOpen() && isPlayerAimingAtWeakPoint(player)) {
                amount *= 2.8f;
                vulnerability = 0;
                if (getWorld() instanceof ServerWorld sw) sw.playSound(null, getBlockPos(), OverworldPlusSounds.weak(kind), SoundCategory.HOSTILE, 4f, 1f);
            } else if (isWeakPointOpen()) {
                amount *= .05f;
            }
        }
        amount = Math.min(amount, 35f);
        return super.damage(source, amount);
    }

    private boolean isPlayerAimingAtWeakPoint(PlayerEntity player) {
        Vec3d eye = player.getEyePos();
        Vec3d point = getPos().add(weakPointOffset());
        Vec3d toPoint = point.subtract(eye);
        double length = toPoint.length();
        if (length < .01) return true;
        Vec3d look = player.getRotationVec(1f).normalize();
        Vec3d unit = toPoint.multiply(1.0 / length);
        double alignment = look.dotProduct(unit);
        return alignment > .985 && eye.distanceTo(point) < 12.0;
    }

    public Vec3d weakPointOffset() {
        return switch (kind) {
            case VOLKARION -> new Vec3d(0, 2.4, -1.0);
            case UMBRAAZAR -> new Vec3d(0, 3.2, -0.9);
            case AEROLIX -> new Vec3d(0, 2.6, -1.1);
            case VERDANTUS -> new Vec3d(0, 2.0, -1.0);
            case SEKHMAR -> new Vec3d(0, 3.5, -1.0);
            case GLACIORIS -> new Vec3d(0, 2.2, -1.2);
        };
    }

    @Override
    public void onStartedTrackingBy(ServerPlayerEntity player) { super.onStartedTrackingBy(player); bossBar.addPlayer(player); }
    @Override
    public void onStoppedTrackingBy(ServerPlayerEntity player) { super.onStoppedTrackingBy(player); bossBar.removePlayer(player); }
    @Override
    public void remove(RemovalReason reason) { bossBar.clearPlayers(); super.remove(reason); }

    @Override protected SoundEvent getAmbientSound() { return OverworldPlusSounds.ambient(kind); }
    @Override protected SoundEvent getHurtSound(DamageSource source) { return OverworldPlusSounds.hurt(kind); }
    @Override protected SoundEvent getDeathSound() { return OverworldPlusSounds.death(kind); }
    @Override protected float getSoundVolume() { return 2.2f; }
}
