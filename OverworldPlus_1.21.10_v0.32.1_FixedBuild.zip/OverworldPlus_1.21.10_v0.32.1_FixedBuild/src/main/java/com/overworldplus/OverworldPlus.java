package com.overworldplus;

import com.overworldplus.ashen.*;
import com.overworldplus.frostveil.*;
import com.overworldplus.everdawn.*;
import com.overworldplus.stormreach.*;
import com.overworldplus.sunkensands.*;
import com.overworldplus.umbral.*;
import com.overworldplus.expansion.*;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.util.Identifier;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.world.World;
import net.minecraft.network.packet.s2c.play.PositionFlag;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import static net.minecraft.server.command.CommandManager.argument;
import static net.minecraft.server.command.CommandManager.literal;

import java.util.EnumMap;
import java.util.Map;

public final class OverworldPlus implements ModInitializer {
    public static final String MOD_ID = "overworldplus";
    public static final Map<GuardianKind, EntityType<GuardianEntity>> GUARDIANS = new EnumMap<>(GuardianKind.class);
    public static final Map<AshenBossKind, EntityType<AshenBossEntity>> ASHEN_BOSSES = new EnumMap<>(AshenBossKind.class);
    public static final Map<FrostveilBossKind, EntityType<FrostveilBossEntity>> FROSTVEIL_BOSSES = new EnumMap<>(FrostveilBossKind.class);
    public static EntityType<FrostveilMinionEntity> FROSTVEIL_MINION;
    public static final Map<EverdawnBossKind, EntityType<EverdawnBossEntity>> EVERDAWN_BOSSES = new EnumMap<>(EverdawnBossKind.class);
    public static EntityType<EverdawnMinionEntity> EVERDAWN_MINION;
    public static EntityType<EverdawnCreatureEntity> EVERDAWN_CREATURE;
    public static EntityType<EverdawnCreatureEntity> EVERDAWN_ELITE;
    public static EntityType<EverdawnTraderEntity> EVERDAWN_TRADER;
    public static final Map<StormreachCreatureKind, EntityType<StormreachCreatureEntity>> STORMREACH_CREATURES = new EnumMap<>(StormreachCreatureKind.class);
    public static final Map<StormreachBossKind, EntityType<StormreachBossEntity>> STORMREACH_BOSSES = new EnumMap<>(StormreachBossKind.class);
    public static net.minecraft.block.Block STORMREACH_GATE;
    public static net.minecraft.item.Item STORMREACH_GATE_ITEM;
    public static EntityType<StormreachNPCEntity> STORMREACH_NPC;
    public static final Map<StormreachStructureKind, EntityType<StormreachStructureMobEntity>> STORMREACH_STRUCTURE_MOBS = new EnumMap<>(StormreachStructureKind.class);
    public static final Map<StormreachStructureKind, EntityType<StormreachStructureMiniBossEntity>> STORMREACH_STRUCTURE_MINI_BOSSES = new EnumMap<>(StormreachStructureKind.class);
    public static final Map<StormreachBiomeMiniBossKind, EntityType<StormreachBiomeMiniBossEntity>> STORMREACH_BIOME_MINI_BOSSES = new EnumMap<>(StormreachBiomeMiniBossKind.class);
    public static final Map<SunkenSandsCreatureKind, EntityType<SunkenSandsCreatureEntity>> SUNKEN_SANDS_CREATURES = new EnumMap<>(SunkenSandsCreatureKind.class);
    public static final Map<SunkenSandsBossKind, EntityType<SunkenSandsBossEntity>> SUNKEN_SANDS_BOSSES = new EnumMap<>(SunkenSandsBossKind.class);
    public static net.minecraft.block.Block SUNKEN_SANDS_GATE;
    public static net.minecraft.item.Item SUNKEN_SANDS_GATE_ITEM;
    public static EntityType<SunkenSandsNPCEntity> SUNKEN_SANDS_NPC;
    public static final Map<SunkenSandsStructureKind, EntityType<SunkenSandsStructureMobEntity>> SUNKEN_SANDS_STRUCTURE_MOBS = new EnumMap<>(SunkenSandsStructureKind.class);
    public static final Map<SunkenSandsStructureKind, EntityType<SunkenSandsStructureMiniBossEntity>> SUNKEN_SANDS_STRUCTURE_MINI_BOSSES = new EnumMap<>(SunkenSandsStructureKind.class);
    public static final Map<SunkenSandsBiomeMiniBossKind, EntityType<SunkenSandsBiomeMiniBossEntity>> SUNKEN_SANDS_BIOME_MINI_BOSSES = new EnumMap<>(SunkenSandsBiomeMiniBossKind.class);
    public static final Map<UmbralCreatureKind, EntityType<UmbralCreatureEntity>> UMBRAL_CREATURES = new EnumMap<>(UmbralCreatureKind.class);
    public static final Map<UmbralBossKind, EntityType<UmbralBossEntity>> UMBRAL_BOSSES = new EnumMap<>(UmbralBossKind.class);
    public static final Map<UmbralMiniBossKind, EntityType<UmbralMiniBossEntity>> UMBRAL_MINI_BOSSES = new EnumMap<>(UmbralMiniBossKind.class);
    public static final Map<UmbralStructureBossKind, EntityType<UmbralStructureBossEntity>> UMBRAL_STRUCTURE_BOSSES = new EnumMap<>(UmbralStructureBossKind.class);
    public static final Map<UmbralStructureKind, EntityType<UmbralStructureMobEntity>> UMBRAL_STRUCTURE_MOBS = new EnumMap<>(UmbralStructureKind.class);
    public static EntityType<CrystalWardenEntity> CRYSTAL_WARDEN;
    public static net.minecraft.block.Block ABYSSAL_CRYSTAL_GATE;
    public static net.minecraft.item.Item ABYSSAL_CRYSTAL_GATE_ITEM;
    public static EntityType<ExpansionCreatureEntity> EXPANSION_CREATURE;
    public static EntityType<ExpansionBossEntity> EXPANSION_BOSS;
    public static EntityType<ExpansionAnimalEntity> EXPANSION_ANIMAL;
    public static final Map<EverdawnCreatureKind, EntityType<EverdawnEncounterEntity>> EVERDAWN_MINI_BOSSES = new EnumMap<>(EverdawnCreatureKind.class);
    public static final Map<EverdawnCreatureKind, EntityType<EverdawnEncounterEntity>> EVERDAWN_STRUCTURE_BOSSES = new EnumMap<>(EverdawnCreatureKind.class);
    public static final net.minecraft.block.Block ANCIENT_GATE = Registry.register(Registries.BLOCK, Identifier.of(MOD_ID, "ancient_gate"), new AncientGateBlock());
    public static final net.minecraft.item.Item ANCIENT_GATE_ITEM = Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "ancient_gate"), new net.minecraft.item.BlockItem(ANCIENT_GATE, new net.minecraft.item.Item.Settings()));
    public static final net.minecraft.block.Block ASHEN_WORLD_GATE = Registry.register(Registries.BLOCK, Identifier.of(MOD_ID, "ashen_world_gate"), new AshenWorldGateBlock());
    public static final net.minecraft.item.Item ASHEN_WORLD_GATE_ITEM = Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "ashen_world_gate"), new net.minecraft.item.BlockItem(ASHEN_WORLD_GATE, new net.minecraft.item.Item.Settings()));

    static {
        for (GuardianKind kind : GuardianKind.values()) {
            Identifier id = Identifier.of(MOD_ID, kind.id);
            EntityType<GuardianEntity> type = Registry.register(Registries.ENTITY_TYPE, id,
                    EntityType.Builder.create((entityType, world) -> new GuardianEntity(entityType, world, kind), SpawnGroup.MONSTER)
                            .dimensions(3.8f, 6.2f).maxTrackingRange(128).trackingTickInterval(1)
                            .build(RegistryKey.of(RegistryKeys.ENTITY_TYPE, id)));
            GUARDIANS.put(kind, type);
        }
        for (AshenBossKind kind : AshenBossKind.values()) {
            Identifier id = Identifier.of(MOD_ID, kind.id);
            EntityType<AshenBossEntity> type = Registry.register(Registries.ENTITY_TYPE, id,
                    EntityType.Builder.create((entityType, world) -> new AshenBossEntity(entityType, world, kind), SpawnGroup.MONSTER)
                            .dimensions(kind == AshenBossKind.INFERNAL_SERPENT ? 2.4f : 3.4f, kind == AshenBossKind.INFERNAL_SERPENT ? 2.2f : 5.6f)
                            .maxTrackingRange(128).trackingTickInterval(1)
                            .build(RegistryKey.of(RegistryKeys.ENTITY_TYPE, id)));
            ASHEN_BOSSES.put(kind, type);
        }
        for (FrostveilBossKind kind : FrostveilBossKind.values()) {
            Identifier id = Identifier.of(MOD_ID, "frostveil_" + kind.id);
            EntityType<FrostveilBossEntity> type = Registry.register(Registries.ENTITY_TYPE, id,
                    EntityType.Builder.create((entityType, world) -> new FrostveilBossEntity(entityType, world, kind), SpawnGroup.MONSTER)
                            .dimensions(kind == FrostveilBossKind.ABYSSAL_LEVIATHAN ? 5.5f : 3.8f, kind == FrostveilBossKind.GLACIER_TITAN ? 7.0f : 5.8f)
                            .maxTrackingRange(160).trackingTickInterval(1)
                            .build(RegistryKey.of(RegistryKeys.ENTITY_TYPE, id)));
            FROSTVEIL_BOSSES.put(kind, type);
        }
        FROSTVEIL_MINION = Registry.register(Registries.ENTITY_TYPE, Identifier.of(MOD_ID, "frostveil_minion"),
                EntityType.Builder.create(FrostveilMinionEntity::new, SpawnGroup.MONSTER).dimensions(0.7f,1.4f).maxTrackingRange(64).build(RegistryKey.of(RegistryKeys.ENTITY_TYPE, Identifier.of(MOD_ID,"frostveil_minion"))));
        for (EverdawnBossKind kind : EverdawnBossKind.values()) {
            Identifier id = Identifier.of(MOD_ID, "everdawn_" + kind.id);
            EntityType<EverdawnBossEntity> type = Registry.register(Registries.ENTITY_TYPE, id,
                    EntityType.Builder.create((entityType, world) -> new EverdawnBossEntity(entityType, world, kind), SpawnGroup.MONSTER)
                            .dimensions(kind == EverdawnBossKind.EMERALD_COLOSSUS ? 5.5f : 3.8f, kind == EverdawnBossKind.EMERALD_COLOSSUS ? 8.0f : 6.2f)
                            .maxTrackingRange(180).trackingTickInterval(1)
                            .build(RegistryKey.of(RegistryKeys.ENTITY_TYPE, id)));
            EVERDAWN_BOSSES.put(kind, type);
        }
        EVERDAWN_MINION = Registry.register(Registries.ENTITY_TYPE, Identifier.of(MOD_ID, "everdawn_minion"),
                EntityType.Builder.create(EverdawnMinionEntity::new, SpawnGroup.MONSTER).dimensions(0.8f,1.5f).maxTrackingRange(72).build(RegistryKey.of(RegistryKeys.ENTITY_TYPE, Identifier.of(MOD_ID,"everdawn_minion"))));
        Identifier creatureId=Identifier.of(MOD_ID,"everdawn_creature");
        EVERDAWN_CREATURE=Registry.register(Registries.ENTITY_TYPE,creatureId,EntityType.Builder.create((type,world)->new EverdawnCreatureEntity(type,world,EverdawnCreatureKind.MEADOW_STAG,false),SpawnGroup.MONSTER).dimensions(.8f,1.8f).maxTrackingRange(64).trackingTickInterval(2).build(RegistryKey.of(RegistryKeys.ENTITY_TYPE,creatureId)));
        Identifier eliteId=Identifier.of(MOD_ID,"everdawn_elite");
        EVERDAWN_ELITE=Registry.register(Registries.ENTITY_TYPE,eliteId,EntityType.Builder.create((type,world)->new EverdawnCreatureEntity(type,world,EverdawnCreatureKind.MEADOW_STAG,true),SpawnGroup.MONSTER).dimensions(1.2f,2.6f).maxTrackingRange(96).trackingTickInterval(1).build(RegistryKey.of(RegistryKeys.ENTITY_TYPE,eliteId)));
        for (EverdawnCreatureKind kind : EverdawnCreatureKind.values()) {
            Identifier miniId = Identifier.of(MOD_ID, "everdawn_mini_" + kind.id);
            EntityType<EverdawnEncounterEntity> mini = Registry.register(Registries.ENTITY_TYPE, miniId,
                    EntityType.Builder.create((type, world) -> new EverdawnEncounterEntity(type, world, kind, EverdawnEncounterRole.MINI_BOSS), SpawnGroup.MONSTER)
                            .dimensions(1.2f, 2.8f).maxTrackingRange(96).trackingTickInterval(1)
                            .build(RegistryKey.of(RegistryKeys.ENTITY_TYPE, miniId)));
            EVERDAWN_MINI_BOSSES.put(kind, mini);
            Identifier bossId = Identifier.of(MOD_ID, "everdawn_structure_boss_" + kind.id);
            EntityType<EverdawnEncounterEntity> boss = Registry.register(Registries.ENTITY_TYPE, bossId,
                    EntityType.Builder.create((type, world) -> new EverdawnEncounterEntity(type, world, kind, EverdawnEncounterRole.STRUCTURE_BOSS), SpawnGroup.MONSTER)
                            .dimensions(1.6f, 3.4f).maxTrackingRange(112).trackingTickInterval(1)
                            .build(RegistryKey.of(RegistryKeys.ENTITY_TYPE, bossId)));
            EVERDAWN_STRUCTURE_BOSSES.put(kind, boss);
        }
        for (StormreachCreatureKind kind : StormreachCreatureKind.values()) {
            Identifier id = Identifier.of(MOD_ID, "stormreach_" + kind.id);
            EntityType<StormreachCreatureEntity> type = Registry.register(Registries.ENTITY_TYPE, id,
                    EntityType.Builder.create((entityType, world) -> new StormreachCreatureEntity(entityType, world, kind), SpawnGroup.MONSTER)
                            .dimensions(0.9f, 1.8f).maxTrackingRange(80).trackingTickInterval(2)
                            .build(RegistryKey.of(RegistryKeys.ENTITY_TYPE, id)));
            STORMREACH_CREATURES.put(kind, type);
        }
        for (StormreachBossKind kind : StormreachBossKind.values()) {
            Identifier id = Identifier.of(MOD_ID, "stormreach_boss_" + kind.id);
            EntityType<StormreachBossEntity> type = Registry.register(Registries.ENTITY_TYPE, id,
                    EntityType.Builder.create((entityType, world) -> new StormreachBossEntity(entityType, world, kind), SpawnGroup.MONSTER)
                            .dimensions(2.2f, 4.8f).maxTrackingRange(180).trackingTickInterval(1)
                            .build(RegistryKey.of(RegistryKeys.ENTITY_TYPE, id)));
            STORMREACH_BOSSES.put(kind, type);
        }
        STORMREACH_GATE = Registry.register(Registries.BLOCK, Identifier.of(MOD_ID, "stormreach_gate"), new StormreachGateBlock());
        STORMREACH_GATE_ITEM = Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "stormreach_gate"), new net.minecraft.item.BlockItem(STORMREACH_GATE, new net.minecraft.item.Item.Settings()));
        for (StormreachBiomeMiniBossKind kind : StormreachBiomeMiniBossKind.values()) {
            Identifier id = Identifier.of(MOD_ID, "stormreach_biome_miniboss_" + kind.id);
            EntityType<StormreachBiomeMiniBossEntity> boss = Registry.register(Registries.ENTITY_TYPE, id,
                    EntityType.Builder.create((type,world)->new StormreachBiomeMiniBossEntity(type,world,kind), SpawnGroup.MONSTER)
                            .dimensions(1.9f,3.4f).maxTrackingRange(128).trackingTickInterval(1)
                            .build(RegistryKey.of(RegistryKeys.ENTITY_TYPE,id)));
            STORMREACH_BIOME_MINI_BOSSES.put(kind,boss);
        }
        for (StormreachStructureKind kind : StormreachStructureKind.values()) {
            Identifier mobId=Identifier.of(MOD_ID,"stormreach_structure_mob_"+kind.id);
            EntityType<StormreachStructureMobEntity> mob=Registry.register(Registries.ENTITY_TYPE,mobId,EntityType.Builder.create((type,world)->new StormreachStructureMobEntity(type,world,kind),SpawnGroup.MONSTER).dimensions(1.0f,2.0f).maxTrackingRange(96).trackingTickInterval(1).build(RegistryKey.of(RegistryKeys.ENTITY_TYPE,mobId)));
            STORMREACH_STRUCTURE_MOBS.put(kind,mob);
            Identifier bossId=Identifier.of(MOD_ID,"stormreach_structure_miniboss_"+kind.id);
            EntityType<StormreachStructureMiniBossEntity> boss=Registry.register(Registries.ENTITY_TYPE,bossId,EntityType.Builder.create((type,world)->new StormreachStructureMiniBossEntity(type,world,kind),SpawnGroup.MONSTER).dimensions(1.8f,3.2f).maxTrackingRange(128).trackingTickInterval(1).build(RegistryKey.of(RegistryKeys.ENTITY_TYPE,bossId)));
            STORMREACH_STRUCTURE_MINI_BOSSES.put(kind,boss);
        }
        Identifier stormNpcId=Identifier.of(MOD_ID,"stormreach_npc");
        STORMREACH_NPC=Registry.register(Registries.ENTITY_TYPE,stormNpcId,EntityType.Builder.create(StormreachNPCEntity::new,SpawnGroup.CREATURE).dimensions(.7f,1.9f).maxTrackingRange(64).trackingTickInterval(2).build(RegistryKey.of(RegistryKeys.ENTITY_TYPE,stormNpcId)));
        Identifier traderId=Identifier.of(MOD_ID,"everdawn_trader");
        EVERDAWN_TRADER=Registry.register(Registries.ENTITY_TYPE,traderId,EntityType.Builder.create((type,world)->new EverdawnTraderEntity(type,world,EverdawnCreatureKind.MEADOW_STAG),SpawnGroup.CREATURE).dimensions(.7f,1.9f).maxTrackingRange(64).trackingTickInterval(2).build(RegistryKey.of(RegistryKeys.ENTITY_TYPE,traderId)));
        for (SunkenSandsCreatureKind kind : SunkenSandsCreatureKind.values()) { Identifier id=Identifier.of(MOD_ID,"sunken_sands_"+kind.id); EntityType<SunkenSandsCreatureEntity> type=Registry.register(Registries.ENTITY_TYPE,id,EntityType.Builder.create((et,w)->new SunkenSandsCreatureEntity(et,w,kind),SpawnGroup.MONSTER).dimensions(.9f,1.8f).maxTrackingRange(96).trackingTickInterval(2).build(RegistryKey.of(RegistryKeys.ENTITY_TYPE,id))); SUNKEN_SANDS_CREATURES.put(kind,type); }
        for (SunkenSandsBossKind kind : SunkenSandsBossKind.values()) { Identifier id=Identifier.of(MOD_ID,"sunken_sands_boss_"+kind.id); EntityType<SunkenSandsBossEntity> type=Registry.register(Registries.ENTITY_TYPE,id,EntityType.Builder.create((et,w)->new SunkenSandsBossEntity(et,w,kind),SpawnGroup.MONSTER).dimensions(2.4f,5.0f).maxTrackingRange(192).trackingTickInterval(1).build(RegistryKey.of(RegistryKeys.ENTITY_TYPE,id))); SUNKEN_SANDS_BOSSES.put(kind,type); }
        SUNKEN_SANDS_GATE=Registry.register(Registries.BLOCK,Identifier.of(MOD_ID,"sunken_sands_gate"),new SunkenSandsGateBlock()); SUNKEN_SANDS_GATE_ITEM=Registry.register(Registries.ITEM,Identifier.of(MOD_ID,"sunken_sands_gate"),new net.minecraft.item.BlockItem(SUNKEN_SANDS_GATE,new net.minecraft.item.Item.Settings()));
        Identifier snpc=Identifier.of(MOD_ID,"sunken_sands_npc"); SUNKEN_SANDS_NPC=Registry.register(Registries.ENTITY_TYPE,snpc,EntityType.Builder.create(SunkenSandsNPCEntity::new,SpawnGroup.CREATURE).dimensions(.7f,1.9f).maxTrackingRange(64).trackingTickInterval(2).build(RegistryKey.of(RegistryKeys.ENTITY_TYPE,snpc)));
        for(SunkenSandsStructureKind kind:SunkenSandsStructureKind.values()){Identifier id=Identifier.of(MOD_ID,"sunken_sands_structure_mob_"+kind.id); EntityType<SunkenSandsStructureMobEntity> mob=Registry.register(Registries.ENTITY_TYPE,id,EntityType.Builder.create((et,w)->new SunkenSandsStructureMobEntity(et,w,kind),SpawnGroup.MONSTER).dimensions(1f,2f).maxTrackingRange(96).trackingTickInterval(1).build(RegistryKey.of(RegistryKeys.ENTITY_TYPE,id))); SUNKEN_SANDS_STRUCTURE_MOBS.put(kind,mob); Identifier bid=Identifier.of(MOD_ID,"sunken_sands_structure_miniboss_"+kind.id); EntityType<SunkenSandsStructureMiniBossEntity> boss=Registry.register(Registries.ENTITY_TYPE,bid,EntityType.Builder.create((et,w)->new SunkenSandsStructureMiniBossEntity(et,w,kind),SpawnGroup.MONSTER).dimensions(1.8f,3.2f).maxTrackingRange(128).trackingTickInterval(1).build(RegistryKey.of(RegistryKeys.ENTITY_TYPE,bid))); SUNKEN_SANDS_STRUCTURE_MINI_BOSSES.put(kind,boss);}
        for(SunkenSandsBiomeMiniBossKind kind:SunkenSandsBiomeMiniBossKind.values()){Identifier id=Identifier.of(MOD_ID,"sunken_sands_biome_miniboss_"+kind.id); EntityType<SunkenSandsBiomeMiniBossEntity> boss=Registry.register(Registries.ENTITY_TYPE,id,EntityType.Builder.create((et,w)->new SunkenSandsBiomeMiniBossEntity(et,w,kind),SpawnGroup.MONSTER).dimensions(1.9f,3.4f).maxTrackingRange(128).trackingTickInterval(1).build(RegistryKey.of(RegistryKeys.ENTITY_TYPE,id))); SUNKEN_SANDS_BIOME_MINI_BOSSES.put(kind,boss);}
        for(UmbralCreatureKind kind:UmbralCreatureKind.values()){Identifier id=Identifier.of(MOD_ID,"umbral_"+kind.id);EntityType<UmbralCreatureEntity> t=Registry.register(Registries.ENTITY_TYPE,id,EntityType.Builder.create((et,w)->new UmbralCreatureEntity(et,w,kind),SpawnGroup.MONSTER).dimensions(.9f,1.9f).maxTrackingRange(96).trackingTickInterval(2).build(RegistryKey.of(RegistryKeys.ENTITY_TYPE,id)));UMBRAL_CREATURES.put(kind,t);}
        for(UmbralBossKind kind:UmbralBossKind.values()){Identifier id=Identifier.of(MOD_ID,"umbral_boss_"+kind.id);EntityType<UmbralBossEntity> t=Registry.register(Registries.ENTITY_TYPE,id,EntityType.Builder.create((et,w)->new UmbralBossEntity(et,w,kind),SpawnGroup.MONSTER).dimensions(3.0f,6.0f).maxTrackingRange(192).trackingTickInterval(1).build(RegistryKey.of(RegistryKeys.ENTITY_TYPE,id)));UMBRAL_BOSSES.put(kind,t);}
        for(UmbralMiniBossKind kind:UmbralMiniBossKind.values()){Identifier id=Identifier.of(MOD_ID,"umbral_miniboss_"+kind.id);EntityType<UmbralMiniBossEntity> t=Registry.register(Registries.ENTITY_TYPE,id,EntityType.Builder.create((et,w)->new UmbralMiniBossEntity(et,w,kind),SpawnGroup.MONSTER).dimensions(2.0f,3.4f).maxTrackingRange(128).trackingTickInterval(1).build(RegistryKey.of(RegistryKeys.ENTITY_TYPE,id)));UMBRAL_MINI_BOSSES.put(kind,t);}
        for(UmbralStructureBossKind kind:UmbralStructureBossKind.values()){Identifier id=Identifier.of(MOD_ID,"umbral_structure_boss_"+kind.id);EntityType<UmbralStructureBossEntity> t=Registry.register(Registries.ENTITY_TYPE,id,EntityType.Builder.create((et,w)->new UmbralStructureBossEntity(et,w,kind),SpawnGroup.MONSTER).dimensions(2.0f,3.6f).maxTrackingRange(128).trackingTickInterval(1).build(RegistryKey.of(RegistryKeys.ENTITY_TYPE,id)));UMBRAL_STRUCTURE_BOSSES.put(kind,t);}
        for(UmbralStructureKind kind:UmbralStructureKind.values()){Identifier id=Identifier.of(MOD_ID,"umbral_structure_"+kind.id);EntityType<UmbralStructureMobEntity> t=Registry.register(Registries.ENTITY_TYPE,id,EntityType.Builder.create(UmbralStructureMobEntity::new,SpawnGroup.MONSTER).dimensions(1f,2f).maxTrackingRange(96).build(RegistryKey.of(RegistryKeys.ENTITY_TYPE,id)));UMBRAL_STRUCTURE_MOBS.put(kind,t);}
        Identifier cw=Identifier.of(MOD_ID,"crystal_warden");CRYSTAL_WARDEN=Registry.register(Registries.ENTITY_TYPE,cw,EntityType.Builder.create(CrystalWardenEntity::new,SpawnGroup.MONSTER).dimensions(2.6f,4.6f).maxTrackingRange(160).trackingTickInterval(1).build(RegistryKey.of(RegistryKeys.ENTITY_TYPE,cw)));
        ABYSSAL_CRYSTAL_GATE=Registry.register(Registries.BLOCK,Identifier.of(MOD_ID,"abyssal_crystal_gate"),new AbyssalCrystalGateBlock());ABYSSAL_CRYSTAL_GATE_ITEM=Registry.register(Registries.ITEM,Identifier.of(MOD_ID,"abyssal_crystal_gate"),new net.minecraft.item.BlockItem(ABYSSAL_CRYSTAL_GATE,new net.minecraft.item.Item.Settings()));
        Identifier ec=Identifier.of(MOD_ID,"expansion_creature"); EXPANSION_CREATURE=Registry.register(Registries.ENTITY_TYPE,ec,EntityType.Builder.create(ExpansionCreatureEntity::new,SpawnGroup.MONSTER).dimensions(1.05f,2.1f).maxTrackingRange(96).trackingTickInterval(2).build(RegistryKey.of(RegistryKeys.ENTITY_TYPE,ec)));
        Identifier eb=Identifier.of(MOD_ID,"expansion_boss"); EXPANSION_BOSS=Registry.register(Registries.ENTITY_TYPE,eb,EntityType.Builder.create(ExpansionBossEntity::new,SpawnGroup.MONSTER).dimensions(2.8f,5.6f).maxTrackingRange(192).trackingTickInterval(1).build(RegistryKey.of(RegistryKeys.ENTITY_TYPE,eb)));
        Identifier ea=Identifier.of(MOD_ID,"expansion_animal"); EXPANSION_ANIMAL=Registry.register(Registries.ENTITY_TYPE,ea,EntityType.Builder.create(ExpansionAnimalEntity::new,SpawnGroup.CREATURE).dimensions(1.0f,1.6f).maxTrackingRange(64).trackingTickInterval(2).build(RegistryKey.of(RegistryKeys.ENTITY_TYPE,ea)));
    }

    @Override public void onInitialize() {
        OverworldPlusSounds.register();
        ModItems.register();
        AshenBlocks.register();
        AshenItems.register();
        AshenBossSounds.register();
        FrostveilBlocks.register();
        FrostveilItems.register();
        FrostveilWorldStructures.register();
        EverdawnBlocks.register();
        EverdawnItems.register();
        EverdawnWorldItems.register();
        EverdawnWorldItems.bindSetBonuses();
        EverdawnProgression.register();
        EverdawnRestoredContent.register();
        EverdawnWorldSystems.register();
        EverdawnWeaponAbilities.register();
        EverdawnWorldStructures.register();
        EverdawnBossSounds.register();
        StormreachBlocks.register();
        StormreachStructureBlocks.register();
        StormreachBiomeContent.register();
        StormreachItems.register();
        StormreachSounds.register();
        StormreachWorldSystems.register();
        SunkenSandsBlocks.register();
        SunkenSandsStructureBlocks.register();
        SunkenSandsBiomeContent.register();
        SunkenSandsItems.register();
        SunkenSandsSounds.register();
        SunkenSandsWorldSystems.register();
        UmbralBlocks.register();
        UmbralItems.register();
        UmbralSounds.register();
        UmbralWildsWorldSystems.register();
        ExpansionBlocks.register();
        ExpansionItems.register();
        ExpansionSounds.register();
        RpgItems.register();
        ExpansionWorldSystems.register();
        OverworldPlusRpgSystems.register();
        WorldUpgradeSystem.register();
        EverdawnBossArenas.bind(EVERDAWN_BOSSES);
        EverdawnBossArenas.register();
        for (EntityType<GuardianEntity> type : GUARDIANS.values()) FabricDefaultAttributeRegistry.register(type, GuardianEntity.createAttributes());
        for (EntityType<AshenBossEntity> type : ASHEN_BOSSES.values()) FabricDefaultAttributeRegistry.register(type, AshenBossEntity.createAttributes());
        for (EntityType<FrostveilBossEntity> type : FROSTVEIL_BOSSES.values()) FabricDefaultAttributeRegistry.register(type, FrostveilBossEntity.createAttributes());
        FabricDefaultAttributeRegistry.register(FROSTVEIL_MINION, FrostveilMinionEntity.attrs());
        for (EntityType<EverdawnBossEntity> type : EVERDAWN_BOSSES.values()) FabricDefaultAttributeRegistry.register(type, EverdawnBossEntity.createAttributes());
        FabricDefaultAttributeRegistry.register(EVERDAWN_MINION, EverdawnMinionEntity.attrs());
        FabricDefaultAttributeRegistry.register(EVERDAWN_CREATURE, EverdawnCreatureEntity.attributes(false));
        FabricDefaultAttributeRegistry.register(EVERDAWN_ELITE, EverdawnCreatureEntity.attributes(true));
        for (EntityType<EverdawnEncounterEntity> type : EVERDAWN_MINI_BOSSES.values()) FabricDefaultAttributeRegistry.register(type, EverdawnEncounterEntity.attributes(EverdawnEncounterRole.MINI_BOSS));
        for (EntityType<EverdawnEncounterEntity> type : EVERDAWN_STRUCTURE_BOSSES.values()) FabricDefaultAttributeRegistry.register(type, EverdawnEncounterEntity.attributes(EverdawnEncounterRole.STRUCTURE_BOSS));

        FabricDefaultAttributeRegistry.register(EVERDAWN_TRADER, net.minecraft.entity.passive.PassiveEntity.createLivingAttributes().add(net.minecraft.entity.attribute.EntityAttributes.MAX_HEALTH,30).add(net.minecraft.entity.attribute.EntityAttributes.MOVEMENT_SPEED,.5));
        for (EntityType<StormreachCreatureEntity> type : STORMREACH_CREATURES.values()) FabricDefaultAttributeRegistry.register(type, StormreachCreatureEntity.attributes());
        for (EntityType<StormreachBossEntity> type : STORMREACH_BOSSES.values()) FabricDefaultAttributeRegistry.register(type, StormreachBossEntity.attributes());
        FabricDefaultAttributeRegistry.register(STORMREACH_NPC, StormreachNPCEntity.attributes());
        for (EntityType<StormreachStructureMobEntity> type : STORMREACH_STRUCTURE_MOBS.values()) FabricDefaultAttributeRegistry.register(type, StormreachStructureMobEntity.attributes());
        for (EntityType<StormreachStructureMiniBossEntity> type : STORMREACH_STRUCTURE_MINI_BOSSES.values()) FabricDefaultAttributeRegistry.register(type, StormreachStructureMiniBossEntity.attributes());
        for (EntityType<StormreachBiomeMiniBossEntity> type : STORMREACH_BIOME_MINI_BOSSES.values()) FabricDefaultAttributeRegistry.register(type, StormreachBiomeMiniBossEntity.attributes());
        for (EntityType<SunkenSandsCreatureEntity> type : SUNKEN_SANDS_CREATURES.values()) FabricDefaultAttributeRegistry.register(type, SunkenSandsCreatureEntity.attributes());
        for (EntityType<SunkenSandsBossEntity> type : SUNKEN_SANDS_BOSSES.values()) FabricDefaultAttributeRegistry.register(type, SunkenSandsBossEntity.attributes());
        FabricDefaultAttributeRegistry.register(SUNKEN_SANDS_NPC, SunkenSandsNPCEntity.attributes());
        for (EntityType<SunkenSandsStructureMobEntity> type : SUNKEN_SANDS_STRUCTURE_MOBS.values()) FabricDefaultAttributeRegistry.register(type, SunkenSandsStructureMobEntity.attributes());
        for (EntityType<SunkenSandsStructureMiniBossEntity> type : SUNKEN_SANDS_STRUCTURE_MINI_BOSSES.values()) FabricDefaultAttributeRegistry.register(type, SunkenSandsStructureMiniBossEntity.attributes());
        for (EntityType<SunkenSandsBiomeMiniBossEntity> type : SUNKEN_SANDS_BIOME_MINI_BOSSES.values()) FabricDefaultAttributeRegistry.register(type, SunkenSandsBiomeMiniBossEntity.attributes());
        for(EntityType<UmbralCreatureEntity> type:UMBRAL_CREATURES.values())FabricDefaultAttributeRegistry.register(type,UmbralCreatureEntity.attributes());
        for(EntityType<UmbralBossEntity> type:UMBRAL_BOSSES.values())FabricDefaultAttributeRegistry.register(type,UmbralBossEntity.attributes());
        for(EntityType<UmbralMiniBossEntity> type:UMBRAL_MINI_BOSSES.values())FabricDefaultAttributeRegistry.register(type,UmbralMiniBossEntity.attributes());
        for(EntityType<UmbralStructureBossEntity> type:UMBRAL_STRUCTURE_BOSSES.values())FabricDefaultAttributeRegistry.register(type,UmbralStructureBossEntity.attributes());
        for(EntityType<UmbralStructureMobEntity> type:UMBRAL_STRUCTURE_MOBS.values())FabricDefaultAttributeRegistry.register(type,UmbralStructureMobEntity.attributes());
        FabricDefaultAttributeRegistry.register(CRYSTAL_WARDEN,CrystalWardenEntity.attributes());
        FabricDefaultAttributeRegistry.register(EXPANSION_CREATURE, ExpansionCreatureEntity.attributes());
        FabricDefaultAttributeRegistry.register(EXPANSION_BOSS, ExpansionBossEntity.attributes());
        FabricDefaultAttributeRegistry.register(EXPANSION_ANIMAL, ExpansionAnimalEntity.attributes());

        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> dispatcher.register(
                literal("overworldplus").then(literal("travel").then(argument("id", StringArgumentType.word()).executes(ctx -> {
                    ServerPlayerEntity player = ctx.getSource().getPlayer();
                    String id = StringArgumentType.getString(ctx, "id");
                    if (!DimensionalNexusBlock.WORLDS.contains(id) || !DimensionalNexusBlock.discovered(player, id)) { player.sendMessage(net.minecraft.text.Text.literal("That dimension is not discovered yet."), false); return 0; }
                    String registryId = id.equals("overworld") ? "minecraft:overworld" : MOD_ID + ":" + id;
                    ServerWorld target = ctx.getSource().getServer().getWorld(RegistryKey.of(RegistryKeys.WORLD, Identifier.of(registryId.split(":")[0], registryId.split(":")[1])));
                    if (target == null) { player.sendMessage(net.minecraft.text.Text.literal("Dimension unavailable: " + id), false); return 0; }
                    var spawn = target.getSpawnPos();
                    player.teleport(target, spawn.getX()+0.5, Math.max(target.getBottomY()+2, spawn.getY()+1), spawn.getZ()+0.5, java.util.Set.<PositionFlag>of(), player.getYaw(), player.getPitch(), true);
                    player.sendMessage(net.minecraft.text.Text.literal("Traveling to " + id.replace('_',' ') + "..."), false); return 1;
                })))
                .then(literal("mapbuy").then(argument("id", StringArgumentType.word()).executes(ctx -> {
                    ServerPlayerEntity player = ctx.getSource().getPlayer();
                    String id = StringArgumentType.getString(ctx, "id");
                    if (!DimensionalNexusBlock.WORLDS.contains(id) || !DimensionalNexusBlock.discovered(player, id)) { player.sendMessage(net.minecraft.text.Text.literal("That map is not available yet. Discover the dimension first."), false); return 0; }
                    String tag = "op_map_" + id;
                    if (player.getCommandTags().contains(tag)) { player.sendMessage(net.minecraft.text.Text.literal("You already own the " + id.replace('_',' ') + " map."), false); return 0; }
                    if (!player.isCreative()) {
                        int emeralds = player.getInventory().count(net.minecraft.item.Items.EMERALD);
                        if (emeralds < 8) { player.sendMessage(net.minecraft.text.Text.literal("You need 8 emeralds."), false); return 0; }
                        int left = 8; for (int i=0;i<player.getInventory().size() && left>0;i++) { var st=player.getInventory().getStack(i); if(st.isOf(net.minecraft.item.Items.EMERALD)){int take=Math.min(left,st.getCount()); player.getInventory().removeStack(i,take); left-=take;}}
                    }
                    player.addCommandTag(tag); player.giveItemStack(new net.minecraft.item.ItemStack(RpgItems.EXPLORER_MAP));
                    player.sendMessage(net.minecraft.text.Text.literal("Map acquired: " + id.replace('_',' ')), false); return 1;
                })))
                .then(literal("mapfragment").then(argument("id", StringArgumentType.word()).executes(ctx -> {
                    ServerPlayerEntity player = ctx.getSource().getPlayer();
                    String id = StringArgumentType.getString(ctx, "id");
                    String current = player.getServerWorld().getRegistryKey().getValue().getPath();
                    if (!id.equals(current) || !player.getCommandTags().contains("op_map_" + id)) { player.sendMessage(net.minecraft.text.Text.literal("You need to own and stand in that map's dimension."), false); return 0; }
                    if (!player.isCreative()) {
                        int emeralds = player.getInventory().count(net.minecraft.item.Items.EMERALD);
                        if (emeralds < 3) { player.sendMessage(net.minecraft.text.Text.literal("You need 3 emeralds."), false); return 0; }
                        int left = 3; for (int i=0;i<player.getInventory().size() && left>0;i++) { var st=player.getInventory().getStack(i); if(st.isOf(net.minecraft.item.Items.EMERALD)){int take=Math.min(left,st.getCount()); player.getInventory().removeStack(i,take); left-=take;}}
                    }
                    int rx=Math.floorDiv(player.getBlockPos().getX(),256), rz=Math.floorDiv(player.getBlockPos().getZ(),256);
                    player.addCommandTag("op_map_fragment_"+id+"_"+rx+"_"+rz);
                    player.sendMessage(net.minecraft.text.Text.literal("Map fragment revealed."), false); return 1;
                })))
                .then(literal("ui").executes(ctx -> { ctx.getSource().sendFeedback(() -> net.minecraft.text.Text.literal("Open the Overworld Plus menu with O."), false); return 1; }))
                .then(literal("owp").requires(source -> source.hasPermissionLevel(2))
                        .then(literal("world").then(argument("id", StringArgumentType.word()).executes(ctx -> {
                            ServerPlayerEntity player = ctx.getSource().getPlayer();
                            String id = StringArgumentType.getString(ctx, "id");
                            ServerWorld target = ctx.getSource().getServer().getWorld(RegistryKey.of(RegistryKeys.WORLD, Identifier.of(MOD_ID, id)));
                            if (target == null) { player.sendMessage(net.minecraft.text.Text.literal("Unknown Overworld Plus world: " + id), false); return 0; }
                            player.teleport(target, 0.5, 120, 0.5, java.util.Set.<PositionFlag>of(), player.getYaw(), player.getPitch(), true);
                            return 1;
                        }))))
                .then(literal("upgrade").then(argument("choice", IntegerArgumentType.integer(0, 2)).executes(ctx -> {
                    ServerPlayerEntity player = ctx.getSource().getPlayer();
                    int choice = IntegerArgumentType.getInteger(ctx, "choice");
                    return WorldUpgradeSystem.apply(player, choice) ? 1 : 0;
                })))
                .then(literal("upgrade_refresh").executes(ctx -> {
                    ServerPlayerEntity player = ctx.getSource().getPlayer();
                    WorldUpgradeSystem.refresh(player);
                    player.sendMessage(net.minecraft.text.Text.literal("§7The World Enchanter reshuffles its three choices."), true);
                    return 1;
                }))
        ));
    }
}
