package com.overworldplus;

import net.minecraft.util.Identifier;

public enum GuardianKind {
    VOLKARION("volkarion", "Volkarion, Lord of the Magma", 0xFF4A0900, 0xFFFF5A00, "eye_of_flame"),
    UMBRAAZAR("umbraazar", "Umbraazar, Watcher of Shadows", 0xFF19002F, 0xFF9B35FF, "eye_of_shadow"),
    AEROLIX("aerolix", "Aerolix, Tempest of the Skies", 0xFF08243A, 0xFF39B9FF, "eye_of_storm"),
    VERDANTUS("verdantus", "Verdantus, Guardian of Life", 0xFF092A15, 0xFF55E85C, "eye_of_nature"),
    SEKHMAR("sekhmar", "Sekhmar, Emperor of the Dunes", 0xFF4A2604, 0xFFFFC23B, "eye_of_sand"),
    GLACIORIS("glacioris", "Glacioris, Heart of Eternal Winter", 0xFF082C46, 0xFF75E8FF, "eye_of_frost");

    public final String id;
    public final String title;
    public final int darkColor;
    public final int glowColor;
    public final String eyeId;

    GuardianKind(String id, String title, int darkColor, int glowColor, String eyeId) {
        this.id = id;
        this.title = title;
        this.darkColor = darkColor;
        this.glowColor = glowColor;
        this.eyeId = eyeId;
    }

    public Identifier texture() {
        return Identifier.of(OverworldPlus.MOD_ID, "textures/entity/" + id + ".png");
    }

    public static GuardianKind fromId(String id) {
        for (GuardianKind kind : values()) if (kind.id.equals(id)) return kind;
        return VOLKARION;
    }
}
