package com.overworldplus.expansion;

import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.block.BlockState;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.ActionResult;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.world.World;

/** Direct, no-book, enchanting-table-style upgrade station. */
public final class WorldEnchanterBlock extends Block {
    public WorldEnchanterBlock() {
        super(AbstractBlock.Settings.copy(Blocks.ENCHANTING_TABLE).strength(5.0f, 1200.0f).luminance(s -> 8));
    }
    @Override
    protected ActionResult onUse(BlockState state, World world, net.minecraft.util.math.BlockPos pos, PlayerEntity player, BlockHitResult hit) {
        return ActionResult.SUCCESS;
    }
}
