package com.overworldplus.expansion;

import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;

public final class WorldBeaconBlock extends Block {
    public WorldBeaconBlock() {
        super(AbstractBlock.Settings.copy(Blocks.BEACON).strength(3.5f).luminance(state -> 15));
    }
}
