package com.overworldplus.expansion;

import com.overworldplus.OverworldPlus;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Identifier;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.network.packet.s2c.play.PositionFlag;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

public final class DimensionalNexusBlock extends Block {
    public static final String TAG_PREFIX = "op_nexus_";
    public static final List<String> WORLDS = List.of(
            "overworld",
            "ashen_abyss",
            "frostveil",
            "everdawn",
            "stormreach",
            "sunken_sands",
            "umbral_wilds",
            "crystal_abyss",
            "deadlands",
            "abyssal_ocean",
            "kingdom_of_ruins",
            "astralis",
            "crimson_realm",
            "dragon_isles",
            "wildheart",
            "warforge",
            "the_hollow",
            "ghostmoor",
            "eternal_sun",
            "moonfall",
            "voidlands"
    );

    public DimensionalNexusBlock() {
        super(AbstractBlock.Settings.copy(Blocks.RESPAWN_ANCHOR).strength(8.0f, 1200.0f).luminance(state -> 15));
    }

    public static String tagFor(String id) {
        return TAG_PREFIX + id;
    }

    public static void markDiscovered(ServerPlayerEntity player, String worldId) {
        if (WORLDS.contains(worldId)) player.addCommandTag(tagFor(worldId));
    }

    public static boolean discovered(PlayerEntity player, String worldId) {
        return player.getCommandTags().contains(tagFor(worldId));
    }

    public static List<String> discoveredWorlds(PlayerEntity player) {
        List<String> result = new ArrayList<>();
        for (String id : WORLDS) if (discovered(player, id)) result.add(id);
        return result;
    }

    @Override
    protected ActionResult onUse(BlockState state, World world, BlockPos pos, PlayerEntity player, BlockHitResult hit) {
        if (world.isClient) return ActionResult.SUCCESS;
        if (!(player instanceof ServerPlayerEntity sp) || world.getServer() == null) return ActionResult.SUCCESS;

        String current = world.getRegistryKey().getValue().getPath();
        if (current.equals("overworld") || WORLDS.contains(current)) markDiscovered(sp, current);

        List<String> found = discoveredWorlds(sp);
        if (found.size() <= 1) {
            sp.sendMessage(Text.literal("§dDimensional Nexus: §fExplore a new dimension first. Discovered: §7" + found.size() + "/20"), true);
            return ActionResult.SUCCESS;
        }

        int index = found.indexOf(current);
        if (index < 0) index = 0;
        int direction = sp.isSneaking() ? -1 : 1;
        String targetId = found.get(Math.floorMod(index + direction, found.size()));
        if (targetId.equals(current)) return ActionResult.SUCCESS;

        String registryId = targetId.equals("overworld") ? "minecraft:overworld" : OverworldPlus.MOD_ID + ":" + targetId;
        ServerWorld target = world.getServer().getWorld(RegistryKey.of(RegistryKeys.WORLD, Identifier.of(registryId.split(":")[0], registryId.split(":")[1])));
        if (target == null) {
            sp.sendMessage(Text.literal("§cThe Nexus cannot find the dimension " + targetId + "."), true);
            return ActionResult.SUCCESS;
        }

        BlockPos spawn = target.getSpawnPos();
        double x = spawn.getX() + 0.5;
        double y = Math.max(target.getBottomY() + 2, spawn.getY() + 1.0);
        double z = spawn.getZ() + 0.5;
        target.spawnParticles(net.minecraft.particle.ParticleTypes.END_ROD, x, y, z, 45, 1.5, 1.5, 1.5, 0.04);
        sp.teleport(target, x, y, z, Set.<PositionFlag>of(), sp.getYaw(), sp.getPitch(), true);
        sp.sendMessage(Text.literal("§dDimensional Nexus §8→ §f" + pretty(targetId) + " §7(" + found.size() + "/20 discovered)"), false);
        return ActionResult.SUCCESS;
    }

    private static String pretty(String id) {
        String[] words = id.replace('_', ' ').split(" ");
        StringBuilder out = new StringBuilder();
        for (String w : words) {
            if (w.isEmpty()) continue;
            if (out.length() > 0) out.append(' ');
            out.append(Character.toUpperCase(w.charAt(0))).append(w.substring(1));
        }
        return out.toString();
    }
}
