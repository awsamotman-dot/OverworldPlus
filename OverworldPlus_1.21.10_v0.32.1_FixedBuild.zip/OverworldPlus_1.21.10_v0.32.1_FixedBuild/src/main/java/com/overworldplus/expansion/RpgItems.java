package com.overworldplus.expansion;

import com.overworldplus.OverworldPlus;
import net.minecraft.block.Block;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public final class RpgItems {
    public static Item CLASS_SIGIL;
    public static Item FACTION_TOKEN;
    public static Item ANCIENT_CODEX;
    public static Item NIGHTMARE_CORE;
    public static Item MYTHIC_CORE;
    public static Item EXPLORER_MAP;
    public static Block MAP_SHOP;
    public static Item MAP_SHOP_ITEM;
    public static Block WORLD_BEACON;
    public static Item WORLD_BEACON_ITEM;

    public static void register() {
        CLASS_SIGIL = Registry.register(Registries.ITEM, Identifier.of(OverworldPlus.MOD_ID, "class_sigil"), new Item(new Item.Settings().maxCount(1)));
        FACTION_TOKEN = Registry.register(Registries.ITEM, Identifier.of(OverworldPlus.MOD_ID, "faction_token"), new Item(new Item.Settings().maxCount(16)));
        ANCIENT_CODEX = Registry.register(Registries.ITEM, Identifier.of(OverworldPlus.MOD_ID, "ancient_codex"), new Item(new Item.Settings().maxCount(1)));
        NIGHTMARE_CORE = Registry.register(Registries.ITEM, Identifier.of(OverworldPlus.MOD_ID, "nightmare_core"), new Item(new Item.Settings().maxCount(1)));
        MYTHIC_CORE = Registry.register(Registries.ITEM, Identifier.of(OverworldPlus.MOD_ID, "mythic_core"), new Item(new Item.Settings().maxCount(16)));
        EXPLORER_MAP = Registry.register(Registries.ITEM, Identifier.of(OverworldPlus.MOD_ID, "explorer_map"), new ExplorerMapItem());
        MAP_SHOP = Registry.register(Registries.BLOCK, Identifier.of(OverworldPlus.MOD_ID, "map_shop"), new MapShopBlock());
        MAP_SHOP_ITEM = Registry.register(Registries.ITEM, Identifier.of(OverworldPlus.MOD_ID, "map_shop"), new BlockItem(MAP_SHOP, new Item.Settings().maxCount(1)));
        WORLD_BEACON = Registry.register(Registries.BLOCK, Identifier.of(OverworldPlus.MOD_ID, "world_beacon"), new WorldBeaconBlock());
        WORLD_BEACON_ITEM = Registry.register(Registries.ITEM, Identifier.of(OverworldPlus.MOD_ID, "world_beacon"), new BlockItem(WORLD_BEACON, new Item.Settings().maxCount(16)));
    }

    private RpgItems() {}
}
