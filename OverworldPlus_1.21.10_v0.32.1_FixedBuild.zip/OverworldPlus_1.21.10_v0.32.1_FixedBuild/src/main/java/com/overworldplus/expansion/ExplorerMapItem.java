package com.overworldplus.expansion;

import net.minecraft.item.Item;

public final class ExplorerMapItem extends Item {
    public ExplorerMapItem() { super(new Item.Settings().maxCount(1)); }
}
