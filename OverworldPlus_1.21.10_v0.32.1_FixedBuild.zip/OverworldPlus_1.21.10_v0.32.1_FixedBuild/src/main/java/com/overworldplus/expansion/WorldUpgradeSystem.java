package com.overworldplus.expansion;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.NbtComponent;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.util.Identifier;
import net.minecraft.world.World;

import java.util.*;

/**
 * 20 worlds x 100 direct upgrades = 2,000 upgrades.
 * Options are shown directly in the World Enchanter UI; no books are used.
 */
public final class WorldUpgradeSystem {
    public static final String TAG_REFRESH = "op_upgrade_refresh";
    private static final String DATA_PREFIX = "OPUpgrade:";
    public static final List<String> WORLDS = List.of(
        "ashen_abyss","frostveil","everdawn","stormreach","sunken_sands","umbral_wilds",
        "crystal_abyss","deadlands","abyssal_ocean","kingdom_of_ruins","astralis","crimson_realm",
        "dragon_isles","wildheart","warforge","the_hollow","ghostmoor","eternal_sun","moonfall","voidlands"
    );
    private static final String[][] THEMES = {
        {"Ember","Cinder","Magma","Ash","Inferno","Scorch","Caldera","Flame","Searing","Volcanic"},
        {"Frost","Glacier","Rime","Blizzard","Icebound","Winter","Frozen","Hail","Boreal","Whiteout"},
        {"Dawn","Radiant","Bloom","Sunrise","Halo","Gleam","Aurora","Luminous","Daybreak","Everdawn"},
        {"Thunder","Storm","Tempest","Volt","Lightning","Gale","Sky","Cyclone","Cloud","Stormheart"},
        {"Dune","Sun","Scarab","Oasis","Sirocco","Mirage","Sand","Serpent","Pharaoh","Sunken"},
        {"Shadow","Wraith","Umbral","Bloodleaf","Night","Eclipse","Ghostwood","Voidroot","Moonless","Darkwood"},
        {"Prism","Crystal","Refraction","Shard","Spectrum","Gem","Lattice","Radiance","Glass","Abyssal"},
        {"Grave","Rot","Bone","Mire","Death","Plague","Ghoul","Dread","Tomb","Deadland"},
        {"Abyss","Tide","Depth","Trench","Tsunami","Pearl","Pressure","Current","Leviathan","Drowned"},
        {"Ruin","Relic","Ancient","Obelisk","Royal","Dust","Crown","Forgotten","Dynasty","Remnant"},
        {"Star","Astral","Comet","Nova","Orbit","Cosmic","Nebula","Gravity","Celestial","Starlight"},
        {"Crimson","Blood","Scarlet","Sanguine","Fang","Rage","Hemal","Vampiric","Redmoon","Carnage"},
        {"Drake","Dragon","Scale","Wyrm","Flamewing","Skyfire","Hoarfang","Elder","Draconic","Dragonheart"},
        {"Wild","Heartwood","Thorn","Grove","Root","Bloom","Verdant","Beast","Ancientwood","Lifebloom"},
        {"War","Forge","Ironclad","Siege","Battle","Steel","Armory","Conquest","Machine","Warheart"},
        {"Hollow","Null","Empty","Echo","Abyssal","Silence","Lost","Bleak","Vacant","Hollowheart"},
        {"Ghost","Specter","Haunt","Mist","Phantom","Gravewind","Soul","Mourning","Wisp","Ghostheart"},
        {"Solar","Sunfire","Radiant","Flare","Corona","Dawnfire","Helios","Burning","Solstice","Sunheart"},
        {"Lunar","Moon","Crescent","Tide","Nightfall","Silver","Eclipse","Starglow","Lunaris","Moonheart"},
        {"Void","Nullstar","Rift","Oblivion","Reality","Entropy","Singularity","Abyss","Darkmatter","Voidheart"}
    };
    private static final String[] SUFFIXES = {"Guard","Edge","Step","Ward","Might","Vitality","Focus","Haste","Grace","Heart"};

    public record Option(String id, String name, int level, int cost) {}

    public static void register() {
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
                if (p.age % 10 != 0) continue;
                applyUpgrades(p);
            }
        });
    }

    public static int worldTier(String worldId) { int i = WORLDS.indexOf(worldId); return i < 0 ? 0 : i + 1; }
    public static boolean isUpgradeWorld(String id) { return WORLDS.contains(id); }
    public static int upgradeIndex(String worldId, int slot) { return Math.floorMod(slot, 100); }
    public static String upgradeId(String worldId, int slot) { return worldId + ":" + upgradeIndex(worldId, slot); }

    public static String upgradeName(String worldId, int slot) {
        int i = upgradeIndex(worldId, slot);
        return THEMES[worldTier(worldId)-1][i/10] + " " + SUFFIXES[i%10];
    }

    public static int levelFor(String worldId, int slot, long salt) {
        int tier = worldTier(worldId);
        long h = mix(salt ^ worldId.hashCode() * 0x9E3779B97F4A7C15L ^ slot * 0xBF58476D1CE4E5B9L);
        return 1 + Math.floorMod((int)(h ^ (h >>> 32)), Math.min(10, 3 + tier / 2));
    }

    public static int cost(String worldId, int level) {
        int tier = worldTier(worldId);
        return 5 + tier * 3 + level * level * 2;
    }

    public static List<Option> optionsFor(String world, UUID uuid, long worldSeed, ItemStack stack, Set<String> tags) {
        if (!isUpgradeWorld(world) || stack.isEmpty()) return List.of();
        long a = uuid.getMostSignificantBits() ^ uuid.getLeastSignificantBits();
        long c = Registries.ITEM.getId(stack.getItem()).hashCode();
        long refresh = tags.stream().filter(s -> s.startsWith(TAG_REFRESH)).findFirst().map(String::hashCode).orElse(0);
        long seed = mix(a ^ worldSeed ^ c ^ refresh);
        NbtComponent existing = stack.get(DataComponentTypes.CUSTOM_DATA);
        NbtCompound existingNbt = existing == null ? new NbtCompound() : existing.copyNbt();
        List<Integer> picks = new ArrayList<>();
        for (int i=0;i<1000 && picks.size()<3;i++) {
            int idx=Math.floorMod((int)mix(seed+i*0x9E3779B9L),100);
            if(!picks.contains(idx) && !existingNbt.contains(DATA_PREFIX + upgradeId(world, idx))) picks.add(idx);
        }
        List<Option> out=new ArrayList<>();
        for(int idx:picks){int lv=levelFor(world,idx,seed);out.add(new Option(upgradeId(world,idx),upgradeName(world,idx),lv,cost(world,lv)));}
        return out;
    }

    public static int totalUpgrades() { return WORLDS.size() * 100; }

    public static List<Option> options(ServerPlayerEntity p) {
        String world = p.getServerWorld().getRegistryKey().getValue().getPath();
        return optionsFor(world, p.getUuid(), p.getServerWorld().getSeed(), p.getMainHandStack(), p.getCommandTags());
    }

    public static Option optionFor(ServerPlayerEntity p, int choice) {
        List<Option> o = options(p); return choice >= 0 && choice < o.size() ? o.get(choice) : null;
    }

    public static boolean apply(ServerPlayerEntity p, int choice) {
        Option opt = optionFor(p, choice);
        if (opt == null) { p.sendMessage(Text.literal("§8No upgrade is available here."), true); return false; }
        ItemStack stack = p.getMainHandStack();
        if (stack.isEmpty()) { p.sendMessage(Text.literal("§8Hold a weapon, armor piece, tool or compatible item."), true); return false; }
        if (!p.isCreative() && p.experienceLevel < opt.cost()) {
            p.sendMessage(Text.literal("§cYou need " + opt.cost() + " XP levels."), true); return false;
        }
        if (!p.isCreative()) p.addExperienceLevels(-opt.cost());
        String key = DATA_PREFIX + opt.id();
        NbtComponent.set(DataComponentTypes.CUSTOM_DATA, stack, n -> n.putInt(key, opt.level()));
        p.getInventory().markDirty();
        p.sendMessage(Text.literal("§6Upgrade applied: §e" + opt.name() + " " + roman(opt.level()) + " §7(" + opt.cost() + " XP)"), false);
        return true;
    }

    public static int levelOn(ItemStack stack, String upgradeId) {
        NbtComponent data = stack.get(DataComponentTypes.CUSTOM_DATA);
        if (data == null) return 0;
        return data.copyNbt().getInt(DATA_PREFIX + upgradeId);
    }

    private static long optionSeed(ServerPlayerEntity p, ItemStack stack) {
        long a = p.getUuid().getMostSignificantBits() ^ p.getUuid().getLeastSignificantBits();
        long b = p.getServerWorld().getSeed();
        long c = Registries.ITEM.getId(stack.getItem()).hashCode();
        long refresh = p.getCommandTags().stream().filter(s -> s.startsWith(TAG_REFRESH)).findFirst().map(String::hashCode).orElse(0);
        return mix(a ^ b ^ c ^ refresh);
    }

    public static void refresh(ServerPlayerEntity p) {
        for (String t : new HashSet<>(p.getCommandTags())) if (t.startsWith(TAG_REFRESH)) p.removeCommandTag(t);
        p.addCommandTag(TAG_REFRESH + "_" + p.getRandom().nextLong());
    }

    private static void applyUpgrades(ServerPlayerEntity p) {
        List<ItemStack> stacks = new ArrayList<>();
        stacks.add(p.getMainHandStack()); stacks.add(p.getOffHandStack());
        stacks.add(p.getEquippedStack(EquipmentSlot.HEAD)); stacks.add(p.getEquippedStack(EquipmentSlot.CHEST));
        stacks.add(p.getEquippedStack(EquipmentSlot.LEGS)); stacks.add(p.getEquippedStack(EquipmentSlot.FEET));
        for (ItemStack stack : stacks) if (!stack.isEmpty()) applyStackEffects(p, stack);
    }

    private static void applyStackEffects(ServerPlayerEntity p, ItemStack stack) {
        NbtComponent data = stack.get(DataComponentTypes.CUSTOM_DATA);
        if (data == null || data.isEmpty()) return;
        NbtCompound n = data.copyNbt();
        for (String key : n.getKeys()) {
            if (!key.startsWith(DATA_PREFIX)) continue;
            String id = key.substring(DATA_PREFIX.length());
            String[] parts = id.split(":"); if (parts.length != 2) continue;
            int tier = worldTier(parts[0]); if (tier <= 0) continue;
            int idx; try { idx = Integer.parseInt(parts[1]); } catch (Exception e) { continue; }
            int lv = n.getInt(key); if (lv <= 0) continue;
            int effect = idx % 10;
            int amp = Math.min(4, Math.max(0, (lv-1)/3 + (tier-1)/5));
            switch (effect) {
                case 0 -> p.addStatusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE, 30, amp, true, false));
                case 1 -> p.addStatusEffect(new StatusEffectInstance(StatusEffects.STRENGTH, 30, amp, true, false));
                case 2 -> p.addStatusEffect(new StatusEffectInstance(StatusEffects.SPEED, 30, amp, true, false));
                case 3 -> p.addStatusEffect(new StatusEffectInstance(StatusEffects.FIRE_RESISTANCE, 30, 0, true, false));
                case 4 -> p.addStatusEffect(new StatusEffectInstance(StatusEffects.ABSORPTION, 30, amp, true, false));
                case 5 -> p.addStatusEffect(new StatusEffectInstance(StatusEffects.REGENERATION, 30, amp, true, false));
                case 6 -> p.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, 30, 0, true, false));
                case 7 -> p.addStatusEffect(new StatusEffectInstance(StatusEffects.HASTE, 30, amp, true, false));
                case 8 -> p.addStatusEffect(new StatusEffectInstance(StatusEffects.JUMP_BOOST, 30, amp, true, false));
                default -> p.addStatusEffect(new StatusEffectInstance(StatusEffects.WATER_BREATHING, 30, 0, true, false));
            }
        }
    }

    public static String roman(int n) { return switch(n){case 1->"I";case 2->"II";case 3->"III";case 4->"IV";case 5->"V";case 6->"VI";case 7->"VII";case 8->"VIII";case 9->"IX";default->"X";}; }
    private static long mix(long z){z=(z^(z>>>30))*0xBF58476D1CE4E5B9L;z=(z^(z>>>27))*0x94D049BB133111EBL;return z^(z>>>31);}
    private WorldUpgradeSystem() {}
}
