package com.overworldplus.expansion;

import com.overworldplus.OverworldPlus;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.particle.ParticleTypes;
import java.util.*;

public final class OverworldPlusRpgSystems {
    private static final String[] CLASSES = {"warrior", "ranger", "mage", "blood_knight", "shadow", "storm"};
    private static final String[] FACTIONS = {"free_hunters", "royal_guard", "arcane_circle", "shadow_covenant"};
    private static final Map<String, String> WORLD_FACTION = new HashMap<>();
    private static final Map<String, Integer> EVENT_COOLDOWN = new HashMap<>();
    private static final Set<UUID> FIRST_TICK = Collections.synchronizedSet(new HashSet<>());
    private static final String[] LORE = {
        "The First Architect divided the World Heart into twenty locks.",
        "Every dimension remembers the civilization that once guarded it.",
        "The gates become harder because the Heart resists being reunited.",
        "Some bosses were guardians, not villains; history was written by survivors.",
        "The Voidlands are not empty. They are the space between broken worlds.",
        "The Nightmare is born when the World Heart is destroyed instead of restored.",
        "A city that survives an invasion can grow, trade and remember its savior.",
        "Ancient crystals store memories of events that happened before the split."
    };
    static {
        WORLD_FACTION.put("ashen_abyss", "iron_legion"); WORLD_FACTION.put("frostveil", "royal_guard");
        WORLD_FACTION.put("everdawn", "arcane_circle"); WORLD_FACTION.put("stormreach", "free_hunters");
        WORLD_FACTION.put("sunken_sands", "royal_guard"); WORLD_FACTION.put("umbral_wilds", "shadow_covenant");
        WORLD_FACTION.put("crystal_abyss", "arcane_circle"); WORLD_FACTION.put("deadlands", "shadow_covenant");
        WORLD_FACTION.put("abyssal_ocean", "free_hunters"); WORLD_FACTION.put("kingdom_of_ruins", "royal_guard");
        WORLD_FACTION.put("astralis", "arcane_circle"); WORLD_FACTION.put("crimson_realm", "shadow_covenant");
        WORLD_FACTION.put("dragon_isles", "free_hunters"); WORLD_FACTION.put("wildheart", "free_hunters");
        WORLD_FACTION.put("warforge", "iron_legion"); WORLD_FACTION.put("the_hollow", "shadow_covenant");
        WORLD_FACTION.put("ghostmoor", "shadow_covenant"); WORLD_FACTION.put("eternal_sun", "royal_guard");
        WORLD_FACTION.put("moonfall", "arcane_circle"); WORLD_FACTION.put("voidlands", "shadow_covenant");
    }

    public static void register() {
        UseItemCallback.EVENT.register((player, world, hand) -> handleItemUse(player, world, hand));
        ServerTickEvents.END_WORLD_TICK.register(OverworldPlusRpgSystems::tick);
    }

    private static ActionResult handleItemUse(PlayerEntity player, World world, Hand hand) {
        ItemStack stack = player.getStackInHand(hand);
        if (world.isClient) return ActionResult.PASS;
        if (stack.isOf(RpgItems.CLASS_SIGIL)) { cycleClass(player); consume(player, hand); return ActionResult.SUCCESS; }
        if (stack.isOf(RpgItems.FACTION_TOKEN)) { cycleFaction(player); consume(player, hand); return ActionResult.SUCCESS; }
        if (stack.isOf(RpgItems.ANCIENT_CODEX)) { revealLore(player); return ActionResult.SUCCESS; }
        if (stack.isOf(RpgItems.NIGHTMARE_CORE)) { toggleNightmare(player); consume(player, hand); return ActionResult.SUCCESS; }
        return ActionResult.PASS;
    }

    private static void consume(PlayerEntity player, Hand hand) { if (!player.isCreative()) player.getStackInHand(hand).decrement(1); }

    private static void cycleClass(PlayerEntity p) {
        String current = classOf(p); int next = (indexOf(CLASSES, current) + 1) % CLASSES.length; clearPrefix(p, "op_class_"); p.addCommandTag("op_class_" + CLASSES[next]);
        p.sendMessage(Text.literal("§6Class changed → §e" + pretty(CLASSES[next])), true);
    }
    private static void cycleFaction(PlayerEntity p) {
        String current = factionOf(p); int next = (indexOf(FACTIONS, current) + 1) % FACTIONS.length; clearPrefix(p, "op_faction_"); p.addCommandTag("op_faction_" + FACTIONS[next] + "_rep_0");
        p.sendMessage(Text.literal("§bFaction → §f" + pretty(FACTIONS[next])), true);
    }
    private static void toggleNightmare(PlayerEntity p) {
        if (p.getCommandTags().contains("op_new_game_plus")) { p.removeCommandTag("op_new_game_plus"); p.sendMessage(Text.literal("§aNew Game+ disabled."), true); }
        else { p.addCommandTag("op_new_game_plus"); p.sendMessage(Text.literal("§cNEW GAME+ ACTIVATED — worlds are more dangerous."), true); }
    }
    private static void revealLore(PlayerEntity p) {
        int i = Math.floorMod(p.getCommandTags().hashCode() + p.getBlockX() + p.getBlockZ(), LORE.length);
        p.addCommandTag("op_lore_" + i); p.sendMessage(Text.literal("§dAncient Lore: §f" + LORE[i]), false);
    }

    private static void tick(ServerWorld w) {
        if (w.getTime() % 40 != 0) return;
        String id = w.getRegistryKey().getValue().getPath();
        boolean expansion = ExpansionProfiles.worldIndex(id) >= 0;
        for (ServerPlayerEntity p : w.getPlayers()) {
            if (FIRST_TICK.add(p.getUuid()) && expansion) p.sendMessage(Text.literal("§5Overworld Plus §7— §dThe world remembers your arrival."), false);
            if (expansion) applyBuildClass(p, id);
            if (nearBeacon(w, p.getBlockPos())) {
                p.addStatusEffect(new StatusEffectInstance(StatusEffects.REGENERATION, 80, 0, true, false));
                p.addStatusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE, 80, 0, true, false));
            }
            if (w.getTime() % 600 == 0 && expansion) worldEvent(w, p, id);
            if (w.getTime() % 1200 == 0 && expansion) grantExplorationMemory(p, id);
        }
        EVENT_COOLDOWN.replaceAll((k,v) -> Math.max(0, v - 1));
    }

    private static void applyBuildClass(ServerPlayerEntity p, String world) {
        String c = classOf(p);
        if (c.equals("warrior")) p.addStatusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE, 60, 0, true, false));
        else if (c.equals("ranger")) p.addStatusEffect(new StatusEffectInstance(StatusEffects.SPEED, 60, 0, true, false));
        else if (c.equals("mage")) p.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, 60, 0, true, false));
        else if (c.equals("blood_knight") && p.getHealth() < p.getMaxHealth() * .65f) p.addStatusEffect(new StatusEffectInstance(StatusEffects.STRENGTH, 60, 0, true, false));
        else if (c.equals("shadow") && p.getWorld().getLightLevel(p.getBlockPos()) < 8) p.addStatusEffect(new StatusEffectInstance(StatusEffects.INVISIBILITY, 60, 0, true, false));
        else if (c.equals("storm")) p.addStatusEffect(new StatusEffectInstance(StatusEffects.JUMP_BOOST, 60, 0, true, false));
        if (p.getCommandTags().contains("op_new_game_plus")) {
            p.addStatusEffect(new StatusEffectInstance(StatusEffects.MINING_FATIGUE, 45, 0, true, false));
            if (p.getWorld().getTime() % 400 == 0) p.sendMessage(Text.literal("§cNG+ §7— the world grows more hostile."), true);
        }
    }

    private static void worldEvent(ServerWorld w, ServerPlayerEntity p, String id) {
        long seed = w.getSeed() ^ p.getBlockX() * 341873128712L ^ p.getBlockZ() * 132897987541L ^ w.getTime();
        int event = Math.floorMod((int)(seed ^ (seed >>> 32)), 8);
        switch (event) {
            case 0 -> { w.setWeather(0, 500, true, false); w.spawnParticles(ParticleTypes.ELECTRIC_SPARK, p.getX(), p.getY()+2, p.getZ(), 80, 5, 3, 5, .08); p.sendMessage(Text.literal("§bWORLD EVENT: §fA violent storm tears through " + pretty(id)), false); }
            case 1 -> { w.setWeather(0, 450, false, true); w.spawnParticles(ParticleTypes.CRIMSON_SPORE, p.getX(), p.getY()+2, p.getZ(), 90, 5, 3, 5, .05); p.sendMessage(Text.literal("§cWORLD EVENT: §fThe sky bleeds over " + pretty(id)), false); }
            case 2 -> { w.spawnParticles(ParticleTypes.SOUL_FIRE_FLAME, p.getX(), p.getY()+2, p.getZ(), 120, 6, 3, 6, .03); if(OverworldPlus.EXPANSION_CREATURE!=null){for(int i=0;i<3;i++){var e=new ExpansionCreatureEntity(OverworldPlus.EXPANSION_CREATURE,w);e.configure(id,ExpansionProfiles.CREATURES.get(id)[Math.floorMod(p.getBlockX()+p.getBlockZ()+i,20)]);e.refreshPositionAndAngles(p.getX()+3+i*2,p.getY()+1,p.getZ()+2,0,0);w.spawnEntity(e);}} p.sendMessage(Text.literal("§7WORLD EVENT: §fThe dead stir nearby."), false); }
            case 3 -> { w.spawnParticles(ParticleTypes.END_ROD, p.getX(), p.getY()+2, p.getZ(), 140, 7, 4, 7, .04); p.sendMessage(Text.literal("§dWORLD EVENT: §fA rare crystal bloom has appeared."), false); }
            case 4 -> { w.spawnParticles(ParticleTypes.DRAGON_BREATH, p.getX(), p.getY()+2, p.getZ(), 100, 6, 3, 6, .02); if(OverworldPlus.EXPANSION_CREATURE!=null){var e=new ExpansionCreatureEntity(OverworldPlus.EXPANSION_CREATURE,w);e.configure(id,ExpansionProfiles.CREATURES.get(id)[Math.floorMod(p.getBlockX(),20)]);e.refreshPositionAndAngles(p.getX()+1,p.getY()+1,p.getZ()+1,0,0);w.spawnEntity(e);} p.sendMessage(Text.literal("§5WORLD EVENT: §fA dimensional rift opens."), false); }
            case 5 -> { p.addStatusEffect(new StatusEffectInstance(StatusEffects.HERO_OF_THE_VILLAGE, 600, 0)); p.sendMessage(Text.literal("§aWORLD EVENT: §fA nearby settlement calls for heroes."), false); }
            case 6 -> { p.addStatusEffect(new StatusEffectInstance(StatusEffects.DARKNESS, 100, 0)); p.sendMessage(Text.literal("§8WORLD EVENT: §fAn eclipse swallows the light."), false); }
            default -> { p.addStatusEffect(new StatusEffectInstance(StatusEffects.HASTE, 500, 1)); p.sendMessage(Text.literal("§6WORLD EVENT: §fAncient energy surges through the land."), false); }
        }
    }

    private static void grantExplorationMemory(ServerPlayerEntity p, String id) {
        String tag = "op_seen_" + id;
        if (!p.getCommandTags().contains(tag)) {
            p.addCommandTag(tag);
            p.sendMessage(Text.literal("§eDiscovery recorded: §f" + pretty(id)), false);
        }
    }

    private static boolean nearBeacon(ServerWorld w, BlockPos pos) {
        for (BlockPos q : BlockPos.iterateOutwards(pos, 10, 6, 10)) if (w.getBlockState(q).isOf(RpgItems.WORLD_BEACON)) return true;
        return false;
    }
    public static void onBossDefeated(ServerPlayerEntity p, String worldId) {
        if (p == null) return;
        p.addCommandTag("op_boss_" + worldId);
        clearPrefix(p, "op_faction_");
        p.addCommandTag("op_faction_" + WORLD_FACTION.getOrDefault(worldId, "free_hunters") + "_rep_10");
        p.sendMessage(Text.literal("§6Boss defeated! §7Your actions changed the reputation of the world."), false);
    }
    public static String classOf(PlayerEntity p) { for (String c : CLASSES) if (p.getCommandTags().contains("op_class_" + c)) return c; p.addCommandTag("op_class_warrior"); return "warrior"; }
    public static String factionOf(PlayerEntity p) { for (String f : FACTIONS) for (String tag : p.getCommandTags()) if (tag.startsWith("op_faction_" + f + "_")) return f; return "free_hunters"; }
    private static void clearPrefix(PlayerEntity p, String prefix) { for (String tag : new HashSet<>(p.getCommandTags())) if (tag.startsWith(prefix)) p.removeCommandTag(tag); }
    private static int indexOf(String[] a, String s) { for (int i=0;i<a.length;i++) if (a[i].equals(s)) return i; return -1; }
    private static String pretty(String s) { StringBuilder b=new StringBuilder(); for(String x:s.split("_")){if(x.isEmpty())continue;b.append(Character.toUpperCase(x.charAt(0))).append(x.substring(1)).append(' ');}return b.toString().trim(); }
    private OverworldPlusRpgSystems() {}
}
