package com.overworldplus.expansion;
import com.overworldplus.OverworldPlus;
import net.minecraft.item.*; import net.minecraft.registry.*; import net.minecraft.util.Identifier; import java.util.*;
public final class ExpansionItems { public static final Map<String,Item> RELICS=new LinkedHashMap<>(); static { for(String w:ExpansionProfiles.WORLDS){String id=w+"_relic"; RELICS.put(w,Registry.register(Registries.ITEM,Identifier.of(OverworldPlus.MOD_ID,id),new Item(new Item.Settings().maxCount(16))));}} public static void register(){} private ExpansionItems(){} }