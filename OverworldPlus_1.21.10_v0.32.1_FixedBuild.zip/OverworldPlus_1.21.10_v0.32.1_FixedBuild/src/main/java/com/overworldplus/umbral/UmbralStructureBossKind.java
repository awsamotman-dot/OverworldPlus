package com.overworldplus.umbral;
public enum UmbralStructureBossKind {
VILLAGE_REAPER("village_reaper","Village Reaper"),KINGDOM_WRAITH("kingdom_wraith","Kingdom Wraith"),TOWER_OVERSEER("tower_overseer","Tower Overseer"),TEMPLE_KEEPER("temple_keeper","Temple Keeper"),FORTRESS_GUARDIAN("fortress_guardian","Fortress Guardian"),SHRINE_WARDEN("shrine_warden","Shrine Warden"),CASTLE_LORD("castle_lord","Castle Lord"),MOON_PRIESTESS("moon_priestess","Moon Priestess"),MINE_COLOSSUS("mine_colossus","Mine Colossus"),TREE_WARDEN("tree_warden","Tree Warden"),ARCHIVE_HORROR("archive_horror","Archive Horror"),OBSERVATORY_SENTINEL("observatory_sentinel","Observatory Sentinel");
public final String id,name; UmbralStructureBossKind(String id,String name){this.id=id;this.name=name;}
}