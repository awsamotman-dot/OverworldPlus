package com.overworldplus.umbral;

import com.overworldplus.OverworldPlus;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.state.StateManager;
import net.minecraft.state.property.BooleanProperty;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Identifier;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

import java.util.Set;

public class AbyssalCrystalGateBlock extends Block {
    public static final BooleanProperty AWAKENED = BooleanProperty.of("awakened");
    public static final BooleanProperty OPEN = BooleanProperty.of("open");

    public AbyssalCrystalGateBlock() {
        super(Settings.copy(Blocks.REINFORCED_DEEPSLATE).strength(100, 1200).luminance(state -> state.get(OPEN) ? 15 : state.get(AWAKENED) ? 12 : 8));
        setDefaultState(getStateManager().getDefaultState().with(AWAKENED, false).with(OPEN, false));
    }

    @Override
    protected void appendProperties(StateManager.Builder<Block, BlockState> builder) {
        builder.add(AWAKENED, OPEN);
    }

    @Override
    protected ActionResult onUse(BlockState state, World world, BlockPos pos, PlayerEntity player, BlockHitResult hit) {
        if (world.isClient) return ActionResult.SUCCESS;
        if (!(player instanceof ServerPlayerEntity sp) || world.getServer() == null) return ActionResult.SUCCESS;
        ServerWorld sw = (ServerWorld) world;

        if (state.get(OPEN)) {
            enterCrystalAbyss(sw, sp);
            return ActionResult.SUCCESS;
        }

        int missing = 0;
        for (String id : UmbralItems.SHARDS.keySet()) {
            if (!sp.getInventory().containsAny(stack -> stack.isOf(UmbralItems.SHARDS.get(id)))) missing++;
        }
        if (missing > 0 && !sp.isCreative()) {
            sp.sendMessage(Text.literal("§5The Abyssal Crystal Gate rejects you. §dMissing Abyssal Shards: " + missing + "/7"), true);
            sp.sendMessage(Text.literal("§8Seven shards: Wild, Wraith, Crystal, Moon, Blood, Shadow and Crown."), false);
            return ActionResult.SUCCESS;
        }

        if (!state.get(AWAKENED)) {
            spawnWarden(sw, pos, sp);
            sw.setBlockState(pos, state.with(AWAKENED, true), Block.NOTIFY_ALL);
            sp.sendMessage(Text.literal("§dTHE PRISMATIC AWAKENING"), false);
            sp.sendMessage(Text.literal("§5The Crystal Warden has awakened. Defeat it to unlock the gate."), true);
            return ActionResult.SUCCESS;
        }

        sp.sendMessage(Text.literal("§dThe Abyssal Crystal Gate is awakened, but the Crystal Warden still holds its seal."), true);
        return ActionResult.SUCCESS;
    }

    private static void spawnWarden(ServerWorld world, BlockPos gate, ServerPlayerEntity player) {
        var existing = world.getEntitiesByType(OverworldPlus.CRYSTAL_WARDEN,
                e -> e.squaredDistanceTo(gate.toCenterPos()) < 900);
        if (!existing.isEmpty()) {
            player.sendMessage(Text.literal("§dThe Crystal Warden is already awake."), true);
            return;
        }
        var boss = new CrystalWardenEntity(OverworldPlus.CRYSTAL_WARDEN, world);
        boss.setGatePos(gate);
        boss.refreshPositionAndAngles(gate.getX() + .5, gate.getY() + 1, gate.getZ() + 5.5, 0, 0);
        world.spawnEntity(boss);
    }

    public static void unlock(ServerWorld world, BlockPos gate) {
        BlockState state = world.getBlockState(gate);
        if (state.isOf(OverworldPlus.ABYSSAL_CRYSTAL_GATE)) {
            for(int dx=-3;dx<=3;dx++) for(int dy=-1;dy<=7;dy++){BlockPos q=gate.add(dx,dy,0);BlockState qs=world.getBlockState(q);if(qs.isOf(OverworldPlus.ABYSSAL_CRYSTAL_GATE)) world.setBlockState(q,qs.with(AWAKENED,true).with(OPEN,true),Block.NOTIFY_ALL);}
            world.setBlockState(gate, state.with(AWAKENED, true).with(OPEN, true), Block.NOTIFY_ALL);
            world.playSound(null, gate, UmbralSounds.gate, net.minecraft.sound.SoundCategory.BLOCKS, 5.0f, 0.8f);
            for (int i = 0; i < 48; i++) {
                double a = i * Math.PI * 2.0 / 48.0;
                double r = 2.0 + (i % 5) * .7;
                world.spawnParticles(net.minecraft.particle.ParticleTypes.END_ROD,
                        gate.getX() + .5 + Math.cos(a) * r,
                        gate.getY() + .4 + (i % 9) * .25,
                        gate.getZ() + .5 + Math.sin(a) * r,
                        1, 0, 0, 0, 0);
            }
        }
    }

    private static void enterCrystalAbyss(ServerWorld source, ServerPlayerEntity player) {
        ServerWorld target = source.getServer().getWorld(
                RegistryKey.of(RegistryKeys.WORLD, Identifier.of(OverworldPlus.MOD_ID, "crystal_abyss")));
        if (target == null) {
            player.sendMessage(Text.literal("§cCrystal Abyss is not available on this server."), true);
            return;
        }
        if (!player.isCreative()) {
            for (String id : UmbralItems.SHARDS.keySet()) {
                ItemStack shard = firstStack(player, UmbralItems.SHARDS.get(id));
                if (!shard.isEmpty()) shard.decrement(1);
            }
        }
        player.sendMessage(Text.literal("§bThe Prismatic Awakening pulls you into the Crystal Abyss..."), false);
        player.teleport(target, .5, 120, .5, Set.of(), player.getYaw(), player.getPitch(), true);
        target.spawnParticles(net.minecraft.particle.ParticleTypes.END_ROD, .5, 121, .5, 80, 2, 4, 2, .08);
    }

    private static ItemStack firstStack(ServerPlayerEntity player, net.minecraft.item.Item item) {
        for (ItemStack stack : player.getInventory().main) if (stack.isOf(item)) return stack;
        for (ItemStack stack : player.getInventory().offHand) if (stack.isOf(item)) return stack;
        return ItemStack.EMPTY;
    }
}
