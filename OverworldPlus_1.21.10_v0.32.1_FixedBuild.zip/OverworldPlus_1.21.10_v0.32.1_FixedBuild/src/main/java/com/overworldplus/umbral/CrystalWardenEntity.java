package com.overworldplus.umbral;

import net.minecraft.entity.*;
import net.minecraft.entity.ai.goal.*;
import net.minecraft.entity.attribute.*;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.effect.*;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class CrystalWardenEntity extends HostileEntity {
    private BlockPos gatePos = BlockPos.ORIGIN;
    private int phase = 1;

    public CrystalWardenEntity(EntityType<? extends CrystalWardenEntity> t, World w) {
        super(t, w);
        setPersistent();
        experiencePoints = 250;
    }

    public static DefaultAttributeContainer.Builder attributes() {
        return HostileEntity.createHostileAttributes()
                .add(EntityAttributes.MAX_HEALTH, 320)
                .add(EntityAttributes.ATTACK_DAMAGE, 22)
                .add(EntityAttributes.ARMOR, 15)
                .add(EntityAttributes.MOVEMENT_SPEED, .28)
                .add(EntityAttributes.FOLLOW_RANGE, 64);
    }

    @Override protected void initGoals() {
        goalSelector.add(2, new MeleeAttackGoal(this, 1.0, true));
        goalSelector.add(7, new LookAtEntityGoal(this, PlayerEntity.class, 30));
        targetSelector.add(1, new ActiveTargetGoal<>(this, PlayerEntity.class, true));
    }

    @Override public Text getDisplayName() { return Text.literal("Crystal Warden"); }
    public void setGatePos(BlockPos p) { gatePos = p.toImmutable(); }
    public int getPhase() { return phase; }

    @Override protected void mobTick() {
        super.mobTick();
        if (getHealth() < getMaxHealth() * .5f) phase = 2;
        if (getHealth() < getMaxHealth() * .25f) phase = 3;
        PlayerEntity p = getTarget();
        if (!getWorld().isClient && p != null) {
            if (age % 50 == 0) {
                p.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 50, 2));
                p.damage(getWorld().getDamageSources().magic(), phase >= 3 ? 16 : 12);
            }
            if (age % (phase == 3 ? 20 : 35) == 0) {
                for (int i = 0; i < 12 + phase * 6; i++) {
                    getWorld().addParticle(ParticleTypes.END_ROD,
                            getX() + (getRandom().nextDouble() - .5) * 4,
                            getY() + 1 + getRandom().nextDouble() * 3,
                            getZ() + (getRandom().nextDouble() - .5) * 4, 0, .04, 0);
                }
            }
        }
    }

    @Override public void onDeath(DamageSource source) {
        if (!getWorld().isClient && getWorld() instanceof net.minecraft.server.world.ServerWorld sw) {
            AbyssalCrystalGateBlock.unlock(sw, gatePos);
            for (int i = 0; i < 80; i++) {
                sw.spawnParticles(ParticleTypes.END_ROD, getX(), getY() + 1, getZ(), 1,
                        (getRandom().nextDouble() - .5) * 5, getRandom().nextDouble() * 4,
                        (getRandom().nextDouble() - .5) * 5, .08);
            }
        }
        super.onDeath(source);
    }

    @Override public void writeCustomDataToNbt(NbtCompound n) {
        super.writeCustomDataToNbt(n);
        n.putInt("GateX", gatePos.getX());
        n.putInt("GateY", gatePos.getY());
        n.putInt("GateZ", gatePos.getZ());
        n.putInt("Phase", phase);
    }

    @Override public void readCustomDataFromNbt(NbtCompound n) {
        super.readCustomDataFromNbt(n);
        gatePos = new BlockPos(n.getInt("GateX"), n.getInt("GateY"), n.getInt("GateZ"));
        phase = n.getInt("Phase");
    }
}
