package com.overworldplus.umbral;
public enum UmbralStructureKind {
SHADOW_VILLAGE("shadow_village","Shadow Village"),ABANDONED_KINGDOM("abandoned_kingdom","Abandoned Kingdom"),WRAITH_TOWER("wraith_tower","Wraith Tower"),UMBRAL_TEMPLE("umbral_temple","Umbral Temple"),BLACKWOOD_FORTRESS("blackwood_fortress","Blackwood Fortress"),CORRUPTED_SHRINE("corrupted_shrine","Corrupted Shrine"),GHOST_CASTLE("ghost_castle","Ghost Castle"),MOON_TEMPLE("moon_temple","Moon Temple"),SHADOW_MINE("shadow_mine","Shadow Mine"),ANCIENT_TREE_CITY("ancient_tree_city","Ancient Tree City"),VOIDROOT_ARCHIVE("voidroot_archive","Voidroot Archive"),ECLIPSE_OBSERVATORY("eclipse_observatory","Eclipse Observatory");
public final String id,name; UmbralStructureKind(String id,String name){this.id=id;this.name=name;}
}