package com.overworldplus.frostveil;

import com.overworldplus.OverworldPlus;
import net.minecraft.entity.*;import net.minecraft.entity.ai.goal.*;import net.minecraft.entity.attribute.*;import net.minecraft.entity.boss.ServerBossBar;import net.minecraft.entity.damage.DamageSource;import net.minecraft.entity.effect.*;import net.minecraft.entity.mob.HostileEntity;import net.minecraft.entity.player.PlayerEntity;import net.minecraft.item.ItemStack;import net.minecraft.server.world.ServerWorld;import net.minecraft.sound.SoundCategory;import net.minecraft.text.Text;import net.minecraft.util.math.*;import net.minecraft.world.World;

public class FrostveilBossEntity extends HostileEntity {
 private final FrostveilBossKind kind; private final ServerBossBar bar; private int cooldown=40,phase=1,skill=0,skillTimer=0; private boolean enraged=false;
 public FrostveilBossEntity(EntityType<? extends FrostveilBossEntity> type,World world,FrostveilBossKind kind){super(type,world);this.kind=kind;setPersistent();experiencePoints=1000;bar=new ServerBossBar(Text.literal(kind.title),ServerBossBar.Color.BLUE,ServerBossBar.Style.NOTCHED_20);}
 public FrostveilBossKind getKind(){return kind;} public int getSkill(){return skill;} public int getPhase(){return phase;}
 public static DefaultAttributeContainer.Builder createAttributes(){return HostileEntity.createHostileAttributes().add(EntityAttributes.MAX_HEALTH,1800).add(EntityAttributes.ATTACK_DAMAGE,34).add(EntityAttributes.ARMOR,24).add(EntityAttributes.ARMOR_TOUGHNESS,16).add(EntityAttributes.KNOCKBACK_RESISTANCE,1).add(EntityAttributes.MOVEMENT_SPEED,.27).add(EntityAttributes.FOLLOW_RANGE,96);}
 @Override protected void initGoals(){goalSelector.add(2,new MeleeAttackGoal(this,1.1,false));goalSelector.add(8,new LookAtEntityGoal(this,PlayerEntity.class,48));targetSelector.add(1,new RevengeGoal(this));targetSelector.add(2,new ActiveTargetGoal<>(this,PlayerEntity.class,true));}
 @Override protected void mobTick(){super.mobTick();if(getWorld().isClient)return;if(cooldown>0)cooldown--;if(skillTimer>0)skillTimer--;updatePhase();bar.setPercent(Math.max(0,getHealth()/getMaxHealth()));var t=getTarget();if(t!=null&&t.isAlive()&&cooldown<=0){useSkill(t);cooldown=Math.max(24,60-phase*10);}}
 private void updatePhase(){float r=getHealth()/getMaxHealth();int p=r<=.25?3:r<=.60?2:1;if(p!=phase){phase=p;skill=99;skillTimer=28;bar.setName(Text.literal(kind.title+" — Phase "+phase));if(p==3)enraged=true;}}
 private void useSkill(LivingEntity t){skill=(skill+1)%5;skillTimer=24;double d=squaredDistanceTo(t);switch(kind){
 case FROZEN_KING -> {if(skill==0)area(t,5,12,StatusEffects.SLOWNESS,80);else if(skill==1)leap(t,1.3);else if(skill==2)summonFrost(t);else if(skill==3)iceNova(t);else line(t,14);}
 case HOWLING_ALPHA -> {if(skill==0)leap(t,1.8);else if(skill==1)roar(t);else if(skill==2)area(t,7,14,StatusEffects.WEAKNESS,80);else if(skill==3)summonFrost(t);else charge(t);}
 case CRYSTAL_SOVEREIGN -> {if(skill==0)crystalBeam(t);else if(skill==1)crystalNova(t);else if(skill==2)summonFrost(t);else if(skill==3)area(t,8,16,StatusEffects.SLOWNESS,100);else shield();}
 case ABYSSAL_LEVIATHAN -> {if(skill==0)leap(t,1.6);else if(skill==1)area(t,10,18,StatusEffects.SLOWNESS,100);else if(skill==2)iceNova(t);else if(skill==3)summonFrost(t);else charge(t);}
 case DEAD_EMPEROR -> {if(skill==0)summonFrost(t);else if(skill==1)area(t,8,18,StatusEffects.WITHER,80);else if(skill==2)roar(t);else if(skill==3)iceNova(t);else shield();}
 case GLACIER_TITAN -> {if(skill==0)area(t,10,20,StatusEffects.SLOWNESS,100);else if(skill==1)leap(t,1.5);else if(skill==2)iceNova(t);else if(skill==3)charge(t);else roar(t);}
 case ASTRAL_WARDEN -> {if(skill==0)crystalBeam(t);else if(skill==1)leap(t,1.5);else if(skill==2)area(t,9,16,StatusEffects.LEVITATION,50);else if(skill==3)iceNova(t);else shield();}
 case SUBZERO_OVERLORD -> {if(skill==0)charge(t);else if(skill==1)area(t,8,20,StatusEffects.MINING_FATIGUE,100);else if(skill==2)summonFrost(t);else if(skill==3)crystalBeam(t);else roar(t);}
 case NIGHTBORN_QUEEN -> {if(skill==0)teleportNear(t);else if(skill==1)area(t,8,18,StatusEffects.BLINDNESS,80);else if(skill==2)roar(t);else if(skill==3)crystalBeam(t);else summonFrost(t);}
 case FROSTHEART_GUARDIAN -> {if(skill==0)iceNova(t);else if(skill==1)crystalBeam(t);else if(skill==2)area(t,12,24,StatusEffects.SLOWNESS,120);else if(skill==3)summonFrost(t);else leap(t,1.7);}
 }}
 private void area(LivingEntity t,double r,float dmg,StatusEffect e,int dur){getWorld().getOtherEntities(this,getBoundingBox().expand(r),(x)->x instanceof LivingEntity).forEach(x->{((LivingEntity)x).damage(getDamageSources().mobAttack(this),dmg);((LivingEntity)x).addStatusEffect(new StatusEffectInstance(e,dur,phase-1));});}
 private void leap(LivingEntity t,double mult){setVelocity(t.getX()-getX(),.75*mult,t.getZ()-getZ());velocityModified=true;}
 private void charge(LivingEntity t){Vec3d v=t.getPos().subtract(getPos()).normalize().multiply(1.8);setVelocity(v.x,.35,v.z);velocityModified=true;}
 private void line(LivingEntity t,float dmg){t.damage(getDamageSources().mobAttack(this),dmg+phase*5);}
 private void crystalBeam(LivingEntity t){t.damage(getDamageSources().mobAttack(this),20+phase*5);t.addStatusEffect(new StatusEffectInstance(StatusEffects.GLOWING,80,0));}
 private void crystalNova(LivingEntity t){area(t,6+phase*2,18+phase*3,StatusEffects.SLOWNESS,80);}
 private void iceNova(LivingEntity t){area(t,7+phase*2,20+phase*4,StatusEffects.SLOWNESS,60);}
 private void roar(LivingEntity t){area(t,9,16+phase*3,StatusEffects.WEAKNESS,100);}
 private void summonFrost(LivingEntity t){if(getWorld() instanceof ServerWorld sw){FrostveilMinionEntity m=new FrostveilMinionEntity(OverworldPlus.FROSTVEIL_MINION,sw);m.refreshPositionAndAngles(getX()+random.nextGaussian()*3,getY(),getZ()+random.nextGaussian()*3,getYaw(),0);sw.spawnEntity(m);}}
 private void shield(){heal(80+phase*30);skill=98;}
 private void teleportNear(LivingEntity t){requestTeleport(t.getX()+random.nextInt(9)-4,t.getY(),t.getZ()+random.nextInt(9)-4,true);}
 @Override public boolean damage(DamageSource source,float amount){if(skillTimer>0&&phase>1)return false;return super.damage(source,amount);}
 @Override protected void dropLoot(DamageSource source,boolean causedByPlayer){super.dropLoot(source,causedByPlayer);if(!(getWorld() instanceof ServerWorld sw))return; if(kind==FrostveilBossKind.FROZEN_KING)drop(new ItemStack(FrostveilItems.FROST_KING_STONE)); if(kind==FrostveilBossKind.CRYSTAL_SOVEREIGN)drop(new ItemStack(FrostveilItems.CRYSTAL_STONE)); if(kind==FrostveilBossKind.DEAD_EMPEROR)drop(new ItemStack(FrostveilItems.SOULFROST_STONE)); if(kind==FrostveilBossKind.ASTRAL_WARDEN)drop(new ItemStack(FrostveilItems.ASTRAL_STONE)); if(kind==FrostveilBossKind.NIGHTBORN_QUEEN)drop(new ItemStack(FrostveilItems.NIGHTSTONE)); if(kind==FrostveilBossKind.FROSTHEART_GUARDIAN)drop(new ItemStack(FrostveilItems.FROSTHEART_STONE)); drop(new ItemStack(switch(kind){case FROZEN_KING->FrostveilItems.FROZEN_KING_BLADE;case HOWLING_ALPHA->FrostveilItems.HOWLING_ALPHA_BLADE;case CRYSTAL_SOVEREIGN->FrostveilItems.CRYSTAL_SOVEREIGN_BLADE;case ABYSSAL_LEVIATHAN->FrostveilItems.ABYSSAL_LEVIATHAN_BLADE;case DEAD_EMPEROR->FrostveilItems.DEAD_EMPEROR_BLADE;case GLACIER_TITAN->FrostveilItems.GLACIER_TITAN_BLADE;case ASTRAL_WARDEN->FrostveilItems.ASTRAL_WARDEN_BLADE;case SUBZERO_OVERLORD->FrostveilItems.SUBZERO_OVERLORD_BLADE;case NIGHTBORN_QUEEN->FrostveilItems.NIGHTBORN_QUEEN_BLADE;case FROSTHEART_GUARDIAN->FrostveilItems.FROSTHEART_GUARDIAN_BLADE;}));}
}
