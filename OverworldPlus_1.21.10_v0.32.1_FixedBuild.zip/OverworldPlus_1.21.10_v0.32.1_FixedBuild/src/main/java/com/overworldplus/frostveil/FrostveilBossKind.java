package com.overworldplus.frostveil;
public enum FrostveilBossKind {
 FROZEN_KING("frozen_king","The Frozen King"), HOWLING_ALPHA("howling_alpha","The Howling Alpha"), CRYSTAL_SOVEREIGN("crystal_sovereign","The Crystal Sovereign"), ABYSSAL_LEVIATHAN("abyssal_leviathan","The Abyssal Leviathan"), DEAD_EMPEROR("dead_emperor","The Dead Emperor"), GLACIER_TITAN("glacier_titan","The Glacier Titan"), ASTRAL_WARDEN("astral_warden","The Astral Warden"), SUBZERO_OVERLORD("subzero_overlord","The Subzero Overlord"), NIGHTBORN_QUEEN("nightborn_queen","The Nightborn Queen"), FROSTHEART_GUARDIAN("frostheart_guardian","The Frostheart Guardian");
 public final String id,title; FrostveilBossKind(String id,String title){this.id=id;this.title=title;}
}
