package com.overworldplus.frostveil;

import net.minecraft.block.*;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.state.StateManager;
import net.minecraft.state.property.IntProperty;
import net.minecraft.text.Text;
import net.minecraft.util.*;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.network.packet.s2c.play.PositionFlag;
import net.minecraft.world.World;
import java.util.Set;

public class FrostveilWorldGateBlock extends Block {
 public static final IntProperty STONES=IntProperty.of("stones",0,6);
 private static final net.minecraft.item.Item[] REQUIRED={FrostveilItems.FROST_KING_STONE,FrostveilItems.CRYSTAL_STONE,FrostveilItems.SOULFROST_STONE,FrostveilItems.ASTRAL_STONE,FrostveilItems.NIGHTSTONE,FrostveilItems.FROSTHEART_STONE};
 public FrostveilWorldGateBlock(){super(Settings.copy(Blocks.OBSIDIAN).strength(60f,1200f).luminance(s->Math.min(15,4+s.get(STONES))));setDefaultState(getStateManager().getDefaultState().with(STONES,0));}
 @Override protected void appendProperties(StateManager.Builder<Block,BlockState> b){b.add(STONES);}
 @Override protected ActionResult onUse(BlockState state,World world,PlayerEntity player,BlockHitResult hit){
  if(world.isClient)return ActionResult.SUCCESS; int n=state.get(STONES);
  if(n>=6){ if(player instanceof net.minecraft.server.network.ServerPlayerEntity sp && world.getServer()!=null){RegistryKey<World> k=RegistryKey.of(RegistryKeys.WORLD,Identifier.of("overworldplus","everdawn")); ServerWorld target=world.getServer().getWorld(k); if(target!=null){sp.teleport(target,0.5,120,0.5,Set.<PositionFlag>of(),sp.getYaw(),sp.getPitch(),true);}} return ActionResult.SUCCESS;}
  ItemStack held=player.getMainHandStack(); if(held.isOf(REQUIRED[n])){if(!player.getAbilities().creativeMode)held.decrement(1);int next=n+1;world.setBlockState(pos,state.with(STONES,next));player.sendMessage(Text.literal(next==6?"§aTHE ANCIENT BLOOM GATE HAS AWAKENED":"§bFROSTVEIL STONE INSERTED: "+next+"/6"),true);return ActionResult.SUCCESS;}
  player.sendMessage(Text.literal("§8The gate awaits the next powerful boss stone."),true);return ActionResult.SUCCESS;
 }
}
