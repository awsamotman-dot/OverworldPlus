package com.overworldplus.frostveil;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerChunkEvents;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.Heightmap;
import net.minecraft.world.World;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.world.biome.Biome;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

/** Procedural Frostveil landmarks/dungeons foundation. Every landmark uses its own block kit. */
public final class FrostveilWorldStructures {
    private static final RegistryKey<World> FROSTVEIL = RegistryKey.of(RegistryKeys.WORLD, Identifier.of("overworldplus", "frostveil"));
    private static final Map<String,String> BIOME_STRUCTURES = new HashMap<>();
    private static final Map<String,String> DUNGEONS = new HashMap<>();
    static {
        BIOME_STRUCTURES.put("frostveil_plains","frostveil_village");
        BIOME_STRUCTURES.put("frozen_evergreen_forest","evergreen_clan_village");
        BIOME_STRUCTURES.put("the_white_peaks","peakbound_settlement");
        BIOME_STRUCTURES.put("endless_blizzard","stormhaven");
        BIOME_STRUCTURES.put("frozen_ocean","ice_mariner_outpost");
        BIOME_STRUCTURES.put("the_frost_kingdom","frost_capital");
        BIOME_STRUCTURES.put("dead_glacier","dead_city");
        BIOME_STRUCTURES.put("crystal_frostlands","crystal_temple");
        BIOME_STRUCTURES.put("the_frozen_depths","underfrost_city");
        BIOME_STRUCTURES.put("the_heart_of_frostveil","heart_temple");
        BIOME_STRUCTURES.put("icebound_wastelands","frost_nomad_camp");
        BIOME_STRUCTURES.put("twilight_tundra","astral_observatory");
        BIOME_STRUCTURES.put("frozen_swamps","mirefolk_village");
        BIOME_STRUCTURES.put("icefall_cliffs","icefall_fortress");
        BIOME_STRUCTURES.put("northern_lights_plateau","aurora_observatory");
        BIOME_STRUCTURES.put("subzero_mines","subzero_mine_complex");
        BIOME_STRUCTURES.put("the_howling_woods","howling_hunter_camp");
        BIOME_STRUCTURES.put("eternal_night","nightborn_ruin");
        BIOME_STRUCTURES.put("the_frostbound_ruins","frostbound_city");
        BIOME_STRUCTURES.put("the_frozen_crown","frozen_crown_citadel");
        DUNGEONS.put("frostveil_village","ancient_tree_dungeon");
        DUNGEONS.put("evergreen_clan_village","ancient_tree_dungeon");
        DUNGEONS.put("peakbound_settlement","ascension");
        DUNGEONS.put("stormhaven","stormvault");
        DUNGEONS.put("ice_mariner_outpost","sunken_palace");
        DUNGEONS.put("frost_capital","royal_tombs");
        DUNGEONS.put("dead_city","black_mausoleum");
        DUNGEONS.put("crystal_temple","crystal_labyrinth");
        DUNGEONS.put("underfrost_city","buried_kingdom");
        DUNGEONS.put("heart_temple","inner_heart");
        DUNGEONS.put("frost_nomad_camp","temple_frozen_sun");
        DUNGEONS.put("astral_observatory","astral_observatory_dungeon");
        DUNGEONS.put("mirefolk_village","drowned_grove");
        DUNGEONS.put("icefall_fortress","icefall_depths");
        DUNGEONS.put("aurora_observatory","astral_observatory_dungeon");
        DUNGEONS.put("subzero_mine_complex","subzero_core");
        DUNGEONS.put("howling_hunter_camp","howling_den");
        DUNGEONS.put("nightborn_ruin","eternal_night_sanctum");
        DUNGEONS.put("frostbound_city","frostbound_crypt");
        DUNGEONS.put("frozen_crown_citadel","frozen_crown_dungeon");
    }
    public static void register(){
        ServerChunkEvents.CHUNK_LOAD.register((world,chunk)-> {
            if(!world.getRegistryKey().equals(FROSTVEIL)) return;
            int cx=chunk.getPos().x, cz=chunk.getPos().z;
            long h=((long)cx*341873128712L)^((long)cz*132897987541L);
            if((h & 127L)!=7L) return;
            int x=(cx<<4)+8, z=(cz<<4)+8;
            BlockPos p=new BlockPos(x, world.getTopY(Heightmap.Type.WORLD_SURFACE,x,z), z);
            String biome=biomePath(world,p);
            String structure=BIOME_STRUCTURES.get(biome);
            if(structure==null) return;
            Block marker=block(structure+"_accent");
            if(world.getBlockState(p).isOf(marker)) return;
            buildSurfaceLandmark(world,p,structure);
            if((Math.abs(h)%9)==0) buildDungeonEntrance(world,p,DUNGEONS.getOrDefault(structure,"frostbound_crypt"));
        });
    }
    private static String biomePath(ServerWorld world,BlockPos p){
        RegistryEntry<Biome> b=world.getBiome(p);
        Optional<RegistryKey<Biome>> key=b.getKey();
        return key.map(k->k.getValue().getPath()).orElse("");
    }
    private static Block block(String id){
        Block b=FrostveilBlocks.ALL.get(id);
        if(b==null) b=FrostveilBlocks.ALL.get("frostveil_plains_stone");
        return b;
    }
    private static void put(ServerWorld w,BlockPos p,String id){w.setBlockState(p,block(id).getDefaultState());}
    private static void cube(ServerWorld w,BlockPos c,int rx,int ry,int rz,String id){
        for(int x=-rx;x<=rx;x++)for(int y=0;y<=ry;y++)for(int z=-rz;z<=rz;z++)put(w,c.add(x,y,z),id);
    }
    private static void shell(ServerWorld w,BlockPos c,int rx,int ry,int rz,String id,String accent){
        for(int x=-rx;x<=rx;x++)for(int y=0;y<=ry;y++)for(int z=-rz;z<=rz;z++){
            if(x==-rx||x==rx||z==-rz||z==rz||y==0||y==ry) put(w,c.add(x,y,z),y==ry?accent:id);
        }
    }
    private static void buildSurfaceLandmark(ServerWorld w,BlockPos p,String id){
        BlockPos c=p.down();
        shell(w,c,5,4,5,id+"_stone",id+"_accent");
        shell(w,c.add(0,4,0),3,5,3,id+"_bricks",id+"_tiles");
        for(int y=0;y<9;y++){put(w,c.add(-3,y,-3),id+"_pillar");put(w,c.add(3,y,-3),id+"_pillar");put(w,c.add(-3,y,3),id+"_pillar");put(w,c.add(3,y,3),id+"_pillar");}
        put(w,p,id+"_accent");
    }
    private static void buildDungeonEntrance(ServerWorld w,BlockPos p,String id){
        BlockPos d=p.down(4);
        shell(w,d,4,2,4,id+"_stone",id+"_seal");
        for(int y=1;y<=8;y++){put(w,d.down(y).add(-2,0,-2),id+"_bricks");put(w,d.down(y).add(2,0,-2),id+"_bricks");}
        put(w,d.down(8),id+"_seal");
    }
    private FrostveilWorldStructures(){}
}
