package com.overworldplus.frostveil;

import com.overworldplus.OverworldPlus;
import net.minecraft.item.*;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;
import java.util.LinkedHashMap;
import java.util.Map;

public final class FrostveilItems {
 public static final Map<String,Item> ORES=new LinkedHashMap<>();
 public static final Map<String,Item> INGOTS=new LinkedHashMap<>();
 public static final Map<String,Item> SWORDS=new LinkedHashMap<>();
 public static final Map<String,Item> ARMOR=new LinkedHashMap<>();
 private static Item reg(String id, Item item){return Registry.register(Registries.ITEM, Identifier.of(OverworldPlus.MOD_ID,id),item);}
 public static final Item FROSTITE_INGOT=reg("frostite_ingot",new Item(new Item.Settings()));
 public static final Item FROSTITE_SWORD=reg("frostite_sword",new SwordItem(ToolMaterial.NETHERITE,7.0f,-2.4f,new Item.Settings().maxCount(1)));
 public static final Item FROSTWOOD_INGOT=reg("frostwood_ingot",new Item(new Item.Settings()));
 public static final Item FROSTWOOD_SWORD=reg("frostwood_sword",new SwordItem(ToolMaterial.NETHERITE,7.0f,-2.4f,new Item.Settings().maxCount(1)));
 public static final Item SKYIRON_INGOT=reg("skyiron_ingot",new Item(new Item.Settings()));
 public static final Item SKYIRON_SWORD=reg("skyiron_sword",new SwordItem(ToolMaterial.NETHERITE,7.0f,-2.4f,new Item.Settings().maxCount(1)));
 public static final Item STORMITE_INGOT=reg("stormite_ingot",new Item(new Item.Settings()));
 public static final Item STORMITE_SWORD=reg("stormite_sword",new SwordItem(ToolMaterial.NETHERITE,7.0f,-2.4f,new Item.Settings().maxCount(1)));
 public static final Item DEEPICE_INGOT=reg("deepice_ingot",new Item(new Item.Settings()));
 public static final Item DEEPICE_SWORD=reg("deepice_sword",new SwordItem(ToolMaterial.NETHERITE,7.0f,-2.4f,new Item.Settings().maxCount(1)));
 public static final Item ROYALSTEEL_INGOT=reg("royalsteel_ingot",new Item(new Item.Settings()));
 public static final Item ROYALSTEEL_SWORD=reg("royalsteel_sword",new SwordItem(ToolMaterial.NETHERITE,7.0f,-2.4f,new Item.Settings().maxCount(1)));
 public static final Item SOULICE_INGOT=reg("soulice_ingot",new Item(new Item.Settings()));
 public static final Item SOULICE_SWORD=reg("soulice_sword",new SwordItem(ToolMaterial.NETHERITE,7.0f,-2.4f,new Item.Settings().maxCount(1)));
 public static final Item LIVINGCRYSTAL_INGOT=reg("livingcrystal_ingot",new Item(new Item.Settings()));
 public static final Item LIVINGCRYSTAL_SWORD=reg("livingcrystal_sword",new SwordItem(ToolMaterial.NETHERITE,7.0f,-2.4f,new Item.Settings().maxCount(1)));
 public static final Item DEEPFROST_INGOT=reg("deepfrost_ingot",new Item(new Item.Settings()));
 public static final Item DEEPFROST_SWORD=reg("deepfrost_sword",new SwordItem(ToolMaterial.NETHERITE,7.0f,-2.4f,new Item.Settings().maxCount(1)));
 public static final Item HEARTCRYSTAL_INGOT=reg("heartcrystal_ingot",new Item(new Item.Settings()));
 public static final Item HEARTCRYSTAL_SWORD=reg("heartcrystal_sword",new SwordItem(ToolMaterial.NETHERITE,7.0f,-2.4f,new Item.Settings().maxCount(1)));
 public static final Item WHITEIRON_INGOT=reg("whiteiron_ingot",new Item(new Item.Settings()));
 public static final Item WHITEIRON_SWORD=reg("whiteiron_sword",new SwordItem(ToolMaterial.NETHERITE,7.0f,-2.4f,new Item.Settings().maxCount(1)));
 public static final Item STARICE_INGOT=reg("starice_ingot",new Item(new Item.Settings()));
 public static final Item STARICE_SWORD=reg("starice_sword",new SwordItem(ToolMaterial.NETHERITE,7.0f,-2.4f,new Item.Settings().maxCount(1)));
 public static final Item BOGCRYSTAL_INGOT=reg("bogcrystal_ingot",new Item(new Item.Settings()));
 public static final Item BOGCRYSTAL_SWORD=reg("bogcrystal_sword",new SwordItem(ToolMaterial.NETHERITE,7.0f,-2.4f,new Item.Settings().maxCount(1)));
 public static final Item GLACIERSTEEL_INGOT=reg("glaciersteel_ingot",new Item(new Item.Settings()));
 public static final Item GLACIERSTEEL_SWORD=reg("glaciersteel_sword",new SwordItem(ToolMaterial.NETHERITE,7.0f,-2.4f,new Item.Settings().maxCount(1)));
 public static final Item AURORITE_INGOT=reg("aurorite_ingot",new Item(new Item.Settings()));
 public static final Item AURORITE_SWORD=reg("aurorite_sword",new SwordItem(ToolMaterial.NETHERITE,7.0f,-2.4f,new Item.Settings().maxCount(1)));
 public static final Item SUBZERITE_INGOT=reg("subzerite_ingot",new Item(new Item.Settings()));
 public static final Item SUBZERITE_SWORD=reg("subzerite_sword",new SwordItem(ToolMaterial.NETHERITE,7.0f,-2.4f,new Item.Settings().maxCount(1)));
 public static final Item HOWLITE_INGOT=reg("howlite_ingot",new Item(new Item.Settings()));
 public static final Item HOWLITE_SWORD=reg("howlite_sword",new SwordItem(ToolMaterial.NETHERITE,7.0f,-2.4f,new Item.Settings().maxCount(1)));
 public static final Item NIGHTSTEEL_INGOT=reg("nightsteel_ingot",new Item(new Item.Settings()));
 public static final Item NIGHTSTEEL_SWORD=reg("nightsteel_sword",new SwordItem(ToolMaterial.NETHERITE,7.0f,-2.4f,new Item.Settings().maxCount(1)));
 public static final Item RUINSTEEL_INGOT=reg("ruinsteel_ingot",new Item(new Item.Settings()));
 public static final Item RUINSTEEL_SWORD=reg("ruinsteel_sword",new SwordItem(ToolMaterial.NETHERITE,7.0f,-2.4f,new Item.Settings().maxCount(1)));
 public static final Item CROWNITE_INGOT=reg("crownite_ingot",new Item(new Item.Settings()));
 public static final Item CROWNITE_SWORD=reg("crownite_sword",new SwordItem(ToolMaterial.NETHERITE,7.0f,-2.4f,new Item.Settings().maxCount(1)));
 public static final Item FROST_KING_STONE=reg("frost_king_stone",new Item(new Item.Settings().maxCount(1)));
 public static final Item CRYSTAL_STONE=reg("crystal_stone",new Item(new Item.Settings().maxCount(1)));
 public static final Item SOULFROST_STONE=reg("soulfrost_stone",new Item(new Item.Settings().maxCount(1)));
 public static final Item ASTRAL_STONE=reg("astral_stone",new Item(new Item.Settings().maxCount(1)));
 public static final Item NIGHTSTONE=reg("nightstone",new Item(new Item.Settings().maxCount(1)));
 public static final Item FROSTHEART_STONE=reg("frostheart_stone",new Item(new Item.Settings().maxCount(1)));
 public static final Item FROZEN_KING_BLADE=reg("frozen_king_blade",new SwordItem(ToolMaterial.NETHERITE,9.0f,-2.5f,new Item.Settings().maxCount(1)));
 public static final Item HOWLING_ALPHA_BLADE=reg("howling_alpha_blade",new SwordItem(ToolMaterial.NETHERITE,9.0f,-2.5f,new Item.Settings().maxCount(1)));
 public static final Item CRYSTAL_SOVEREIGN_BLADE=reg("crystal_sovereign_blade",new SwordItem(ToolMaterial.NETHERITE,9.0f,-2.5f,new Item.Settings().maxCount(1)));
 public static final Item ABYSSAL_LEVIATHAN_BLADE=reg("abyssal_leviathan_blade",new SwordItem(ToolMaterial.NETHERITE,9.0f,-2.5f,new Item.Settings().maxCount(1)));
 public static final Item DEAD_EMPEROR_BLADE=reg("dead_emperor_blade",new SwordItem(ToolMaterial.NETHERITE,9.0f,-2.5f,new Item.Settings().maxCount(1)));
 public static final Item GLACIER_TITAN_BLADE=reg("glacier_titan_blade",new SwordItem(ToolMaterial.NETHERITE,9.0f,-2.5f,new Item.Settings().maxCount(1)));
 public static final Item ASTRAL_WARDEN_BLADE=reg("astral_warden_blade",new SwordItem(ToolMaterial.NETHERITE,9.0f,-2.5f,new Item.Settings().maxCount(1)));
 public static final Item SUBZERO_OVERLORD_BLADE=reg("subzero_overlord_blade",new SwordItem(ToolMaterial.NETHERITE,9.0f,-2.5f,new Item.Settings().maxCount(1)));
 public static final Item NIGHTBORN_QUEEN_BLADE=reg("nightborn_queen_blade",new SwordItem(ToolMaterial.NETHERITE,9.0f,-2.5f,new Item.Settings().maxCount(1)));
 public static final Item FROSTHEART_GUARDIAN_BLADE=reg("frostheart_guardian_blade",new SwordItem(ToolMaterial.NETHERITE,9.0f,-2.5f,new Item.Settings().maxCount(1)));
 public static void register(){}
 private FrostveilItems(){}
}