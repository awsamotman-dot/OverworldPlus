package com.overworldplus;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Item;
import net.minecraft.registry.RegistryKey;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.state.StateManager;
import net.minecraft.state.property.IntProperty;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class AncientGateBlock extends Block {
    public static final IntProperty EYES = IntProperty.of("eyes", 0, 6);
    public AncientGateBlock() { super(Settings.copy(Blocks.OBSIDIAN).strength(50f, 1200f).luminance(s -> s.get(EYES) == 6 ? 15 : 4)); setDefaultState(getStateManager().getDefaultState().with(EYES, 0)); }
    @Override protected void appendProperties(StateManager.Builder<Block, BlockState> builder){ builder.add(EYES); }
    @Override protected ActionResult onUse(BlockState state, World world, BlockPos pos, PlayerEntity player, BlockHitResult hit){
        if(world.isClient) return ActionResult.SUCCESS;
        if(state.get(EYES) >= 6){ player.sendMessage(Text.literal("§5THE ANCIENT GATE IS AWAKENED"), true); return ActionResult.SUCCESS; }
        ItemStack stack=player.getStackInHand(Hand.MAIN_HAND);
        GuardianKind[] kinds=GuardianKind.values();
        for(int i=state.get(EYES); i<kinds.length; i++){
            Item item=ModItems.EYES.get(kinds[i]);
            if(stack.isOf(item)){
                if(!player.getAbilities().creativeMode) stack.decrement(1);
                int next=state.get(EYES)+1;
                world.setBlockState(pos,state.with(EYES,next));
                player.sendMessage(Text.literal(next==6?"§dTHE SIX EYES HAVE AWAKENED":"§7GATE EYE INSERTED: "+next+"/6"), true);
                return ActionResult.SUCCESS;
            }
        }
        player.sendMessage(Text.literal("§8The gate requires the six guardian eyes."), true);
        return ActionResult.SUCCESS;
    }
}
