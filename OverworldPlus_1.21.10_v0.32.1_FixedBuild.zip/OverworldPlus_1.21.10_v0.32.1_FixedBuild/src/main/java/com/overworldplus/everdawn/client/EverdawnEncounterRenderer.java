package com.overworldplus.everdawn.client;
import com.overworldplus.OverworldPlus;
import com.overworldplus.everdawn.EverdawnEncounterEntity;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.MobEntityRenderer;
import net.minecraft.client.render.entity.model.BipedEntityModel;
import net.minecraft.client.render.entity.model.EntityModelLayers;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
public class EverdawnEncounterRenderer extends MobEntityRenderer<EverdawnEncounterEntity,BipedEntityModel<EverdawnEncounterEntity>> {
 public EverdawnEncounterRenderer(EntityRendererFactory.Context ctx){super(ctx,new BipedEntityModel<>(ctx.getPart(EntityModelLayers.ZOMBIE)),.55f);}
 @Override public Identifier getTexture(EverdawnEncounterEntity e){return Identifier.of(OverworldPlus.MOD_ID,"textures/entity/everdawn_creature/"+e.getKind().id+".png");}
 @Override protected void scale(EverdawnEncounterEntity e,MatrixStack m,float d){float s=e.isStructureBoss()?1.65f:1.35f;m.scale(s,s,s);}
}
