package com.overworldplus.everdawn;

import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ActionResult;

public final class EverdawnWeaponAbilities {
 public static void register(){AttackEntityCallback.EVENT.register((player,world,hand,target,hit)->{if(world.isClient)return ActionResult.PASS;ItemStack s=player.getStackInHand(hand);if(!(target instanceof LivingEntity living))return ActionResult.PASS;
  for(var e:EverdawnItems.WEAPONS.entrySet())if(s.isOf(e.getValue())){switch(e.getKey()){
   case "ancient_treant_king"->living.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS,60,1));
   case "blossom_empress"->living.addStatusEffect(new StatusEffectInstance(StatusEffects.POISON,80,1));
   case "mycelian_overlord"->living.addStatusEffect(new StatusEffectInstance(StatusEffects.WEAKNESS,80,1));
   case "emerald_colossus"->living.addStatusEffect(new StatusEffectInstance(StatusEffects.MINING_FATIGUE,70,1));
   case "astral_druid"->living.addStatusEffect(new StatusEffectInstance(StatusEffects.GLOWING,100,0));
   case "fey_queen"->living.addStatusEffect(new StatusEffectInstance(StatusEffects.BLINDNESS,35,0));
   case "wildheart_beast"->player.addStatusEffect(new StatusEffectInstance(StatusEffects.STRENGTH,50,1));
   case "blight_sovereign"->living.addStatusEffect(new StatusEffectInstance(StatusEffects.WITHER,50,0));
   case "forgotten_king_everdawn"->living.addStatusEffect(new StatusEffectInstance(StatusEffects.DARKNESS,45,0));
   case "heart_of_everdawn"->player.addStatusEffect(new StatusEffectInstance(StatusEffects.REGENERATION,60,1));
  }break;}
  return ActionResult.PASS;});}
 private EverdawnWeaponAbilities(){}
}
