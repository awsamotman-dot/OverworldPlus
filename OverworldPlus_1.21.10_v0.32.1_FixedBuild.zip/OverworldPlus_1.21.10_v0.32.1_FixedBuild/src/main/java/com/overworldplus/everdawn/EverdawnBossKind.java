package com.overworldplus.everdawn;
public enum EverdawnBossKind {
 ANCIENT_TREANT_KING("ancient_treant_king","The Ancient Treant King","The Ancientwood"),
 BLOSSOM_EMPRESS("blossom_empress","The Blossom Empress","Blossomwilds"),
 MYCELIAN_OVERLORD("mycelian_overlord","The Mycelian Overlord","The Mycelian Deep"),
 EMERALD_COLOSSUS("emerald_colossus","The Emerald Colossus","Emerald Highlands"),
 ASTRAL_DRUID("astral_druid","The Astral Druid","The Astral Grove"),
 FEY_QUEEN("fey_queen","The Fey Queen","Feywild Gardens"),
 WILDHEART_BEAST("wildheart_beast","The Wildheart Beast","The Wildheart Basin"),
 BLIGHT_SOVEREIGN("blight_sovereign","The Blight Sovereign","The Blighted Forest"),
 FORGOTTEN_KING("forgotten_king_everdawn","The Forgotten King","The Elder Ruins"),
 HEART_OF_EVERDAWN("heart_of_everdawn","The Heart of Everdawn","The Everdawn Heart");
 public final String id,title,biome; EverdawnBossKind(String id,String title,String biome){this.id=id;this.title=title;this.biome=biome;}
}
