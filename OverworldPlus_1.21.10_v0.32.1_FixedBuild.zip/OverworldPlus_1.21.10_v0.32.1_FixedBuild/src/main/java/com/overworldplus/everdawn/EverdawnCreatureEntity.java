package com.overworldplus.everdawn;

import net.minecraft.entity.EntityType;
import net.minecraft.entity.ai.goal.ActiveTargetGoal;
import net.minecraft.entity.ai.goal.LookAtEntityGoal;
import net.minecraft.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.world.World;

public class EverdawnCreatureEntity extends HostileEntity {
 private EverdawnCreatureKind kind;
 private final boolean elite;
 private String encounterName="";
 public EverdawnCreatureEntity(EntityType<? extends EverdawnCreatureEntity> type,World world,EverdawnCreatureKind kind,boolean elite){super(type,world);this.kind=kind;this.elite=elite;setPersistent();experiencePoints=elite?80:18;}
 public EverdawnCreatureKind getKind(){return kind;}
 public void setEncounterName(String name){this.encounterName=name==null?"":name;}
 public String getEncounterName(){return encounterName;}
 public boolean isElite(){return elite;}
 public static DefaultAttributeContainer.Builder attributes(boolean elite){
  return HostileEntity.createHostileAttributes().add(EntityAttributes.MAX_HEALTH,elite?180:28).add(EntityAttributes.ATTACK_DAMAGE,elite?18:6).add(EntityAttributes.MOVEMENT_SPEED,elite?.31:.29).add(EntityAttributes.FOLLOW_RANGE,elite?42:26).add(EntityAttributes.ARMOR,elite?8:2);
 }
 @Override protected void initGoals(){goalSelector.add(2,new MeleeAttackGoal(this,1.15,false));goalSelector.add(7,new LookAtEntityGoal(this,PlayerEntity.class,18));targetSelector.add(1,new ActiveTargetGoal<>(this,PlayerEntity.class,true));}
 @Override public void writeCustomDataToNbt(NbtCompound nbt){super.writeCustomDataToNbt(nbt);nbt.putString("EverdawnKind",kind.id);nbt.putBoolean("EverdawnElite",elite);if(!encounterName.isEmpty())nbt.putString("EncounterName",encounterName);}
 @Override public void readCustomDataFromNbt(NbtCompound nbt){super.readCustomDataFromNbt(nbt);String id=nbt.getString("EverdawnKind");for(EverdawnCreatureKind k:EverdawnCreatureKind.values())if(k.id.equals(id)){kind=k;break;}encounterName=nbt.getString("EncounterName");}
 @Override public Text getDisplayName(){return Text.literal(encounterName.isEmpty()?((elite?"Elite ":"")+kind.name):encounterName);}
 @Override protected void mobTick(){super.mobTick(); if(!elite || world.isClient || getTarget()==null)return; if(age%80==0){var t=getTarget(); switch(kind){
 case BLOSSOM_WITCH->t.addStatusEffect(new net.minecraft.entity.effect.StatusEffectInstance(net.minecraft.entity.effect.StatusEffects.POISON,50,1));
 case SPORE_CRAWLER->t.addStatusEffect(new net.minecraft.entity.effect.StatusEffectInstance(net.minecraft.entity.effect.StatusEffects.WEAKNESS,60,1));
 case EMERALD_GOLEM->t.addStatusEffect(new net.minecraft.entity.effect.StatusEffectInstance(net.minecraft.entity.effect.StatusEffects.MINING_FATIGUE,60,1));
 case RIVER_NYMPH->t.addStatusEffect(new net.minecraft.entity.effect.StatusEffectInstance(net.minecraft.entity.effect.StatusEffects.SLOWNESS,45,1));
 case ASTRAL_WISP->t.addStatusEffect(new net.minecraft.entity.effect.StatusEffectInstance(net.minecraft.entity.effect.StatusEffects.GLOWING,80,0));
 case BLIGHTLING->t.addStatusEffect(new net.minecraft.entity.effect.StatusEffectInstance(net.minecraft.entity.effect.StatusEffects.WITHER,35,0));
 default -> {} } } }
}
