package com.overworldplus.everdawn;

public enum EverdawnCreatureKind {
 MEADOW_STAG("meadow_stag","Dawnstag","everdawn_meadows"),
 ROOTLING("rootling","Rootling","the_ancientwood"),
 BLOSSOM_WITCH("blossom_witch","Blossom Witch","blossomwilds"),
 SPORE_CRAWLER("spore_crawler","Spore Crawler","the_mycelian_deep"),
 EMERALD_GOLEM("emerald_golem","Emerald Golem","emerald_highlands"),
 RIVER_NYMPH("river_nymph","River Nymph","the_everflow"),
 JUNGLE_STALKER("jungle_stalker","Jungle Stalker","verdant_jungle"),
 SPIRIT_DEER("spirit_deer","Spirit Deer","spiritwood"),
 DAWN_SENTINEL("dawn_sentinel","Dawn Sentinel","the_golden_dawnlands"),
 ASTRAL_WISP("astral_wisp","Astral Wisp","the_astral_grove"),
 WILDCLAW("wildclaw","Wildclaw","the_wildheart_basin"),
 MIST_HAG("mist_hag","Mist Hag","mistveil_marshes"),
 RUIN_GUARDIAN("ruin_guardian","Ruin Guardian","the_elder_ruins"),
 WORLDTREE_SPROUT("worldtree_sprout","Worldtree Sprout","the_worldtree_expanse"),
 FEY_HARE("fey_hare","Fey Hare","feywild_gardens"),
 BLIGHTLING("blightling","Blightling","the_blighted_forest"),
 CALDERA_SALAMANDER("caldera_salamander","Caldera Salamander","the_verdant_caldera"),
 SKY_SERAPH("sky_seraph","Sky Seraph","the_skygarden_peaks"),
 FORGOTTEN_HUNTER("forgotten_hunter","Forgotten Hunter","the_forgotten_wilds"),
 HEARTBORN("heartborn","Heartborn","the_everdawn_heart");
 public final String id,name,biome;
 EverdawnCreatureKind(String id,String name,String biome){this.id=id;this.name=name;this.biome=biome;}
}
