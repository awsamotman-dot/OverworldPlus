package com.overworldplus.everdawn;
import com.overworldplus.OverworldPlus;import net.minecraft.item.*;import net.minecraft.item.equipment.*;import net.minecraft.registry.*;import net.minecraft.util.Identifier;import java.util.*;
public final class EverdawnItems {
 public static final Map<String,Item> WEAPONS=new LinkedHashMap<>(),RELICS=new LinkedHashMap<>(),LORE=new LinkedHashMap<>(),MATERIALS=new LinkedHashMap<>();
 private static Item reg(String id,Item i){return Registry.register(Registries.ITEM,Identifier.of(OverworldPlus.MOD_ID,id),i);}
 static {for(EverdawnBossKind k:EverdawnBossKind.values()){WEAPONS.put(k.id,reg(k.id+"_weapon",new SwordItem(ToolMaterial.NETHERITE,10,-2.5f,new Item.Settings().maxCount(1))));RELICS.put(k.id,reg(k.id+"_relic",new Item(new Item.Settings().maxCount(1))));LORE.put(k.id,reg(k.id+"_lore",new Item(new Item.Settings().maxCount(1))));MATERIALS.put(k.id,reg(k.id+"_material",new Item(new Item.Settings().maxCount(64))));}}
 public static final Map<String,Item[]> ARMOR=new LinkedHashMap<>();
 static {for(EverdawnBossKind k:EverdawnBossKind.values()){Item[] a=new Item[4];a[0]=reg(k.id+"_helmet",new ArmorItem(ArmorMaterials.NETHERITE,EquipmentType.HELMET,new Item.Settings().maxCount(1)));a[1]=reg(k.id+"_chestplate",new ArmorItem(ArmorMaterials.NETHERITE,EquipmentType.CHESTPLATE,new Item.Settings().maxCount(1)));a[2]=reg(k.id+"_leggings",new ArmorItem(ArmorMaterials.NETHERITE,EquipmentType.LEGGINGS,new Item.Settings().maxCount(1)));a[3]=reg(k.id+"_boots",new ArmorItem(ArmorMaterials.NETHERITE,EquipmentType.BOOTS,new Item.Settings().maxCount(1)));ARMOR.put(k.id,a);}}
 public static void register(){} private EverdawnItems(){}
}
