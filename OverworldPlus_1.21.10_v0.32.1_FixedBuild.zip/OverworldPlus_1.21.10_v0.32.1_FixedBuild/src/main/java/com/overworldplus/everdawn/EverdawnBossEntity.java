package com.overworldplus.everdawn;
import com.overworldplus.OverworldPlus;import net.minecraft.entity.*;import net.minecraft.entity.ai.goal.*;import net.minecraft.entity.attribute.*;import net.minecraft.entity.boss.ServerBossBar;import net.minecraft.entity.damage.DamageSource;import net.minecraft.entity.effect.*;import net.minecraft.entity.mob.HostileEntity;import net.minecraft.entity.player.PlayerEntity;import net.minecraft.item.ItemStack;import net.minecraft.particle.ParticleTypes;import net.minecraft.server.world.ServerWorld;import net.minecraft.sound.SoundCategory;import net.minecraft.text.Text;import net.minecraft.util.math.Vec3d;import net.minecraft.world.World;
public class EverdawnBossEntity extends HostileEntity {
 private final EverdawnBossKind kind; private final ServerBossBar bar; private int cooldown=35,skill=0,skillTimer=0,phase=1,ambientTimer=0; private boolean weakPoint=false;
 public EverdawnBossEntity(EntityType<? extends EverdawnBossEntity> t,World w,EverdawnBossKind k){super(t,w);kind=k;setPersistent();experiencePoints=1200;bar=new ServerBossBar(Text.literal(k.title),ServerBossBar.Color.GREEN,ServerBossBar.Style.NOTCHED_20);}
 public EverdawnBossKind getKind(){return kind;} public int getPhase(){return phase;} public int getSkill(){return skill;} public boolean isWeakPointOpen(){return weakPoint;} public float getSkillProgress(float tickDelta){return Math.min(1f,skillTimer/30f);}
 public static DefaultAttributeContainer.Builder createAttributes(){return HostileEntity.createHostileAttributes().add(EntityAttributes.MAX_HEALTH,2200).add(EntityAttributes.ATTACK_DAMAGE,38).add(EntityAttributes.ARMOR,26).add(EntityAttributes.ARMOR_TOUGHNESS,18).add(EntityAttributes.KNOCKBACK_RESISTANCE,1).add(EntityAttributes.MOVEMENT_SPEED,.30).add(EntityAttributes.FOLLOW_RANGE,110);}
 @Override protected void initGoals(){goalSelector.add(2,new MeleeAttackGoal(this,1.15,false));goalSelector.add(7,new LookAtEntityGoal(this,PlayerEntity.class,55));targetSelector.add(1,new RevengeGoal(this));targetSelector.add(2,new ActiveTargetGoal<>(this,PlayerEntity.class,true));}
 @Override protected void mobTick(){super.mobTick();if(getWorld().isClient)return;if(cooldown>0)cooldown--;if(skillTimer>0)skillTimer--;else weakPoint=false;if(ambientTimer++>180){ambientTimer=0;getWorld().playSound(null,getBlockPos(),EverdawnBossSounds.ambient(kind),SoundCategory.HOSTILE,2.5f,0.9f+random.nextFloat()*.2f); if(age%600==0)getWorld().playSound(null,getBlockPos(),EverdawnBossSounds.music(kind),SoundCategory.RECORDS,1.8f,1f);}float ratio=getHealth()/getMaxHealth();int np=ratio<=.25?3:ratio<=.60?2:1;if(np!=phase){phase=np;weakPoint=true;skillTimer=36;getWorld().playSound(null,getBlockPos(),EverdawnBossSounds.phase(kind),SoundCategory.HOSTILE,4f,1f);burst(ParticleTypes.END_ROD,90);}bar.setPercent(Math.max(0,getHealth()/getMaxHealth()));bar.setName(Text.literal(kind.title+" — Phase "+phase)); if(getWorld() instanceof ServerWorld sw){for(var pl:sw.getPlayers()){if(pl.squaredDistanceTo(this)<128*128)bar.addPlayer(pl);else bar.removePlayer(pl);}}var target=getTarget();if(target!=null&&target.isAlive()&&cooldown<=0){useSkill(target);cooldown=Math.max(18,48-phase*7);}}
 private void useSkill(LivingEntity t){skill=(skill+1)%6;skillTimer=30;switch(kind){
 case ANCIENT_TREANT_KING -> { switch(skill){case 0->roots(t);case 1->slam(t,16);case 2->rain(t);case 3->summon(t);case 4->expose();default->roar(t);} }
 case BLOSSOM_EMPRESS -> { switch(skill){case 0->petals(t);case 1->poison(t);case 2->teleport(t);case 3->healSelf(90);case 4->expose();default->summon(t);} }
 case MYCELIAN_OVERLORD -> { switch(skill){case 0->spores(t);case 1->roots(t);case 2->slam(t,18);case 3->summon(t);case 4->expose();default->teleport(t);} }
 case EMERALD_COLOSSUS -> { switch(skill){case 0->slam(t,24);case 1->beam(t);case 2->rain(t);case 3->charge(t);case 4->expose();default->roar(t);} }
 case ASTRAL_DRUID -> { switch(skill){case 0->beam(t);case 1->gravity(t);case 2->rain(t);case 3->teleport(t);case 4->expose();default->summon(t);} }
 case FEY_QUEEN -> { switch(skill){case 0->teleport(t);case 1->illusion(t);case 2->petals(t);case 3->curse(t);case 4->expose();default->summon(t);} }
 case WILDHEART_BEAST -> { switch(skill){case 0->charge(t);case 1->roar(t);case 2->summon(t);case 3->slam(t,20);case 4->expose();default->charge(t);} }
 case BLIGHT_SOVEREIGN -> { switch(skill){case 0->poison(t);case 1->roots(t);case 2->blight(t);case 3->summon(t);case 4->expose();default->rain(t);} }
 case FORGOTTEN_KING -> { switch(skill){case 0->slam(t,22);case 1->charge(t);case 2->summon(t);case 3->beam(t);case 4->expose();default->roar(t);} }
 case HEART_OF_EVERDAWN -> { switch(skill){case 0->roots(t);case 1->beam(t);case 2->rain(t);case 3->summon(t);case 4->expose();default->blight(t);} }
 } getWorld().playSound(null,getBlockPos(),skill%2==0?EverdawnBossSounds.attack1(kind):EverdawnBossSounds.attack2(kind),SoundCategory.HOSTILE,2.8f,.8f+random.nextFloat()*.35f);}
 private void expose(){weakPoint=true;skillTimer=36;}
 private void damageArea(double r,float dmg,StatusEffect e,int dur){getWorld().getOtherEntities(this,getBoundingBox().expand(r),x->x instanceof LivingEntity&&x!=this).forEach(x->{x.damage(getDamageSources().mobAttack(this),dmg+phase*3);if(e!=null)((LivingEntity)x).addStatusEffect(new StatusEffectInstance(e,dur,Math.max(0,phase-1)));});burst(ParticleTypes.HAPPY_VILLAGER,50);}
 private void roots(LivingEntity t){damageArea(6+phase*2,13,StatusEffects.SLOWNESS,80);}
 private void slam(LivingEntity t,float dmg){damageArea(7+phase, dmg, null,0);setVelocity(t.getX()-getX(),.45,t.getZ()-getZ());velocityModified=true;}
 private void rain(LivingEntity t){if(getWorld() instanceof ServerWorld sw)for(int i=0;i<18;i++)sw.spawnParticles(ParticleTypes.COMPOSTER,t.getX()+random.nextGaussian()*5,t.getY()+1,t.getZ()+random.nextGaussian()*5,3,.1,.5,.1,.02);damageArea(9,15,StatusEffects.POISON,70);}
 private void spores(LivingEntity t){damageArea(9,12,StatusEffects.POISON,100);}
 private void petals(LivingEntity t){damageArea(8,18,StatusEffects.POISON,60);}
 private void poison(LivingEntity t){damageArea(10,14,StatusEffects.POISON,120);}
 private void beam(LivingEntity t){t.damage(getDamageSources().mobAttack(this),24+phase*6);t.addStatusEffect(new StatusEffectInstance(StatusEffects.GLOWING,100,0));burst(ParticleTypes.END_ROD,35);}
 private void gravity(LivingEntity t){t.addStatusEffect(new StatusEffectInstance(StatusEffects.LEVITATION,45,1));damageArea(7,12,null,0);}
 private void teleport(LivingEntity t){requestTeleport(t.getX()+random.nextInt(13)-6,t.getY(),t.getZ()+random.nextInt(13)-6,true);}
 private void charge(LivingEntity t){Vec3d v=t.getPos().subtract(getPos()).normalize().multiply(2.0+phase*.25);setVelocity(v.x,.35,v.z);velocityModified=true;}
 private void summon(LivingEntity t){if(getWorld() instanceof ServerWorld sw){EverdawnMinionEntity m=new EverdawnMinionEntity(OverworldPlus.EVERDAWN_MINION,sw);m.refreshPositionAndAngles(getX()+random.nextGaussian()*4,getY(),getZ()+random.nextGaussian()*4,getYaw(),0);sw.spawnEntity(m);}}
 private void illusion(LivingEntity t){summon(t);summon(t);}
 private void curse(LivingEntity t){t.addStatusEffect(new StatusEffectInstance(StatusEffects.WITHER,70+phase*20,phase-1));damageArea(5,10,null,0);}
 private void blight(LivingEntity t){damageArea(10,17,StatusEffects.WITHER,100);}
 private void roar(LivingEntity t){damageArea(11,15,StatusEffects.WEAKNESS,100);}
 private void healSelf(float n){heal(n);burst(ParticleTypes.HAPPY_VILLAGER,80);}
 private void burst(net.minecraft.particle.ParticleEffect p,int n){if(getWorld() instanceof ServerWorld sw)sw.spawnParticles(p,getX(),getY()+2,getZ(),n,2,2,2,.08);}
 @Override public boolean damage(DamageSource source,float amount){if(skillTimer>0&&phase>1&&!weakPoint)return super.damage(source,amount*.18f);if(weakPoint)amount*=1.65f;return super.damage(source,amount);}
 @Override protected void dropLoot(DamageSource source,boolean causedByPlayer){super.dropLoot(source,causedByPlayer);if(kind==EverdawnBossKind.HEART_OF_EVERDAWN)drop(new ItemStack(EverdawnProgression.HEART_SIGIL));drop(new ItemStack(EverdawnItems.WEAPONS.get(kind.id)));drop(new ItemStack(EverdawnItems.RELICS.get(kind.id)));drop(new ItemStack(EverdawnItems.LORE.get(kind.id)));drop(new ItemStack(EverdawnItems.MATERIALS.get(kind.id)));Item[] armor=EverdawnItems.ARMOR.get(kind.id);if(armor!=null){drop(new ItemStack(armor[0]));drop(new ItemStack(armor[1]));drop(new ItemStack(armor[2]));drop(new ItemStack(armor[3]));}}
 @Override protected void playHurtSound(DamageSource source){getWorld().playSound(null,getBlockPos(),EverdawnBossSounds.hurt(kind),SoundCategory.HOSTILE,2.5f,1f);}
 @Override public void onDeath(DamageSource source){getWorld().playSound(null,getBlockPos(),EverdawnBossSounds.death(kind),SoundCategory.HOSTILE,5f,1f);super.onDeath(source);}
}
