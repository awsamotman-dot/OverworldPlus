package com.overworldplus.everdawn;

import com.overworldplus.OverworldPlus;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.entity.effect.*;
import net.minecraft.item.*;
import net.minecraft.item.equipment.*;
import net.minecraft.registry.*;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.Identifier;
import java.util.*;

public final class EverdawnWorldItems {
 public static final Map<String,Item> RAW=new LinkedHashMap<>(),INGOTS=new LinkedHashMap<>(),SWORDS=new LinkedHashMap<>();
 public static final Map<String,Item[]> ARMOR=new LinkedHashMap<>();
 public static final Map<String,Item[]> TOOLS=new LinkedHashMap<>();
 private static Item reg(String id,Item i){return Registry.register(Registries.ITEM,Identifier.of(OverworldPlus.MOD_ID,id),i);}
 static {
  RAW.put("verdant",reg("raw_verdant",new Item(new Item.Settings().maxCount(64))));
  INGOTS.put("verdant",reg("verdant_ingot",new Item(new Item.Settings().maxCount(64))));
  SWORDS.put("verdant",reg("verdant_sword",new SwordItem(ToolMaterial.NETHERITE,8,-2.4f,new Item.Settings().maxCount(1))));
  Item[] a=new Item[4]; a[0]=reg("verdant_helmet",new ArmorItem(ArmorMaterials.NETHERITE,EquipmentType.HELMET,new Item.Settings().maxCount(1))); a[1]=reg("verdant_chestplate",new ArmorItem(ArmorMaterials.NETHERITE,EquipmentType.CHESTPLATE,new Item.Settings().maxCount(1))); a[2]=reg("verdant_leggings",new ArmorItem(ArmorMaterials.NETHERITE,EquipmentType.LEGGINGS,new Item.Settings().maxCount(1))); a[3]=reg("verdant_boots",new ArmorItem(ArmorMaterials.NETHERITE,EquipmentType.BOOTS,new Item.Settings().maxCount(1))); ARMOR.put("verdant",a);
  RAW.put("dawnite",reg("raw_dawnite",new Item(new Item.Settings().maxCount(64))));
  INGOTS.put("dawnite",reg("dawnite_ingot",new Item(new Item.Settings().maxCount(64))));
  SWORDS.put("dawnite",reg("dawnite_sword",new SwordItem(ToolMaterial.NETHERITE,8,-2.4f,new Item.Settings().maxCount(1))));
  Item[] a=new Item[4]; a[0]=reg("dawnite_helmet",new ArmorItem(ArmorMaterials.NETHERITE,EquipmentType.HELMET,new Item.Settings().maxCount(1))); a[1]=reg("dawnite_chestplate",new ArmorItem(ArmorMaterials.NETHERITE,EquipmentType.CHESTPLATE,new Item.Settings().maxCount(1))); a[2]=reg("dawnite_leggings",new ArmorItem(ArmorMaterials.NETHERITE,EquipmentType.LEGGINGS,new Item.Settings().maxCount(1))); a[3]=reg("dawnite_boots",new ArmorItem(ArmorMaterials.NETHERITE,EquipmentType.BOOTS,new Item.Settings().maxCount(1))); ARMOR.put("dawnite",a);
  RAW.put("emeraldite",reg("raw_emeraldite",new Item(new Item.Settings().maxCount(64))));
  INGOTS.put("emeraldite",reg("emeraldite_ingot",new Item(new Item.Settings().maxCount(64))));
  SWORDS.put("emeraldite",reg("emeraldite_sword",new SwordItem(ToolMaterial.NETHERITE,8,-2.4f,new Item.Settings().maxCount(1))));
  Item[] a=new Item[4]; a[0]=reg("emeraldite_helmet",new ArmorItem(ArmorMaterials.NETHERITE,EquipmentType.HELMET,new Item.Settings().maxCount(1))); a[1]=reg("emeraldite_chestplate",new ArmorItem(ArmorMaterials.NETHERITE,EquipmentType.CHESTPLATE,new Item.Settings().maxCount(1))); a[2]=reg("emeraldite_leggings",new ArmorItem(ArmorMaterials.NETHERITE,EquipmentType.LEGGINGS,new Item.Settings().maxCount(1))); a[3]=reg("emeraldite_boots",new ArmorItem(ArmorMaterials.NETHERITE,EquipmentType.BOOTS,new Item.Settings().maxCount(1))); ARMOR.put("emeraldite",a);
  RAW.put("astralite",reg("raw_astralite",new Item(new Item.Settings().maxCount(64))));
  INGOTS.put("astralite",reg("astralite_ingot",new Item(new Item.Settings().maxCount(64))));
  SWORDS.put("astralite",reg("astralite_sword",new SwordItem(ToolMaterial.NETHERITE,8,-2.4f,new Item.Settings().maxCount(1))));
  Item[] a=new Item[4]; a[0]=reg("astralite_helmet",new ArmorItem(ArmorMaterials.NETHERITE,EquipmentType.HELMET,new Item.Settings().maxCount(1))); a[1]=reg("astralite_chestplate",new ArmorItem(ArmorMaterials.NETHERITE,EquipmentType.CHESTPLATE,new Item.Settings().maxCount(1))); a[2]=reg("astralite_leggings",new ArmorItem(ArmorMaterials.NETHERITE,EquipmentType.LEGGINGS,new Item.Settings().maxCount(1))); a[3]=reg("astralite_boots",new ArmorItem(ArmorMaterials.NETHERITE,EquipmentType.BOOTS,new Item.Settings().maxCount(1))); ARMOR.put("astralite",a);
  RAW.put("spirit",reg("raw_spirit",new Item(new Item.Settings().maxCount(64))));
  INGOTS.put("spirit",reg("spirit_ingot",new Item(new Item.Settings().maxCount(64))));
  SWORDS.put("spirit",reg("spirit_sword",new SwordItem(ToolMaterial.NETHERITE,8,-2.4f,new Item.Settings().maxCount(1))));
  Item[] a=new Item[4]; a[0]=reg("spirit_helmet",new ArmorItem(ArmorMaterials.NETHERITE,EquipmentType.HELMET,new Item.Settings().maxCount(1))); a[1]=reg("spirit_chestplate",new ArmorItem(ArmorMaterials.NETHERITE,EquipmentType.CHESTPLATE,new Item.Settings().maxCount(1))); a[2]=reg("spirit_leggings",new ArmorItem(ArmorMaterials.NETHERITE,EquipmentType.LEGGINGS,new Item.Settings().maxCount(1))); a[3]=reg("spirit_boots",new ArmorItem(ArmorMaterials.NETHERITE,EquipmentType.BOOTS,new Item.Settings().maxCount(1))); ARMOR.put("spirit",a);
  RAW.put("living_crystal",reg("raw_living_crystal",new Item(new Item.Settings().maxCount(64))));
  INGOTS.put("living_crystal",reg("living_crystal_ingot",new Item(new Item.Settings().maxCount(64))));
  SWORDS.put("living_crystal",reg("living_crystal_sword",new SwordItem(ToolMaterial.NETHERITE,8,-2.4f,new Item.Settings().maxCount(1))));
  Item[] a=new Item[4]; a[0]=reg("living_crystal_helmet",new ArmorItem(ArmorMaterials.NETHERITE,EquipmentType.HELMET,new Item.Settings().maxCount(1))); a[1]=reg("living_crystal_chestplate",new ArmorItem(ArmorMaterials.NETHERITE,EquipmentType.CHESTPLATE,new Item.Settings().maxCount(1))); a[2]=reg("living_crystal_leggings",new ArmorItem(ArmorMaterials.NETHERITE,EquipmentType.LEGGINGS,new Item.Settings().maxCount(1))); a[3]=reg("living_crystal_boots",new ArmorItem(ArmorMaterials.NETHERITE,EquipmentType.BOOTS,new Item.Settings().maxCount(1))); ARMOR.put("living_crystal",a);
  RAW.put("elderium",reg("raw_elderium",new Item(new Item.Settings().maxCount(64))));
  INGOTS.put("elderium",reg("elderium_ingot",new Item(new Item.Settings().maxCount(64))));
  SWORDS.put("elderium",reg("elderium_sword",new SwordItem(ToolMaterial.NETHERITE,8,-2.4f,new Item.Settings().maxCount(1))));
  Item[] a=new Item[4]; a[0]=reg("elderium_helmet",new ArmorItem(ArmorMaterials.NETHERITE,EquipmentType.HELMET,new Item.Settings().maxCount(1))); a[1]=reg("elderium_chestplate",new ArmorItem(ArmorMaterials.NETHERITE,EquipmentType.CHESTPLATE,new Item.Settings().maxCount(1))); a[2]=reg("elderium_leggings",new ArmorItem(ArmorMaterials.NETHERITE,EquipmentType.LEGGINGS,new Item.Settings().maxCount(1))); a[3]=reg("elderium_boots",new ArmorItem(ArmorMaterials.NETHERITE,EquipmentType.BOOTS,new Item.Settings().maxCount(1))); ARMOR.put("elderium",a);
  RAW.put("blightsteel",reg("raw_blightsteel",new Item(new Item.Settings().maxCount(64))));
  INGOTS.put("blightsteel",reg("blightsteel_ingot",new Item(new Item.Settings().maxCount(64))));
  SWORDS.put("blightsteel",reg("blightsteel_sword",new SwordItem(ToolMaterial.NETHERITE,8,-2.4f,new Item.Settings().maxCount(1))));
  Item[] a=new Item[4]; a[0]=reg("blightsteel_helmet",new ArmorItem(ArmorMaterials.NETHERITE,EquipmentType.HELMET,new Item.Settings().maxCount(1))); a[1]=reg("blightsteel_chestplate",new ArmorItem(ArmorMaterials.NETHERITE,EquipmentType.CHESTPLATE,new Item.Settings().maxCount(1))); a[2]=reg("blightsteel_leggings",new ArmorItem(ArmorMaterials.NETHERITE,EquipmentType.LEGGINGS,new Item.Settings().maxCount(1))); a[3]=reg("blightsteel_boots",new ArmorItem(ArmorMaterials.NETHERITE,EquipmentType.BOOTS,new Item.Settings().maxCount(1))); ARMOR.put("blightsteel",a);
 }
 public static void register(){ }
 public static void bindSetBonuses(){ ServerTickEvents.END_PLAYER_TICK.register(p -> { for(var e:ARMOR.entrySet()){ Item[] a=e.getValue(); if(p.getEquippedStack(EquipmentType.HELMET).isOf(a[0]) && p.getEquippedStack(EquipmentType.CHESTPLATE).isOf(a[1]) && p.getEquippedStack(EquipmentType.LEGGINGS).isOf(a[2]) && p.getEquippedStack(EquipmentType.BOOTS).isOf(a[3])) apply(p,e.getKey()); } }); }
 private static void apply(ServerPlayerEntity p,String id){ var effect=switch(id){case "verdant"->StatusEffects.REGENERATION;case "dawnite"->StatusEffects.HASTE;case "emeraldite"->StatusEffects.JUMP_BOOST;case "astralite"->StatusEffects.NIGHT_VISION;case "spirit"->StatusEffects.RESISTANCE;case "living_crystal"->StatusEffects.WATER_BREATHING;case "elderium"->StatusEffects.FIRE_RESISTANCE;default->StatusEffects.SPEED;}; p.addStatusEffect(new StatusEffectInstance(effect,40,0,true,false)); }
 private EverdawnWorldItems(){}
}
