package com.overworldplus.everdawn;

import net.minecraft.entity.EntityType;
import net.minecraft.entity.ai.goal.LookAtEntityGoal;
import net.minecraft.entity.ai.goal.WanderAroundFarGoal;
import net.minecraft.entity.mob.PathAwareEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.text.Text;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.world.World;

public class EverdawnTraderEntity extends PathAwareEntity {
 private EverdawnCreatureKind kind;
 public EverdawnTraderEntity(EntityType<? extends EverdawnTraderEntity> type,World world,EverdawnCreatureKind kind){super(type,world);this.kind=kind;setPersistent();}
 public EverdawnCreatureKind getKind(){return kind;}
 @Override protected void initGoals(){goalSelector.add(7,new WanderAroundFarGoal(this,0.7));goalSelector.add(8,new LookAtEntityGoal(this,PlayerEntity.class,14));}
 @Override protected ActionResult interactMob(PlayerEntity player,Hand hand){
  if(world.isClient)return ActionResult.SUCCESS;
  ItemStack held=player.getStackInHand(hand);
  if(!player.getAbilities().creativeMode && !held.isOf(Items.EMERALD)){
   player.sendMessage(Text.literal("§e"+kind.name+"§7: Bring me an emerald and I will reveal a location."),true);return ActionResult.SUCCESS;
  }
  if(!player.getAbilities().creativeMode)held.decrement(1);
  EverdawnRestoredContent.Profile profile=EverdawnRestoredContent.PROFILES.get(kind.biome);
  ItemStack reward=new ItemStack(profile==null?EverdawnProgression.ANCIENT_MAP:EverdawnRestoredContent.MAPS.get(kind.biome));
  player.giveItemStack(reward);
  player.sendMessage(Text.literal("§a"+(profile==null?kind.name:profile.traderRole())+"§7 reveals a route toward §b"+(profile==null?"an Everdawn landmark":profile.dungeon())+"§7 at §b"+targetX(player)+" §7/ §b"+targetZ(player)),false);
  return ActionResult.SUCCESS;
 }
 private int targetX(PlayerEntity p){return p.getBlockX()+((p.getRandom().nextInt(17)-8)*32);}
 private int targetZ(PlayerEntity p){return p.getBlockZ()+((p.getRandom().nextInt(17)-8)*32);}
 @Override public void writeCustomDataToNbt(NbtCompound nbt){super.writeCustomDataToNbt(nbt);nbt.putString("EverdawnKind",kind.id);}
 @Override public void readCustomDataFromNbt(NbtCompound nbt){super.readCustomDataFromNbt(nbt);String id=nbt.getString("EverdawnKind");for(EverdawnCreatureKind k:EverdawnCreatureKind.values())if(k.id.equals(id)){kind=k;break;}}
 @Override public net.minecraft.text.Text getDisplayName(){EverdawnRestoredContent.Profile p=EverdawnRestoredContent.PROFILES.get(kind.biome);return Text.literal((p==null?kind.name:p.traderRole())+" Trader");}
}
