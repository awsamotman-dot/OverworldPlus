package com.overworldplus.everdawn;

import com.overworldplus.OverworldPlus;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registry;
import net.minecraft.registry.Registries;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.world.World;
import net.minecraft.block.BlockState;
import net.minecraft.util.math.BlockPos;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.network.packet.s2c.play.PositionFlag;
import java.util.Set;

public final class EverdawnProgression {
 public static final Item HEART_SIGIL=Registry.register(Registries.ITEM,Identifier.of(OverworldPlus.MOD_ID,"heart_of_everdawn_sigil"),new Item(new Item.Settings().maxCount(1)));
 public static final Item ANCIENT_MAP=Registry.register(Registries.ITEM,Identifier.of(OverworldPlus.MOD_ID,"ancient_sky_map"),new Item(new Item.Settings().maxCount(1)));
 public static final Block STORMREACH_GATE=Registry.register(Registries.BLOCK,Identifier.of(OverworldPlus.MOD_ID,"everdawn_stormreach_gate"),new GateBlock(AbstractBlock.Settings.create().strength(50).requiresTool().luminance(s->12)));
 public static final Item STORMREACH_GATE_ITEM=Registry.register(Registries.ITEM,Identifier.of(OverworldPlus.MOD_ID,"everdawn_stormreach_gate"),new net.minecraft.item.BlockItem(STORMREACH_GATE,new Item.Settings()));
 public static void register(){}
 private static final class GateBlock extends Block{
  GateBlock(AbstractBlock.Settings s){super(s);}
  @Override protected ActionResult onUse(BlockState state,World world,BlockPos pos,PlayerEntity player,BlockHitResult hit){
   if(world.isClient)return ActionResult.SUCCESS;
   ItemStack held=player.getStackInHand(Hand.MAIN_HAND);
   if(world.getServer()!=null && player instanceof ServerPlayerEntity sp){
    boolean returning=world.getRegistryKey().getValue().getPath().equals("stormreach");
    if(!returning && !held.isOf(HEART_SIGIL) && !player.getAbilities().creativeMode){player.sendMessage(Text.literal("§5The gate demands the Heart of Everdawn."),true);return ActionResult.SUCCESS;}
    String destination=returning?"everdawn":"stormreach";
    ServerWorld target=world.getServer().getWorld(RegistryKey.of(RegistryKeys.WORLD,Identifier.of(OverworldPlus.MOD_ID,destination)));
    if(target!=null){if(!returning && !player.getAbilities().creativeMode)held.decrement(1);sp.teleport(target,0.5,120,0.5,Set.<PositionFlag>of(),sp.getYaw(),sp.getPitch(),true);player.sendMessage(Text.literal(returning?"§aYou return to Everdawn.":"§bThe sky opens. Stormreach awaits."),true);}
    else player.sendMessage(Text.literal("§cThe destination dimension is not available."),true);
   }
   return ActionResult.SUCCESS;
  }
 }
 private EverdawnProgression(){}
}
