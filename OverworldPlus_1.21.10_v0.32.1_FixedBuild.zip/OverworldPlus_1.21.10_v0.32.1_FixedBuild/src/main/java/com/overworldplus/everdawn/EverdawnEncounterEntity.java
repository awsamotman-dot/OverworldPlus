package com.overworldplus.everdawn;

import net.minecraft.entity.EntityType;
import net.minecraft.entity.ai.goal.ActiveTargetGoal;
import net.minecraft.entity.ai.goal.LookAtEntityGoal;
import net.minecraft.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.text.Text;
import net.minecraft.world.World;

/** Independent encounter entity for every Everdawn mini-boss and structure boss. */
public class EverdawnEncounterEntity extends HostileEntity {
    private final EverdawnCreatureKind kind;
    private final EverdawnEncounterRole role;
    private String encounterName = "";
    private int phase = 1;

    public EverdawnEncounterEntity(EntityType<? extends EverdawnEncounterEntity> type, World world,
                                   EverdawnCreatureKind kind, EverdawnEncounterRole role) {
        super(type, world);
        this.kind = kind;
        this.role = role;
        setPersistent();
        experiencePoints = role == EverdawnEncounterRole.STRUCTURE_BOSS ? 180 : 100;
    }

    public EverdawnCreatureKind getKind() { return kind; }
    public EverdawnEncounterRole getRole() { return role; }
    public boolean isStructureBoss() { return role == EverdawnEncounterRole.STRUCTURE_BOSS; }
    public void setEncounterName(String name) { encounterName = name == null ? "" : name; }

    public static DefaultAttributeContainer.Builder attributes(EverdawnEncounterRole role) {
        boolean structure = role == EverdawnEncounterRole.STRUCTURE_BOSS;
        return HostileEntity.createHostileAttributes()
                .add(EntityAttributes.MAX_HEALTH, structure ? 650 : 320)
                .add(EntityAttributes.ATTACK_DAMAGE, structure ? 24 : 14)
                .add(EntityAttributes.ARMOR, structure ? 14 : 9)
                .add(EntityAttributes.ARMOR_TOUGHNESS, structure ? 6 : 3)
                .add(EntityAttributes.KNOCKBACK_RESISTANCE, structure ? .85 : .55)
                .add(EntityAttributes.MOVEMENT_SPEED, structure ? .27 : .31)
                .add(EntityAttributes.FOLLOW_RANGE, 64);
    }

    @Override protected void initGoals() {
        goalSelector.add(2, new MeleeAttackGoal(this, 1.15, false));
        goalSelector.add(7, new LookAtEntityGoal(this, PlayerEntity.class, 24));
        targetSelector.add(1, new ActiveTargetGoal<>(this, PlayerEntity.class, true));
    }

    @Override protected void mobTick() {
        super.mobTick();
        if (world.isClient || getTarget() == null) return;
        phase = getHealth() <= getMaxHealth() * .35f ? 3 : getHealth() <= getMaxHealth() * .65f ? 2 : 1;
        if (age % (isStructureBoss() ? 55 : 75) != 0) return;
        PlayerEntity t = getTarget();
        int skill = Math.floorMod(age / 20 + kind.ordinal() + phase, 5);
        switch (skill) {
            case 0 -> t.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 45 + phase * 10, Math.min(2, phase - 1)));
            case 1 -> t.addStatusEffect(new StatusEffectInstance(StatusEffects.WEAKNESS, 50 + phase * 10, phase - 1));
            case 2 -> t.addStatusEffect(new StatusEffectInstance(StatusEffects.POISON, 35 + phase * 8, isStructureBoss() ? 1 : 0));
            case 3 -> { if (phase >= 2) t.addStatusEffect(new StatusEffectInstance(StatusEffects.BLINDNESS, 30, 0)); }
            default -> { if (phase >= 3) t.addStatusEffect(new StatusEffectInstance(StatusEffects.WITHER, 28, 0)); }
        }
        if (isStructureBoss() && age % 110 == 0) heal(18f);
    }

    @Override public Text getDisplayName() {
        return Text.literal(encounterName.isEmpty() ? kind.name : encounterName);
    }

    @Override public void writeCustomDataToNbt(NbtCompound nbt) {
        super.writeCustomDataToNbt(nbt);
        nbt.putString("EncounterKind", kind.id);
        nbt.putString("EncounterRole", role.name());
        nbt.putString("EncounterName", encounterName);
    }

    @Override public void readCustomDataFromNbt(NbtCompound nbt) {
        super.readCustomDataFromNbt(nbt);
        encounterName = nbt.getString("EncounterName");
    }
}
