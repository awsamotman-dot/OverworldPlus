package com.overworldplus.everdawn;
public enum EverdawnEncounterRole { MINI_BOSS, STRUCTURE_BOSS }
