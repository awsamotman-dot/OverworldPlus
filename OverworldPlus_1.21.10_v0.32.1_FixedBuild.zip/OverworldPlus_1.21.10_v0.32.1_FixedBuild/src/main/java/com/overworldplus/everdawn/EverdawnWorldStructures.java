package com.overworldplus.everdawn;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerChunkEvents;
import net.minecraft.block.Block;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.Heightmap;
import net.minecraft.world.World;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.world.biome.Biome;
import java.util.*;

public final class EverdawnWorldStructures {
 private static final RegistryKey<World> WORLD=RegistryKey.of(RegistryKeys.WORLD,Identifier.of("overworldplus","everdawn"));
 private static final Map<String,String> SURFACE=new HashMap<>(), DUNGEON=new HashMap<>();
 static {
  SURFACE.put("everdawn_meadows","meadow_village"); DUNGEON.put("everdawn_meadows","rootbound_catacombs");
  SURFACE.put("the_ancientwood","ancientwood_grove"); DUNGEON.put("the_ancientwood","ancient_grove_depths");
  SURFACE.put("blossomwilds","blossom_court"); DUNGEON.put("blossomwilds","blossom_burrow");
  SURFACE.put("the_mycelian_deep","mycelian_hive"); DUNGEON.put("the_mycelian_deep","mycelian_labyrinth");
  SURFACE.put("emerald_highlands","emerald_hold"); DUNGEON.put("emerald_highlands","emerald_deep");
  SURFACE.put("the_everflow","everflow_harbor"); DUNGEON.put("the_everflow","everflow_underways");
  SURFACE.put("verdant_jungle","verdant_jungle_temple"); DUNGEON.put("verdant_jungle","jungle_ruins");
  SURFACE.put("spiritwood","spiritwood_shrine"); DUNGEON.put("spiritwood","spirit_catacombs");
  SURFACE.put("the_golden_dawnlands","golden_dawn_city"); DUNGEON.put("the_golden_dawnlands","golden_crypt");
  SURFACE.put("the_astral_grove","astral_observatory"); DUNGEON.put("the_astral_grove","astral_rift");
  SURFACE.put("the_wildheart_basin","wildheart_camp"); DUNGEON.put("the_wildheart_basin","wildheart_den");
  SURFACE.put("mistveil_marshes","mistveil_settlement"); DUNGEON.put("mistveil_marshes","mistveil_drowned_temple");
  SURFACE.put("the_elder_ruins","elder_ruin_city"); DUNGEON.put("the_elder_ruins","elder_vault");
  SURFACE.put("the_worldtree_expanse","worldtree_sanctum"); DUNGEON.put("the_worldtree_expanse","worldtree_roots");
  SURFACE.put("feywild_gardens","feywild_palace"); DUNGEON.put("feywild_gardens","feywild_maze");
  SURFACE.put("the_blighted_forest","blight_fortress"); DUNGEON.put("the_blighted_forest","blight_hollow");
  SURFACE.put("the_verdant_caldera","verdant_caldera_forge"); DUNGEON.put("the_verdant_caldera","caldera_depths");
  SURFACE.put("the_skygarden_peaks","skygarden_monastery"); DUNGEON.put("the_skygarden_peaks","skyroot_depths");
  SURFACE.put("the_forgotten_wilds","forgotten_wild_city"); DUNGEON.put("the_forgotten_wilds","forgotten_crypt");
  SURFACE.put("the_everdawn_heart","everdawn_heart_temple"); DUNGEON.put("the_everdawn_heart","heart_of_everdawn_dungeon");
 }
 public static void register() { /* Generation is owned by EverdawnWorldSystems. */ }
 private static Block b(String id){return EverdawnWorldBlocks.ALL.get(id);} private static void put(ServerWorld w,BlockPos p,String id){Block x=b(id);if(x!=null)w.setBlockState(p,x.getDefaultState());}
 private static void build(ServerWorld w,BlockPos p,String s){BlockPos c=p.down(); for(int x=-6;x<=6;x++)for(int z=-6;z<=6;z++)for(int y=0;y<3;y++)put(w,c.add(x,y,z),s+"_stone"); for(int x=-4;x<=4;x++)for(int z=-4;z<=4;z++)for(int y=3;y<7;y++)if(Math.abs(x)==4||Math.abs(z)==4||y==6)put(w,c.add(x,y,z),s+"_bricks"); for(int y=7;y<11;y++){put(w,c.add(-4,y,-4),s+"_accent");put(w,c.add(4,y,-4),s+"_accent");put(w,c.add(-4,y,4),s+"_accent");put(w,c.add(4,y,4),s+"_accent");} put(w,c.add(0,6,0),s+"_glow");}
 private static void dungeon(ServerWorld w,BlockPos p,String d){BlockPos c=p.down(5); for(int x=-5;x<=5;x++)for(int z=-5;z<=5;z++)put(w,c.add(x,0,z),d+"_stone"); for(int y=-1;y>=-9;y--)for(int x=-3;x<=3;x++)for(int z=-3;z<=3;z++)if(Math.abs(x)==3||Math.abs(z)==3)put(w,c.add(x,y,z),d+"_bricks"); put(w,c.down(9),d+"_seal"); put(w,c.down(8),d+"_glow");}
 private EverdawnWorldStructures(){}
}
