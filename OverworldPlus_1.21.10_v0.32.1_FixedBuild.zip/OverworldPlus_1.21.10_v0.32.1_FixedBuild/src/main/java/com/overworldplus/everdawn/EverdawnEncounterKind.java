package com.overworldplus.everdawn;

public enum EverdawnEncounterKind {
    MEADOW_WARDEN("meadow_warden", "The Stag Warden", "everdawn_meadows"),
    BARKBOUND_CHAMPION("barkbound_champion", "The Barkbound Champion", "the_ancientwood"),
    THORN_MATRIARCH("thorn_matriarch", "The Thorn Matriarch", "blossomwilds"),
    PALE_SPORELORD("pale_sporelord", "The Pale Sporelord", "the_mycelian_deep"),
    FACETBREAKER("facetbreaker", "The Facetbreaker", "emerald_highlands"),
    DROWNED_COURIER("drowned_courier", "The Drowned Courier", "the_everflow"),
    VINE_STALKER("vine_stalker", "The Vine Stalker", "verdant_jungle"),
    PALE_HART("pale_hart", "The Pale Hart", "spiritwood"),
    DAWN_EXECUTIONER("dawn_executioner", "The Dawn Executioner", "the_golden_dawnlands"),
    COMET_HERALD("comet_herald", "The Comet Herald", "the_astral_grove"),
    BLOODHORN("bloodhorn", "The Bloodhorn", "the_wildheart_basin"),
    FEN_HAG("fen_hag", "The Fen Hag", "mistveil_marshes"),
    RUIN_KNIGHT("ruin_knight", "The Ruin Knight", "the_elder_ruins"),
    BRANCHWARDEN("branchwarden", "The Branchwarden", "the_worldtree_expanse"),
    MIRROR_HARE("mirror_hare", "The Mirror Hare", "feywild_gardens"),
    ROT_KNIGHT("rot_knight", "The Rot Knight", "the_blighted_forest"),
    MAGMA_STAG("magma_stag", "The Magma Stag", "the_verdant_caldera"),
    CLOUD_SERAPH("cloud_seraph", "The Cloud Seraph", "the_skygarden_peaks"),
    NAMELESS_HUNTER("nameless_hunter", "The Nameless Hunter", "the_forgotten_wilds"),
    HEARTBOUND_KNIGHT("heartbound_knight", "The Heartbound Knight", "the_everdawn_heart");
    public final String id,name,biome;
    EverdawnEncounterKind(String id,String name,String biome){this.id=id;this.name=name;this.biome=biome;}
}
