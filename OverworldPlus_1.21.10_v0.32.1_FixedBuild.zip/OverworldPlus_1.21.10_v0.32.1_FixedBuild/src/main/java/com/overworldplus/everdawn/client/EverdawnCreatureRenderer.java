package com.overworldplus.everdawn.client;

import com.overworldplus.OverworldPlus;
import com.overworldplus.everdawn.EverdawnCreatureEntity;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.MobEntityRenderer;
import net.minecraft.client.render.entity.model.BipedEntityModel;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;

public class EverdawnCreatureRenderer extends MobEntityRenderer<EverdawnCreatureEntity,BipedEntityModel<EverdawnCreatureEntity>> {
 public EverdawnCreatureRenderer(EntityRendererFactory.Context ctx,BipedEntityModel<EverdawnCreatureEntity> model){super(ctx,model,.45f);}
 @Override public Identifier getTexture(EverdawnCreatureEntity e){return Identifier.of(OverworldPlus.MOD_ID,"textures/entity/everdawn_creature/"+e.getKind().id+".png");}
 @Override protected void scale(EverdawnCreatureEntity e,MatrixStack matrices,float tickDelta){float s=e.isElite()?1.35f:1f;matrices.scale(s,s,s);}
}
