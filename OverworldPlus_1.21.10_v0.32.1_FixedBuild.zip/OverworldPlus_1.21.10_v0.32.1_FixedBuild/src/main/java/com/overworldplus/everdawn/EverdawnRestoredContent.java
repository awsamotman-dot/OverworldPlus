package com.overworldplus.everdawn;

import com.overworldplus.OverworldPlus;
import net.minecraft.item.Item;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;
import java.util.*;

/** Restored Everdawn content registry: lore, maps, trophies and encounter names that were previously only design notes. */
public final class EverdawnRestoredContent {
    public record Profile(String biome, String settlement, String traderRole, String dungeon, String miniBoss, String structureBoss, String map, String lore) {}
    public static final Map<String, Item> LORE_TOMES = new LinkedHashMap<>();
    public static final Map<String, Item> MAPS = new LinkedHashMap<>();
    public static final Map<String, Item> TROPHIES = new LinkedHashMap<>();
    public static final Map<String, Profile> PROFILES = new LinkedHashMap<>();

    private static Item item(String id) { return Registry.register(Registries.ITEM, Identifier.of(OverworldPlus.MOD_ID, id), new Item(new Item.Settings().maxCount(1))); }

    static {
        add("everdawn_meadows", "Dawnmeadow Commune", "Dawn Herbalist", "Meadowroot Catacombs", "The Stag Warden", "The Meadow Warden", "Dawn Meadow Chart", "The first dawn left its gentlest memory here.");
        add("the_ancientwood", "Elderwood Grove", "Root Seer", "Ancient Grove Depths", "The Barkbound Champion", "The Rootbound Champion", "Ancientwood Root Chart", "The oldest trees remember every oath spoken beneath them.");
        add("blossomwilds", "Blossom Court", "Petal Alchemist", "Blossom Burrow", "The Thorn Matriarch", "The Thornbound Duchess", "Blossom Court Chart", "Every flower in this court grows from a forgotten promise.");
        add("the_mycelian_deep", "Mycelian Hive", "Spore Oracle", "Mycelian Labyrinth", "The Pale Sporelord", "The Deep Sporelord", "Mycelian Depth Chart", "The underground remembers through spores rather than words.");
        add("emerald_highlands", "Emerald Hold", "Gemwright", "Emerald Deep", "The Facetbreaker", "The Emerald Sentinel", "Emerald Highlands Chart", "Ancient miners carved their history into living crystal.");
        add("the_everflow", "Everflow Harbor", "River Navigator", "Everflow Underways", "The Drowned Courier", "The River Crown", "Everflow Chart", "The river changes its course when the world changes its heart.");
        add("verdant_jungle", "Verdant Canopy", "Jungle Forager", "Jungle Ruins", "The Vine Stalker", "The Canopy Tyrant", "Verdant Jungle Chart", "Vines conceal roads older than the first kingdom.");
        add("spiritwood", "Spiritwood Shrine", "Spirit Medium", "Spirit Catacombs", "The Pale Hart", "The Spirit Guardian", "Spiritwood Chart", "The spirits gather where moonlight touches ancient roots.");
        add("the_golden_dawnlands", "Golden Dawn City", "Sun Archivist", "Golden Crypt", "The Dawn Executioner", "The Solar Regent", "Golden Dawn Chart", "The old sun-kings sealed their greatest secrets beneath gold.");
        add("the_astral_grove", "Astral Observatory", "Star Reader", "Astral Rift", "The Comet Herald", "The Starbound Hierophant", "Astral Grove Chart", "Stars fall here as memories rather than stones.");
        add("the_wildheart_basin", "Wildheart Camp", "Beast Tracker", "Wildheart Den", "The Bloodhorn", "The Primal Champion", "Wildheart Chart", "The basin rewards courage and punishes hesitation.");
        add("mistveil_marshes", "Mistveil Hamlet", "Bog Seer", "Drowned Temple", "The Fen Hag", "The Mist Sovereign", "Mistveil Chart", "The fog hides roads that only appear during silence.");
        add("the_elder_ruins", "Elder Ruin Enclave", "Relic Scholar", "Elder Vault", "The Ruin Knight", "The Elder Castellan", "Elder Ruins Chart", "The ruins are broken, but their laws still endure.");
        add("the_worldtree_expanse", "Worldtree Sanctum", "Root Keeper", "Worldtree Roots", "The Branchwarden", "The Worldtree Guardian", "Worldtree Chart", "Every root leads toward a memory of Everdawn.");
        add("feywild_gardens", "Fey Palace", "Fey Envoy", "Feywild Maze", "The Mirror Hare", "The Fey Champion", "Feywild Chart", "The Fey court changes its halls when mortals blink.");
        add("the_blighted_forest", "Blight Refuge", "Blight Purifier", "Blight Hollow", "The Rot Knight", "The Blight Marshal", "Blighted Forest Chart", "The corruption is not death; it is hunger wearing the shape of life.");
        add("the_verdant_caldera", "Verdant Forgehold", "Living Smith", "Caldera Depths", "The Magma Stag", "The Caldera Lord", "Verdant Caldera Chart", "Fire and leaf meet here without destroying one another.");
        add("the_skygarden_peaks", "Skygarden Monastery", "Cloud Cartographer", "Skyroot Depths", "The Cloud Seraph", "The Skygarden Ascendant", "Skygarden Chart", "The highest gardens grow from stone that remembers the sky.");
        add("the_forgotten_wilds", "Forgotten Wild City", "Memory Hunter", "Forgotten Crypt", "The Nameless Hunter", "The Forgotten King\'s Champion", "Forgotten Wilds Chart", "Some memories were buried because they were too dangerous to keep.");
        add("the_everdawn_heart", "Heart Temple", "Heart Oracle", "Heart of Everdawn Dungeon", "The Heartbound Knight", "The Heartwarden", "Everdawn Heart Chart", "At the center of Everdawn beats a heart that predates every kingdom.");
    }

    private static void add(String biome, String settlement, String traderRole, String dungeon, String miniBoss, String structureBoss, String map, String lore) {
        PROFILES.put(biome, new Profile(biome, settlement, traderRole, dungeon, miniBoss, structureBoss, map, lore));
        LORE_TOMES.put(biome, item("lore_" + biome));
        MAPS.put(biome, item("map_" + biome));
        TROPHIES.put(biome, item("trophy_" + biome));
    }

    public static void register() {}
    private EverdawnRestoredContent() {}
}
