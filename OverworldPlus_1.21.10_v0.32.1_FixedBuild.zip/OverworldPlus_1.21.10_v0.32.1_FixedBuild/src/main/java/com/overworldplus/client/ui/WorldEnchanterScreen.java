package com.overworldplus.client.ui;

import com.overworldplus.expansion.WorldUpgradeSystem;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;

import java.util.List;

/** Souls-like, simple enchanting screen: one item, three direct upgrade choices. */
public final class WorldEnchanterScreen extends Screen {
    private final Screen parent;
    private List<WorldUpgradeSystem.Option> options = List.of();
    public WorldEnchanterScreen(Screen parent) { super(Text.literal("World Enchanter")); this.parent = parent; }

    @Override protected void init() {
        refreshOptions();
        int x = width / 2 - 155;
        int y = 92;
        for (int i=0;i<3;i++) {
            final int choice=i;
            String label = i < options.size() ? options.get(i).name()+" "+WorldUpgradeSystem.roman(options.get(i).level())+"  ·  "+options.get(i).cost()+" XP" : "—";
            addDrawableChild(ButtonWidget.builder(Text.literal(label), b -> choose(choice)).dimensions(x, y, 310, 28).build());
            y += 36;
        }
        addDrawableChild(ButtonWidget.builder(Text.literal("REFRESH"), b -> refreshOptions()).dimensions(width/2-150,height-58,100,22).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("CLOSE"), b -> close()).dimensions(width/2+50,height-58,100,22).build());
    }

    private void refreshOptions() {
        if (client == null || client.player == null || client.world == null) { options=List.of(); return; }
        String world=client.world.getRegistryKey().getValue().getPath();
        ItemStack stack=client.player.getMainHandStack();
        options=WorldUpgradeSystem.optionsFor(world,client.player.getUuid(),client.world.getSeed(),stack,client.player.getCommandTags());
        if (!children().isEmpty()) clearAndInit();
    }

    private void choose(int choice) {
        if (client == null || client.player == null || choice >= options.size()) return;
        client.player.networkHandler.sendChatCommand("overworldplus upgrade " + choice);
        close();
    }

    @Override public void render(DrawContext c,int mx,int my,float delta) {
        c.fill(0,0,width,height,0xFF070809);
        c.fill(22,20,width-22,height-20,0xFF111214);
        c.fill(30,28,width-30,31,0xFF3A3329);
        c.drawCenteredTextWithShadow(textRenderer,Text.literal("WORLD ENCHANTER"),width/2,40,0xFFE5D8BA);
        String world=client==null||client.world==null?"Unknown World":pretty(client.world.getRegistryKey().getValue().getPath());
        c.drawCenteredTextWithShadow(textRenderer,Text.literal(world),width/2,57,0xFF8D8578);
        if(client!=null&&client.player!=null){
            c.drawCenteredTextWithShadow(textRenderer,Text.literal("Hold the item you want to upgrade"),width/2,75,0xFF77716A);
            c.drawCenteredTextWithShadow(textRenderer,Text.literal("XP Levels: "+client.player.experienceLevel),width/2,height-78,0xFFD0C4AB);
        }
        super.render(c,mx,my,delta);
    }
    @Override public void close(){if(client!=null)client.setScreen(parent);}
    private static String pretty(String id){StringBuilder s=new StringBuilder();for(String w:id.replace('_',' ').split(" "))if(!w.isEmpty()){if(s.length()>0)s.append(' ');s.append(Character.toUpperCase(w.charAt(0))).append(w.substring(1));}return s.toString();}
}
