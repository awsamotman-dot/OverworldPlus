package com.overworldplus.client.ui;

import com.overworldplus.expansion.DimensionalNexusBlock;
import com.overworldplus.expansion.OverworldPlusRpgSystems;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;


import java.util.List;

/** A deliberately simple, Souls-like adventure menu. */
public final class OverworldPlusMenuScreen extends Screen {
    private final Screen parent;
    private int page = 0;
    public OverworldPlusMenuScreen(Screen parent) { super(Text.literal("Overworld Plus")); this.parent = parent; }

    @Override protected void init() {
        if (page == 0) buildMain(); else if (page == 1) buildWorlds(); else if (page == 2) buildCharacter(); else buildCodex();
    }

    private void buildMain() {
        int x=width/2-105, y=84;
        add("WORLD", x,y, () -> {page=1;clearAndInit();}); y+=31;
        add("MAP", x,y, () -> { if(client!=null) client.setScreen(new OverworldPlusMapScreen(this)); }); y+=31;
        add("UPGRADE", x,y, () -> { if(client!=null) client.setScreen(new WorldEnchanterScreen(this)); }); y+=31;
        add("CHARACTER", x,y, () -> {page=2;clearAndInit();}); y+=31;
        add("CODEX", x,y, () -> {page=3;clearAndInit();}); y+=31;
        add("SETTINGS", x,y, () -> {}); y+=38;
        add("CLOSE", x,y, this::close);
    }
    private void buildWorlds() {
        int x=width/2-155,y=64;
        List<String> worlds=client==null||client.player==null?List.of():DimensionalNexusBlock.discoveredWorlds(client.player);
        for(String id:worlds){final String target=id;add("ENTER · "+pretty(id),x,y,()->travel(target));y+=25;if(y>height-48)break;}
        add("BACK",width/2-90,height-34,()->{page=0;clearAndInit();},180);
    }
    private void buildCharacter(){add("BACK",width/2-90,height-34,()->{page=0;clearAndInit();},180);}
    private void buildCodex(){add("BACK",width/2-90,height-34,()->{page=0;clearAndInit();},180);}
    private void add(String label,int x,int y,Runnable action){add(label,x,y,action,210);}
    private void add(String label,int x,int y,Runnable action,int w){addDrawableChild(ButtonWidget.builder(Text.literal(label),b->action.run()).dimensions(x,y,w,22).build());}

    private void travel(String id){if(client!=null&&client.player!=null){client.player.networkHandler.sendChatCommand("overworldplus travel "+id);close();}}

    @Override public void render(DrawContext c,int mx,int my,float delta){
        c.fill(0,0,width,height,0xFF070809);
        c.fill(22,20,width-22,height-22,0xFF111214);
        c.fill(30,28,width-30,31,0xFF3A3329);
        c.fill(30,height-31,width-30,height-28,0xFF3A3329);
        c.drawCenteredTextWithShadow(textRenderer,Text.literal("OVERWORLD PLUS"),width/2,36,0xFFE5D8BA);
        if(page==0){c.drawCenteredTextWithShadow(textRenderer,Text.literal("CONTINUE ADVENTURE"),width/2,58,0xFF8D8578);}
        else if(page==1){c.drawCenteredTextWithShadow(textRenderer,Text.literal("WORLD"),width/2,43,0xFFB4A68E);c.drawCenteredTextWithShadow(textRenderer,Text.literal("Discovered dimensions"),width/2,54,0xFF6F6A62);}
        else if(page==2){
            c.drawCenteredTextWithShadow(textRenderer,Text.literal("CHARACTER"),width/2,54,0xFFB4A68E);
            if(client!=null&&client.player!=null){int x=width/2-120; c.drawTextWithShadow(textRenderer,Text.literal("Class  ·  "+pretty(OverworldPlusRpgSystems.classOf(client.player))),x,92,0xFFD0C4AB);c.drawTextWithShadow(textRenderer,Text.literal("Faction ·  "+pretty(OverworldPlusRpgSystems.factionOf(client.player))),x,114,0xFFAAA39A);c.drawTextWithShadow(textRenderer,Text.literal("Level   ·  "+client.player.experienceLevel),x,136,0xFFAAA39A);}
        } else {c.drawCenteredTextWithShadow(textRenderer,Text.literal("CODEX"),width/2,54,0xFFB4A68E);c.drawCenteredTextWithShadow(textRenderer,Text.literal("Ancient knowledge awaits."),width/2,96,0xFF77716A);}
        super.render(c,mx,my,delta);
    }
    @Override public void close(){if(client!=null)client.setScreen(parent);}
    private static String pretty(String id){StringBuilder s=new StringBuilder();for(String w:id.replace('_',' ').split(" "))if(!w.isEmpty()){if(s.length()>0)s.append(' ');s.append(Character.toUpperCase(w.charAt(0))).append(w.substring(1));}return s.toString();}
}
