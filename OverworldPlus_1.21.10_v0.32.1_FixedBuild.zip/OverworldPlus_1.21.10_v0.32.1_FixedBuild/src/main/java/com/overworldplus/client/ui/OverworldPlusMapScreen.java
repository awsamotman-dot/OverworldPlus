package com.overworldplus.client.ui;

import com.overworldplus.expansion.DimensionalNexusBlock;
import com.overworldplus.expansion.RpgItems;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.Heightmap;

import java.util.HashSet;
import java.util.Set;

public final class OverworldPlusMapScreen extends Screen {
    private final Screen parent;
    private String dimension = "overworld";
    private final Set<String> fragments = new HashSet<>();
    private int ticks;

    public OverworldPlusMapScreen(Screen parent) { super(Text.literal("Map")); this.parent = parent; }

    @Override protected void init() {
        if (client == null || client.player == null) return;
        dimension = client.world == null ? "overworld" : client.world.getRegistryKey().getValue().getPath();
        loadFragments();
        addDrawableChild(ButtonWidget.builder(Text.literal("BACK"), b -> close()).dimensions(width - 88, height - 28, 76, 20).build());
    }

    private void loadFragments() {
        fragments.clear();
        if (client == null || client.player == null) return;
        String prefix = "op_map_fragment_" + dimension + "_";
        for (String tag : client.player.getCommandTags()) if (tag.startsWith(prefix)) fragments.add(tag.substring(prefix.length()));
    }

    @Override public void tick() {
        super.tick();
        if (++ticks % 10 == 0) loadFragments();
    }

    @Override public void render(DrawContext c, int mouseX, int mouseY, float delta) {
        c.fill(0, 0, width, height, 0xFF08090B);
        c.fill(18, 18, width - 18, height - 40, 0xFF121316);
        c.drawCenteredTextWithShadow(textRenderer, Text.literal("THE MAP"), width / 2, 26, 0xFFE2D5B5);
        c.drawCenteredTextWithShadow(textRenderer, Text.literal(pretty(dimension)), width / 2, 42, 0xFF9D8B6A);
        if (client == null || client.player == null || !hasMap()) {
            c.drawCenteredTextWithShadow(textRenderer, Text.literal("You do not own this map."), width / 2, height / 2 - 8, 0xFFB8B0A0);
            c.drawCenteredTextWithShadow(textRenderer, Text.literal("Visit a Cartographer's Table to buy it."), width / 2, height / 2 + 10, 0xFF77716A);
            super.render(c, mouseX, mouseY, delta); return;
        }
        int mapLeft = 38, mapTop = 62, mapRight = width - 38, mapBottom = height - 58;
        c.fill(mapLeft, mapTop, mapRight, mapBottom, 0xFF1B1C1D);
        int cellsX = 64, cellsY = 36;
        double scaleX = (mapRight - mapLeft) / (double) cellsX;
        double scaleY = (mapBottom - mapTop) / (double) cellsY;
        BlockPos p = client.player.getBlockPos();
        int cellWorld = 32;
        for (int gx = 0; gx < cellsX; gx++) for (int gy = 0; gy < cellsY; gy++) {
            int ox = (gx - cellsX / 2) * cellWorld;
            int oz = (gy - cellsY / 2) * cellWorld;
            int wx = p.getX() + ox, wz = p.getZ() + oz;
            String key = fragmentKey(Math.floorDiv(wx, 256), Math.floorDiv(wz, 256));
            if (!fragments.contains(key)) {
                c.fill((int)(mapLeft + gx * scaleX), (int)(mapTop + gy * scaleY), (int)(mapLeft + (gx+1)*scaleX + 1), (int)(mapTop + (gy+1)*scaleY + 1), 0xFF0B0C0E);
                continue;
            }
            int color = terrainColor(wx, wz);
            c.fill((int)(mapLeft + gx * scaleX), (int)(mapTop + gy * scaleY), (int)(mapLeft + (gx+1)*scaleX + 1), (int)(mapTop + (gy+1)*scaleY + 1), color);
        }
        int px = mapLeft + (mapRight - mapLeft) / 2;
        int py = mapTop + (mapBottom - mapTop) / 2;
        c.fill(px - 2, py - 8, px + 3, py + 3, 0xFFE5C35A);
        c.fill(px - 7, py - 3, px + 8, py + 1, 0xFFE5C35A);
        c.drawTextWithShadow(textRenderer, Text.literal("YOU"), px + 8, py - 5, 0xFFE5C35A);
        c.drawTextWithShadow(textRenderer, Text.literal("Explored regions: " + fragments.size()), 38, height - 50, 0xFF8C857C);
        super.render(c, mouseX, mouseY, delta);
    }

    private boolean hasMap() { return client != null && client.player != null && client.player.getCommandTags().contains("op_map_" + dimension); }

    private int terrainColor(int x, int z) {
        if (client == null || client.world == null) return 0xFF4C4B43;
        try {
            int y = client.world.getTopY(Heightmap.Type.WORLD_SURFACE, x, z);
            String biome = client.world.getBiome(BlockPos.ofFloored(x, Math.max(0, y), z)).getKey().map(k -> k.getValue().getPath()).orElse("");
            if (biome.contains("ocean") || biome.contains("sea")) return 0xFF354F5A;
            if (biome.contains("desert") || biome.contains("sand")) return 0xFF8C754E;
            if (biome.contains("snow") || biome.contains("frost")) return 0xFF7F8586;
            if (biome.contains("crystal")) return 0xFF655C82;
            if (biome.contains("forest") || biome.contains("wild") || biome.contains("jungle")) return 0xFF3E4B3C;
            if (biome.contains("swamp") || biome.contains("marsh")) return 0xFF3E4737;
            if (biome.contains("mountain") || biome.contains("highland") || biome.contains("peak")) return 0xFF5C5A55;
            return y > 110 ? 0xFF69665D : 0xFF4D5148;
        } catch (Exception ignored) { return 0xFF4A4A43; }
    }

    private static String fragmentKey(int rx, int rz) { return rx + "_" + rz; }
    private static String pretty(String id) { StringBuilder s = new StringBuilder(); for (String w : id.replace('_',' ').split(" ")) if (!w.isEmpty()) { if (s.length()>0)s.append(' '); s.append(Character.toUpperCase(w.charAt(0))).append(w.substring(1)); } return s.toString(); }
    @Override public void close() { if (client != null) client.setScreen(parent); }
}
