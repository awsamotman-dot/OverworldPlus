package com.overworldplus.client;

import com.overworldplus.GuardianEntity;
import com.overworldplus.OverworldPlus;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.MobEntityRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;

public class GuardianEntityRenderer extends MobEntityRenderer<GuardianEntity, GuardianEntityModel> {
    public GuardianEntityRenderer(EntityRendererFactory.Context ctx, GuardianEntityModel model) { super(ctx, model, 2.0f); }
    @Override public Identifier getTexture(GuardianEntity entity){ return entity.getKind().texture(); }
    @Override protected void scale(GuardianEntity e, MatrixStack matrices, float amount){
        float s=switch(e.getKind()){case VOLKARION->1.25f;case UMBRAAZAR->1.12f;case AEROLIX->1.18f;case VERDANTUS->1.35f;case SEKHMAR->1.22f;case GLACIORIS->1.30f;}; matrices.scale(s,s,s);
    }
}
