package com.overworldplus.client;

import com.overworldplus.GuardianKind;
import com.overworldplus.OverworldPlus;
import com.overworldplus.ashen.AshenBossKind;
import com.overworldplus.ashen.client.AshenBossModel;
import com.overworldplus.ashen.client.AshenBossRenderer;
import com.overworldplus.everdawn.*;
import com.overworldplus.everdawn.client.EverdawnBossModel;
import com.overworldplus.everdawn.client.EverdawnBossRenderer;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.EntityModelLayerRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.minecraft.client.render.entity.model.EntityModelLayer;
import net.minecraft.entity.EntityType;
import net.minecraft.client.render.entity.model.BipedEntityModel;
import net.minecraft.client.render.entity.model.EntityModelLayers;
import com.overworldplus.everdawn.client.EverdawnCreatureRenderer;
import com.overworldplus.stormreach.*;
import com.overworldplus.stormreach.client.*;
import com.overworldplus.sunkensands.*;
import com.overworldplus.sunkensands.client.*;
import com.overworldplus.umbral.*;
import com.overworldplus.umbral.client.*;
import com.overworldplus.expansion.client.*;
import com.overworldplus.client.ui.OverworldPlusMenuScreen;
import com.overworldplus.client.ui.OverworldPlusMapScreen;
import com.overworldplus.client.ui.OverworldPlusMapShopScreen;
import com.overworldplus.client.ui.WorldEnchanterScreen;
import com.overworldplus.expansion.DimensionalNexusBlock;
import com.overworldplus.expansion.RpgItems;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import org.lwjgl.glfw.GLFW;

import java.util.EnumMap;
import java.util.Map;

public final class OverworldPlusClient implements ClientModInitializer {
    private static KeyBinding MENU_KEY;
    private static boolean autoOpenedThisSession = false;
    public static final EntityModelLayer GUARDIAN_LAYER = new EntityModelLayer(OverworldPlus.MOD_ID, "guardian");
    @Override public void onInitializeClient(){
        MENU_KEY = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.overworldplus.menu", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_O, "category.overworldplus"));
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.player == null) {
                autoOpenedThisSession = false;
            } else {
                // Open the Overworld Plus RPG menu automatically when the player enters a world.
                // It only opens once per client session so closing it does not trap the player in the UI.
                if (!autoOpenedThisSession && client.currentScreen == null && !client.isPaused()) {
                    autoOpenedThisSession = true;
                    client.setScreen(new OverworldPlusMenuScreen(null));
                }
                while (MENU_KEY.wasPressed()) client.setScreen(new OverworldPlusMenuScreen(client.currentScreen));
            }
        });
        UseItemCallback.EVENT.register((player, world, hand) -> { if (world.isClient && player.getStackInHand(hand).isOf(RpgItems.ANCIENT_CODEX)) { MinecraftClientHolder.open(); return ActionResult.SUCCESS; }
            if (world.isClient && player.getStackInHand(hand).isOf(RpgItems.EXPLORER_MAP)) { MinecraftClientHolder.openMap(); return ActionResult.SUCCESS; } return ActionResult.PASS; });
        UseBlockCallback.EVENT.register((player, world, hand, hit) -> { if (world.isClient && world.getBlockState(hit.getBlockPos()).isOf(com.overworldplus.expansion.ExpansionBlocks.DIMENSIONAL_NEXUS)) { MinecraftClientHolder.open(); return ActionResult.SUCCESS; }
            if (world.isClient && world.getBlockState(hit.getBlockPos()).isOf(RpgItems.MAP_SHOP)) { MinecraftClientHolder.openMapShop(); return ActionResult.SUCCESS; }
            if (world.isClient && world.getBlockState(hit.getBlockPos()).isOf(com.overworldplus.expansion.ExpansionBlocks.WORLD_ENCHANTER)) { MinecraftClientHolder.openUpgrade(); return ActionResult.SUCCESS; } return ActionResult.PASS; });
        EntityModelLayerRegistry.registerModelLayer(GUARDIAN_LAYER, GuardianEntityModel::getTexturedModelData);
        for(GuardianKind kind: GuardianKind.values()) EntityRendererRegistry.register(OverworldPlus.GUARDIANS.get(kind), ctx -> new GuardianEntityRenderer(ctx, new GuardianEntityModel(ctx.getPart(GUARDIAN_LAYER))));
        for (AshenBossKind kind : AshenBossKind.values()) {
            EntityModelLayer layer = new EntityModelLayer(OverworldPlus.MOD_ID, "ashen_boss_" + kind.id);
            EntityModelLayerRegistry.registerModelLayer(layer, () -> AshenBossModel.create(kind));
            EntityRendererRegistry.register(OverworldPlus.ASHEN_BOSSES.get(kind), ctx -> new AshenBossRenderer(ctx, new AshenBossModel(ctx.getPart(layer), kind), kind));
        }
        for (EverdawnBossKind kind : EverdawnBossKind.values()) {
            EntityModelLayer layer = new EntityModelLayer(OverworldPlus.MOD_ID, "everdawn_boss_" + kind.id);
            EntityModelLayerRegistry.registerModelLayer(layer, () -> EverdawnBossModel.create(kind));
            EntityRendererRegistry.register(OverworldPlus.EVERDAWN_BOSSES.get(kind), ctx -> new EverdawnBossRenderer(ctx, new EverdawnBossModel(ctx.getPart(layer), kind), kind));
        }
        EntityRendererRegistry.register(OverworldPlus.EVERDAWN_CREATURE, ctx -> new EverdawnCreatureRenderer(ctx, new BipedEntityModel<>(ctx.getPart(EntityModelLayers.ZOMBIE))));
        EntityRendererRegistry.register(OverworldPlus.EVERDAWN_ELITE, ctx -> new EverdawnCreatureRenderer(ctx, new BipedEntityModel<>(ctx.getPart(EntityModelLayers.ZOMBIE))));
        EntityRendererRegistry.register(OverworldPlus.EVERDAWN_TRADER, ctx -> new EverdawnCreatureRenderer(ctx, new BipedEntityModel<>(ctx.getPart(EntityModelLayers.ZOMBIE))));
        for (EntityType<EverdawnEncounterEntity> type : OverworldPlus.EVERDAWN_MINI_BOSSES.values()) EntityRendererRegistry.register(type, ctx -> new EverdawnEncounterRenderer(ctx));
        for (EntityType<EverdawnEncounterEntity> type : OverworldPlus.EVERDAWN_STRUCTURE_BOSSES.values()) EntityRendererRegistry.register(type, ctx -> new EverdawnEncounterRenderer(ctx));
        for (StormreachCreatureKind kind : StormreachCreatureKind.values()) EntityRendererRegistry.register(OverworldPlus.STORMREACH_CREATURES.get(kind), ctx -> new StormreachCreatureRenderer(ctx, new BipedEntityModel<>(ctx.getPart(EntityModelLayers.ZOMBIE))));
        for (StormreachBossKind kind : StormreachBossKind.values()) EntityRendererRegistry.register(OverworldPlus.STORMREACH_BOSSES.get(kind), ctx -> new StormreachBossRenderer(ctx, new BipedEntityModel<>(ctx.getPart(EntityModelLayers.ZOMBIE))));
        EntityRendererRegistry.register(OverworldPlus.STORMREACH_NPC, StormreachNPCRenderer::new);
        for (StormreachStructureKind kind : StormreachStructureKind.values()) EntityRendererRegistry.register(OverworldPlus.STORMREACH_STRUCTURE_MOBS.get(kind), ctx -> new StormreachStructureRenderer(ctx, new BipedEntityModel<>(ctx.getPart(EntityModelLayers.ZOMBIE))));
        for (StormreachStructureKind kind : StormreachStructureKind.values()) EntityRendererRegistry.register(OverworldPlus.STORMREACH_STRUCTURE_MINI_BOSSES.get(kind), ctx -> new StormreachStructureMiniBossRenderer(ctx, new BipedEntityModel<>(ctx.getPart(EntityModelLayers.ZOMBIE))));
        for (StormreachBiomeMiniBossKind kind : StormreachBiomeMiniBossKind.values()) EntityRendererRegistry.register(OverworldPlus.STORMREACH_BIOME_MINI_BOSSES.get(kind), StormreachBiomeMiniBossRenderer::new);
        for (SunkenSandsCreatureKind kind : SunkenSandsCreatureKind.values()) { EntityModelLayer layer=new EntityModelLayer(OverworldPlus.MOD_ID,"sunken_creature_"+kind.id); EntityModelLayerRegistry.registerModelLayer(layer,()->SunkenSandsCreatureModel.create(kind)); EntityRendererRegistry.register(OverworldPlus.SUNKEN_SANDS_CREATURES.get(kind),ctx->new SunkenSandsCreatureRenderer(ctx,new SunkenSandsCreatureModel(ctx.getPart(layer),kind),kind)); }
        for (SunkenSandsBossKind kind : SunkenSandsBossKind.values()) { EntityModelLayer layer=new EntityModelLayer(OverworldPlus.MOD_ID,"sunken_boss_"+kind.id); EntityModelLayerRegistry.registerModelLayer(layer,()->SunkenSandsBossModel.create(kind)); EntityRendererRegistry.register(OverworldPlus.SUNKEN_SANDS_BOSSES.get(kind),ctx->new SunkenSandsBossRenderer(ctx,new SunkenSandsBossModel(ctx.getPart(layer),kind),kind)); }
        EntityRendererRegistry.register(OverworldPlus.SUNKEN_SANDS_NPC, SunkenSandsNPCRenderer::new);
        for (SunkenSandsStructureKind kind : SunkenSandsStructureKind.values()) { EntityModelLayer layer=new EntityModelLayer(OverworldPlus.MOD_ID,"sunken_structure_"+kind.id); EntityModelLayerRegistry.registerModelLayer(layer,()->SunkenSandsStructureModel.create(kind)); EntityRendererRegistry.register(OverworldPlus.SUNKEN_SANDS_STRUCTURE_MOBS.get(kind),ctx->new SunkenSandsStructureRenderer(ctx,new SunkenSandsStructureModel(ctx.getPart(layer),kind),kind)); }
        for (SunkenSandsStructureKind kind : SunkenSandsStructureKind.values()) { EntityModelLayer layer=new EntityModelLayer(OverworldPlus.MOD_ID,"sunken_structure_boss_"+kind.id); EntityModelLayerRegistry.registerModelLayer(layer,()->SunkenSandsStructureMiniBossModel.create(kind)); EntityRendererRegistry.register(OverworldPlus.SUNKEN_SANDS_STRUCTURE_MINI_BOSSES.get(kind),ctx->new SunkenSandsStructureMiniBossRenderer(ctx,new SunkenSandsStructureMiniBossModel(ctx.getPart(layer),kind),kind)); }
        for (SunkenSandsBiomeMiniBossKind kind : SunkenSandsBiomeMiniBossKind.values()) { EntityModelLayer layer=new EntityModelLayer(OverworldPlus.MOD_ID,"sunken_biome_boss_"+kind.id); EntityModelLayerRegistry.registerModelLayer(layer,()->SunkenSandsBiomeMiniBossModel.create(kind)); EntityRendererRegistry.register(OverworldPlus.SUNKEN_SANDS_BIOME_MINI_BOSSES.get(kind),ctx->new SunkenSandsBiomeMiniBossRenderer(ctx,new SunkenSandsBiomeMiniBossModel(ctx.getPart(layer),kind),kind)); }

        for(UmbralCreatureKind kind:UmbralCreatureKind.values()){EntityModelLayer l=new EntityModelLayer(OverworldPlus.MOD_ID,"umbral_creature_"+kind.id);EntityModelLayerRegistry.registerModelLayer(l,()->UmbralCreatureModel.create(kind));EntityRendererRegistry.register(OverworldPlus.UMBRAL_CREATURES.get(kind),ctx->new UmbralCreatureRenderer(ctx,new UmbralCreatureModel(ctx.getPart(l),kind),kind));}
        for(UmbralBossKind kind:UmbralBossKind.values()){EntityModelLayer l=new EntityModelLayer(OverworldPlus.MOD_ID,"umbral_boss_"+kind.id);EntityModelLayerRegistry.registerModelLayer(l,UmbralBossModel::create);EntityRendererRegistry.register(OverworldPlus.UMBRAL_BOSSES.get(kind),ctx->new UmbralBossRenderer(ctx,new UmbralBossModel(ctx.getPart(l)),kind));}
        for(UmbralMiniBossKind kind:UmbralMiniBossKind.values()){EntityModelLayer l=new EntityModelLayer(OverworldPlus.MOD_ID,"umbral_miniboss_"+kind.id);EntityModelLayerRegistry.registerModelLayer(l,UmbralMiniBossModel::create);EntityRendererRegistry.register(OverworldPlus.UMBRAL_MINI_BOSSES.get(kind),ctx->new UmbralMiniBossRenderer(ctx,new UmbralMiniBossModel(ctx.getPart(l)),kind));}
        for(UmbralStructureKind kind:UmbralStructureKind.values()){EntityModelLayer l=new EntityModelLayer(OverworldPlus.MOD_ID,"umbral_guardian_"+kind.id);EntityModelLayerRegistry.registerModelLayer(l,UmbralGuardianModel::create);EntityRendererRegistry.register(OverworldPlus.UMBRAL_STRUCTURE_MOBS.get(kind),ctx->new UmbralGuardianRenderer<>(ctx,new UmbralGuardianModel<>(ctx.getPart(l)),kind.id));}
        for(UmbralStructureBossKind kind:UmbralStructureBossKind.values()){EntityModelLayer l=new EntityModelLayer(OverworldPlus.MOD_ID,"umbral_structure_boss_"+kind.id);EntityModelLayerRegistry.registerModelLayer(l,UmbralGuardianModel::create);EntityRendererRegistry.register(OverworldPlus.UMBRAL_STRUCTURE_BOSSES.get(kind),ctx->new UmbralGuardianRenderer<>(ctx,new UmbralGuardianModel<>(ctx.getPart(l)),kind.id));}
        EntityModelLayer cwLayer=new EntityModelLayer(OverworldPlus.MOD_ID,"crystal_warden");EntityModelLayerRegistry.registerModelLayer(cwLayer,UmbralGuardianModel::create);EntityRendererRegistry.register(OverworldPlus.CRYSTAL_WARDEN,ctx->new CrystalWardenRenderer(ctx,new UmbralGuardianModel<>(ctx.getPart(cwLayer))));
    }
    private static final class MinecraftClientHolder {
        static void open() { net.minecraft.client.MinecraftClient.getInstance().setScreen(new OverworldPlusMenuScreen(net.minecraft.client.MinecraftClient.getInstance().currentScreen)); }
        static void openMap() { net.minecraft.client.MinecraftClient.getInstance().setScreen(new OverworldPlusMapScreen(net.minecraft.client.MinecraftClient.getInstance().currentScreen)); }
        static void openMapShop() { net.minecraft.client.MinecraftClient.getInstance().setScreen(new OverworldPlusMapShopScreen(net.minecraft.client.MinecraftClient.getInstance().currentScreen)); }
        static void openUpgrade() { net.minecraft.client.MinecraftClient.getInstance().setScreen(new WorldEnchanterScreen(net.minecraft.client.MinecraftClient.getInstance().currentScreen)); }
    }

}
