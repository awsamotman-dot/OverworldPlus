package com.overworldplus.client.ui;

import com.overworldplus.expansion.DimensionalNexusBlock;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

import java.util.List;

public final class OverworldPlusMapShopScreen extends Screen {
    private final Screen parent;
    public OverworldPlusMapShopScreen(Screen parent) { super(Text.literal("Cartographer")); this.parent = parent; }
    @Override protected void init() {
        if (client == null || client.player == null) return;
        List<String> worlds = DimensionalNexusBlock.discoveredWorlds(client.player);
        int y = 58;
        for (String id : worlds) {
            final String target = id;
            addDrawableChild(ButtonWidget.builder(Text.literal("BUY MAP · " + pretty(id) + " · 8 Emeralds"), b -> buy("mapbuy", target)).dimensions(width/2-190,y,380,20).build());
            y += 24;
            if (y > height-75) break;
        }
        addDrawableChild(ButtonWidget.builder(Text.literal("BUY CURRENT MAP FRAGMENT · 3 Emeralds"), b -> buy("mapfragment", current())).dimensions(width/2-190,height-56,380,20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("BACK"), b -> close()).dimensions(width-88,height-28,76,20).build());
    }
    private void buy(String command,String id){ if(client!=null&&client.player!=null){client.player.networkHandler.sendChatCommand("overworldplus "+command+" "+id); close();}}
    private String current(){ return client==null||client.world==null?"overworld":client.world.getRegistryKey().getValue().getPath(); }
    @Override public void render(DrawContext c,int mx,int my,float delta){c.fill(0,0,width,height,0xFF090A0C);c.fill(24,20,width-24,height-40,0xFF151619);c.drawCenteredTextWithShadow(textRenderer,Text.literal("THE CARTOGRAPHER"),width/2,30,0xFFE2D5B5);c.drawCenteredTextWithShadow(textRenderer,Text.literal("Maps & Fragments"),width/2,44,0xFF8F877A);super.render(c,mx,my,delta);}
    @Override public void close(){if(client!=null)client.setScreen(parent);}
    private static String pretty(String id){StringBuilder s=new StringBuilder();for(String w:id.replace('_',' ').split(" "))if(!w.isEmpty()){if(s.length()>0)s.append(' ');s.append(Character.toUpperCase(w.charAt(0))).append(w.substring(1));}return s.toString();}
}
