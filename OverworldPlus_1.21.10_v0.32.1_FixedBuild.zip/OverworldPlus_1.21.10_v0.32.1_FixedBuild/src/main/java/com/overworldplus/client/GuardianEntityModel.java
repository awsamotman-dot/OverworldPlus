package com.overworldplus.client;

import com.overworldplus.GuardianEntity;
import com.overworldplus.GuardianKind;
import net.minecraft.client.model.*;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.MathHelper;

public class GuardianEntityModel extends EntityModel<GuardianEntity> {
    private final ModelPart root, body, head, leftArm, rightArm, leftLeg, rightLeg, core;
    public GuardianEntityModel(ModelPart root) {
        super(root); this.root=root; body=root.getChild("body"); head=root.getChild("head");
        leftArm=root.getChild("left_arm"); rightArm=root.getChild("right_arm"); leftLeg=root.getChild("left_leg"); rightLeg=root.getChild("right_leg"); core=root.getChild("core");
    }
    public static TexturedModelData getTexturedModelData() {
        ModelData d=new ModelData(); ModelPartData r=d.getRoot();
        r.addChild("body", ModelPartBuilder.create().uv(0,0).cuboid(-12,-22,-8,24,30,16), ModelTransform.pivot(0,2,0));
        r.addChild("head", ModelPartBuilder.create().uv(0,48).cuboid(-8,-10,-7,16,16,14), ModelTransform.pivot(0,-20,-1));
        r.addChild("left_arm", ModelPartBuilder.create().uv(80,0).cuboid(-5,-2,-6,10,30,12), ModelTransform.pivot(17,-15,0));
        r.addChild("right_arm", ModelPartBuilder.create().uv(80,42).cuboid(-5,-2,-6,10,30,12), ModelTransform.pivot(-17,-15,0));
        r.addChild("left_leg", ModelPartBuilder.create().uv(0,80).cuboid(-6,0,-7,12,28,14), ModelTransform.pivot(7,30,0));
        r.addChild("right_leg", ModelPartBuilder.create().uv(52,80).cuboid(-6,0,-7,12,28,14), ModelTransform.pivot(-7,30,0));
        r.addChild("core", ModelPartBuilder.create().uv(96,80).cuboid(-3,-3,-9,6,6,3), ModelTransform.pivot(0,0,0));
        return TexturedModelData.of(d,128,128);
    }
    @Override public void setAngles(GuardianEntity e,float limbAngle,float limbDistance,float age,float headYaw,float headPitch){
        head.yaw=headYaw*MathHelper.RADIANS_PER_DEGREE; head.pitch=headPitch*MathHelper.RADIANS_PER_DEGREE;
        float walk=MathHelper.cos(limbAngle*.55f)*limbDistance*.7f;
        leftLeg.pitch=walk; rightLeg.pitch=-walk; leftArm.pitch=-walk*.65f; rightArm.pitch=walk*.65f;
        float bob=MathHelper.sin(age*.08f)*.5f; body.pivotY=2+bob;
        if(e.getAttackAnimation()!=0){float p=e.getAttackProgress(0); float swing=MathHelper.sin(p*MathHelper.PI); if(e.getAttackAnimation()==1){leftArm.pitch=-1.5f*swing;rightArm.pitch=-1.5f*swing;} else if(e.getAttackAnimation()==2){body.pitch=.35f*swing;} else {leftArm.roll=.8f*swing;rightArm.roll=-.8f*swing;}}
        core.pivotZ=e.isWeakPointOpen()?-1.2f:-.2f; core.xScale=e.isWeakPointOpen()?1.4f:1f; core.yScale=e.isWeakPointOpen()?1.4f:1f;
        switch(e.getKind()){
            case UMBRAAZAR -> {head.roll=MathHelper.sin(age*.06f)*.08f; leftArm.roll=.2f; rightArm.roll=-.2f;}
            case AEROLIX -> {leftArm.roll=.45f; rightArm.roll=-.45f;}
            case VERDANTUS -> {leftArm.pitch+=.2f; rightArm.pitch-=.2f;}
            case SEKHMAR -> {head.yaw+=MathHelper.sin(age*.05f)*.12f;}
            case GLACIORIS -> {body.pitch=MathHelper.sin(age*.04f)*.04f;}
            default -> {}
        }
    }
    @Override public void render(MatrixStack matrices,VertexConsumer vertices,int light,int overlay,int color){root.render(matrices,vertices,light,overlay,color);}
}
