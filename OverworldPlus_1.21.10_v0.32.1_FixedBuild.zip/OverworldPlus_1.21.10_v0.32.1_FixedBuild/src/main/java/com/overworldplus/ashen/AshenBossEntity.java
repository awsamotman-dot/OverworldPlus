package com.overworldplus.ashen;

import com.overworldplus.OverworldPlus;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.goal.ActiveTargetGoal;
import net.minecraft.entity.ai.goal.LookAtEntityGoal;
import net.minecraft.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.entity.ai.goal.RevengeGoal;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.boss.ServerBossBar;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.text.Text;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

public class AshenBossEntity extends HostileEntity {
    private final AshenBossKind kind;
    private final ServerBossBar bossBar;
    private int phase;
    private int cooldown;
    private int skillTimer;
    private int skillAnimation;
    private int invulnerableTicks;
    private boolean defeated;

    public AshenBossEntity(EntityType<? extends AshenBossEntity> type, World world, AshenBossKind kind) {
        super(type, world);
        this.kind = kind;
        this.experiencePoints = 500;
        this.setPersistent();
        this.bossBar = new ServerBossBar(Text.literal(kind.title), ServerBossBar.Color.RED, ServerBossBar.Style.NOTCHED_20);
    }

    public AshenBossKind getKind() { return kind; }
    public int getPhase() { return phase; }
    public int getSkillAnimation() { return skillAnimation; }
    public float getSkillProgress(float tickDelta) { return MathHelper.clamp((skillTimer - tickDelta) / 24f, 0f, 1f); }

    public static DefaultAttributeContainer.Builder createAttributes() {
        return HostileEntity.createHostileAttributes()
                .add(EntityAttributes.MAX_HEALTH, 1200.0)
                .add(EntityAttributes.ATTACK_DAMAGE, 28.0)
                .add(EntityAttributes.ARMOR, 22.0)
                .add(EntityAttributes.ARMOR_TOUGHNESS, 12.0)
                .add(EntityAttributes.KNOCKBACK_RESISTANCE, 1.0)
                .add(EntityAttributes.MOVEMENT_SPEED, 0.25)
                .add(EntityAttributes.FOLLOW_RANGE, 80.0);
    }

    @Override protected void initGoals() {
        goalSelector.add(2, new MeleeAttackGoal(this, 1.05, false));
        goalSelector.add(8, new LookAtEntityGoal(this, PlayerEntity.class, 32f));
        targetSelector.add(1, new RevengeGoal(this));
        targetSelector.add(2, new ActiveTargetGoal<>(this, PlayerEntity.class, true));
    }

    @Override protected void mobTick() {
        super.mobTick();
        if (getWorld().isClient) return;
        if (cooldown > 0) cooldown--;
        if (skillTimer > 0) skillTimer--;
        if (invulnerableTicks > 0) invulnerableTicks--;
        updatePhase();
        bossBar.setPercent(Math.max(0f, getHealth() / getMaxHealth()));
        LivingEntity target = getTarget();
        if (target != null && target.isAlive() && cooldown <= 0) useUniqueSkill(target);
    }

    private void updatePhase() {
        float r = getHealth() / getMaxHealth();
        int next = r <= .25f ? 2 : r <= .60f ? 1 : 0;
        if (next != phase) {
            phase = next;
            invulnerableTicks = 30;
            if (getWorld() instanceof ServerWorld sw) {
                sw.playSound(null, getBlockPos(), AshenBossSounds.phase(kind), SoundCategory.HOSTILE, 5f, .65f + phase * .12f);
                sw.getPlayers().stream().filter(p -> p.squaredDistanceTo(this) < 80 * 80)
                        .forEach(p -> p.sendMessage(Text.literal("§c" + kind.title.toUpperCase() + " — PHASE " + (phase + 1)), true));
            }
        }
    }

    

    private void beginSkill(int animation, int duration) {
        skillAnimation = animation;
        skillTimer = duration;
        playSound((animation & 1) == 0 ? AshenBossSounds.attack2(kind) : AshenBossSounds.attack1(kind), 3.8f, 0.72f + random.nextFloat() * 0.18f);
    }

    private void useUniqueSkill(LivingEntity target) {
        double d = distanceTo(target);
        switch (kind) {
            case ASHEN_WARDEN -> wardenSkill(target, d);
            case CRIMSON_PROPHET -> crimsonProphet(target, d);
            case FLAME_KEEPER -> flameKeeper(target, d);
            case MOLTEN_EXCAVATOR -> excavator(target, d);
            case IRON_TYRANT -> ironTyrant(target, d);
            case UNDYING_LORD -> undyingLord(target, d);
            case MAGMA_COLOSSUS -> magmaColossus(target, d);
            case VILLAGE_KEEPER -> villageKeeper(target, d);
            case HOLLOW_GIANT -> hollowGiant(target, d);
            case FORGOTTEN_KING -> forgottenKing(target, d);
            case INFERNAL_SERPENT -> infernalSerpent(target, d);
            case CRIMSON_BEASTMASTER -> beastmaster(target, d);
            case BLACK_COMMANDER -> blackCommander(target, d);
            case VOLKARION -> volkarion(target, d);
        }
    }

    private void radialDamage(double radius, float damage, double knockback) {
        for (LivingEntity e : getWorld().getEntitiesByClass(LivingEntity.class, getBoundingBox().expand(radius), x -> x != this && x.isAlive())) {
            if (e.squaredDistanceTo(this) <= radius * radius) {
                e.damage(getDamageSources().mobAttack(this), damage);
                if (knockback > 0) e.takeKnockback(knockback, getX() - e.getX(), getZ() - e.getZ());
            }
        }
    }

    private void leap(LivingEntity target, double power) {
        Vec3d d = target.getPos().subtract(getPos());
        double len = Math.max(.1, Math.sqrt(d.x * d.x + d.z * d.z));
        setVelocity(d.x / len * power, .8 + phase * .15, d.z / len * power);
        velocityDirty = true;
    }

    private void wardenSkill(LivingEntity t, double d) { beginSkill(1, 24); radialDamage(6 + phase, 18 + phase * 5, 1.4); cooldown = 38 - phase * 4; }
    private void crimsonProphet(LivingEntity t, double d) { beginSkill(2, 26); radialDamage(9 + phase * 2, 14 + phase * 4, 0); t.addStatusEffect(new StatusEffectInstance(StatusEffects.WITHER, 80 + phase * 40, phase)); cooldown = 55 - phase * 5; }
    private void flameKeeper(LivingEntity t, double d) { beginSkill(3, 28); radialDamage(7 + phase, 16 + phase * 4, 1); for (LivingEntity e : getWorld().getEntitiesByClass(LivingEntity.class, getBoundingBox().expand(10), x -> x != this && x.isAlive())) e.setOnFireFor(phase == 2 ? 8 : 5); cooldown = 52 - phase * 5; }
    private void excavator(LivingEntity t, double d) { beginSkill(4, 22); leap(t, 1.5); radialDamage(5 + phase, 22 + phase * 5, 2); cooldown = 45 - phase * 4; }
    private void ironTyrant(LivingEntity t, double d) { beginSkill(5, 30); radialDamage(5, 24 + phase * 4, 2.2); addStatusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE, 30, 2)); cooldown = 48 - phase * 4; }
    private void undyingLord(LivingEntity t, double d) { beginSkill(6, 30); addStatusEffect(new StatusEffectInstance(StatusEffects.REGENERATION, 80 + phase * 30, 1)); radialDamage(8, 13 + phase * 4, 0); cooldown = 70 - phase * 6; }
    private void magmaColossus(LivingEntity t, double d) { beginSkill(7, 32); leap(t, 1.2); radialDamage(10 + phase * 2, 26 + phase * 6, 2.5); cooldown = 60 - phase * 5; }
    private void villageKeeper(LivingEntity t, double d) { beginSkill(8, 25); if (random.nextBoolean()) leap(t, 1.35); radialDamage(6, 17 + phase * 4, 1.1); cooldown = 42 - phase * 4; }
    private void hollowGiant(LivingEntity t, double d) { beginSkill(9, 34); if (random.nextBoolean()) t.addStatusEffect(new StatusEffectInstance(StatusEffects.BLINDNESS, 50, 0)); radialDamage(12, 18 + phase * 5, 0); cooldown = 62 - phase * 5; }
    private void forgottenKing(LivingEntity t, double d) { beginSkill(10, 27); radialDamage(7, 22 + phase * 5, 1.7); if (phase >= 1) addStatusEffect(new StatusEffectInstance(StatusEffects.STRENGTH, 60, 1)); cooldown = 50 - phase * 4; }
    private void infernalSerpent(LivingEntity t, double d) { beginSkill(11, 22); leap(t, 1.8); radialDamage(5, 20 + phase * 5, 1); for (LivingEntity e : getWorld().getEntitiesByClass(LivingEntity.class, getBoundingBox().expand(7), x -> x != this && x.isAlive())) e.setOnFireFor(6 + phase * 2); cooldown = 44 - phase * 3; }
    private void beastmaster(LivingEntity t, double d) { beginSkill(12, 26); radialDamage(8, 15 + phase * 4, 1.2); t.addStatusEffect(new StatusEffectInstance(StatusEffects.POISON, 80, phase)); cooldown = 52 - phase * 5; }
    private void blackCommander(LivingEntity t, double d) { beginSkill(13, 28); leap(t, 1.6); radialDamage(6, 25 + phase * 5, 2.0); cooldown = 46 - phase * 4; }
    private void volkarion(LivingEntity t, double d) { beginSkill(14, 36); leap(t, 1.45); radialDamage(14 + phase * 2, 30 + phase * 8, 2.8); for (LivingEntity e : getWorld().getEntitiesByClass(LivingEntity.class, getBoundingBox().expand(14), x -> x != this && x.isAlive())) e.setOnFireFor(10 + phase * 3); cooldown = 68 - phase * 5; }

    @Override public boolean damage(DamageSource source, float amount) {
        if (invulnerableTicks > 0) return false;
        if (phase == 1) amount *= .92f;
        if (phase == 2) amount *= .85f;
        amount = Math.min(amount, 45f);
        return super.damage(source, amount);
    }

    @Override protected void dropLoot(ServerWorld world, DamageSource source) {
        if (!(source.getAttacker() instanceof PlayerEntity)) return;
        dropStack(new ItemStack(AshenItems.KEYS.get(kind)));
        dropStack(new ItemStack(AshenItems.WEAPONS.get(kind)));
        if (random.nextFloat() < .45f) dropStack(new ItemStack(AshenItems.INGOTS.get(AshenMaterial.values()[kind.ordinal() % AshenMaterial.values().length]), 2 + random.nextInt(4)));
        if (kind == AshenBossKind.VOLKARION) dropStack(new ItemStack(AshenItems.INGOTS.get(AshenMaterial.ANCIENT), 4));
    }

    @Override public void onStartedTrackingBy(ServerPlayerEntity player) { super.onStartedTrackingBy(player); bossBar.addPlayer(player); }
    @Override public void onStoppedTrackingBy(ServerPlayerEntity player) { super.onStoppedTrackingBy(player); bossBar.removePlayer(player); }
    @Override public void remove(RemovalReason reason) { bossBar.clearPlayers(); super.remove(reason); }

    @Override protected net.minecraft.sound.SoundEvent getAmbientSound() { return AshenBossSounds.ambient(kind); }
    @Override protected net.minecraft.sound.SoundEvent getHurtSound(DamageSource source) { return AshenBossSounds.hurt(kind); }
    @Override protected net.minecraft.sound.SoundEvent getDeathSound() { return AshenBossSounds.death(kind); }
    @Override protected float getSoundVolume() { return 2.4f; }
}
