package com.overworldplus.ashen.client;

import com.overworldplus.ashen.AshenBossEntity;
import com.overworldplus.ashen.AshenBossKind;
import net.minecraft.client.model.*;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.MathHelper;

public class AshenBossModel extends EntityModel<AshenBossEntity> {
    private final ModelPart root, body, head, leftArm, rightArm, leftLeg, rightLeg, core, extra;
    private final AshenBossKind kind;
    public AshenBossModel(ModelPart root, AshenBossKind kind) {
        super(root); this.root=root; this.kind=kind;
        body=root.getChild("body"); head=root.getChild("head"); leftArm=root.getChild("left_arm"); rightArm=root.getChild("right_arm");
        leftLeg=root.getChild("left_leg"); rightLeg=root.getChild("right_leg"); core=root.getChild("core"); extra=root.getChild("extra");
    }
    public static TexturedModelData create(AshenBossKind kind) {
        ModelData d=new ModelData(); ModelPartData r=d.getRoot();
        float w = kind == AshenBossKind.INFERNAL_SERPENT ? 9 : 12;
        r.addChild("body", ModelPartBuilder.create().uv(0,0).cuboid(-w,-22,-8,w*2,30,16), ModelTransform.pivot(0,2,0));
        r.addChild("head", ModelPartBuilder.create().uv(0,48).cuboid(-8,-10,-7,16,16,14), ModelTransform.pivot(0,-20,-1));
        r.addChild("left_arm", ModelPartBuilder.create().uv(64,0).cuboid(-5,-2,-6,10,30,12), ModelTransform.pivot(17,-15,0));
        r.addChild("right_arm", ModelPartBuilder.create().uv(64,42).cuboid(-5,-2,-6,10,30,12), ModelTransform.pivot(-17,-15,0));
        r.addChild("left_leg", ModelPartBuilder.create().uv(0,80).cuboid(-6,0,-7,12,28,14), ModelTransform.pivot(7,30,0));
        r.addChild("right_leg", ModelPartBuilder.create().uv(52,80).cuboid(-6,0,-7,12,28,14), ModelTransform.pivot(-7,30,0));
        r.addChild("core", ModelPartBuilder.create().uv(96,80).cuboid(-3,-3,-9,6,6,3), ModelTransform.pivot(0,0,0));
        switch(kind) {
            case ASHEN_WARDEN -> r.addChild("extra", ModelPartBuilder.create().uv(0,104).cuboid(-14,-29,-4,28,7,8), ModelTransform.pivot(0,-2,0));
            case CRIMSON_PROPHET -> r.addChild("extra", ModelPartBuilder.create().uv(0,104).cuboid(-5,-32,-5,10,12,10).cuboid(-13,-24,-2,26,4,4), ModelTransform.pivot(0,0,0));
            case FLAME_KEEPER -> r.addChild("extra", ModelPartBuilder.create().uv(64,104).cuboid(-14,-4,-2,28,8,4), ModelTransform.pivot(0,-16,0));
            case MOLTEN_EXCAVATOR -> r.addChild("extra", ModelPartBuilder.create().uv(0,120).cuboid(-10,-3,-10,20,6,20), ModelTransform.pivot(0,22,0));
            case IRON_TYRANT -> r.addChild("extra", ModelPartBuilder.create().uv(64,120).cuboid(-16,-20,-3,32,8,6), ModelTransform.pivot(0,0,0));
            case UNDYING_LORD -> r.addChild("extra", ModelPartBuilder.create().uv(0,136).cuboid(-15,-8,-2,30,5,4), ModelTransform.pivot(0,-10,0));
            case MAGMA_COLOSSUS -> r.addChild("extra", ModelPartBuilder.create().uv(0,144).cuboid(-18,-28,-10,36,12,20), ModelTransform.pivot(0,0,0));
            case VILLAGE_KEEPER -> r.addChild("extra", ModelPartBuilder.create().uv(64,144).cuboid(-12,-35,-2,24,8,4), ModelTransform.pivot(0,0,0));
            case HOLLOW_GIANT -> r.addChild("extra", ModelPartBuilder.create().uv(0,156).cuboid(-18,-24,-2,36,5,4), ModelTransform.pivot(0,0,0));
            case FORGOTTEN_KING -> r.addChild("extra", ModelPartBuilder.create().uv(64,156).cuboid(-16,-34,-3,32,9,6), ModelTransform.pivot(0,0,0));
            case INFERNAL_SERPENT -> r.addChild("extra", ModelPartBuilder.create().uv(0,168).cuboid(-6,-4,-18,12,8,36), ModelTransform.pivot(0,0,0));
            case CRIMSON_BEASTMASTER -> r.addChild("extra", ModelPartBuilder.create().uv(64,168).cuboid(-13,-12,-3,26,7,6), ModelTransform.pivot(0,0,0));
            case BLACK_COMMANDER -> r.addChild("extra", ModelPartBuilder.create().uv(0,180).cuboid(-17,-31,-4,34,7,8), ModelTransform.pivot(0,0,0));
            case VOLKARION -> r.addChild("extra", ModelPartBuilder.create().uv(64,180).cuboid(-20,-30,-12,40,15,24), ModelTransform.pivot(0,0,0));
        }
        return TexturedModelData.of(d,256,256);
    }
    @Override public void setAngles(AshenBossEntity e,float limbAngle,float limbDistance,float age,float headYaw,float headPitch){
        head.yaw=headYaw*MathHelper.RADIANS_PER_DEGREE; head.pitch=headPitch*MathHelper.RADIANS_PER_DEGREE;
        float walk=MathHelper.cos(limbAngle*.5f)*limbDistance*.75f;
        leftLeg.pitch=walk; rightLeg.pitch=-walk; leftArm.pitch=-walk*.6f; rightArm.pitch=walk*.6f;
        float bob=MathHelper.sin(age*.08f)*.8f; body.pivotY=2+bob; core.pivotY=bob;
        if(e.getSkillAnimation()!=0){ float p=e.getSkillProgress(0); float s=MathHelper.sin(p*MathHelper.PI); leftArm.pitch-=1.7f*s; rightArm.pitch-=1.7f*s; body.pitch += .18f*s; }
        switch(kind){
            case HOLLOW_GIANT -> { head.roll=MathHelper.sin(age*.04f)*.16f; leftArm.roll=.18f; rightArm.roll=-.18f; }
            case INFERNAL_SERPENT -> { body.yaw=MathHelper.sin(age*.05f)*.18f; extra.yaw=MathHelper.sin(age*.07f)*.25f; }
            case FLAME_KEEPER, VOLKARION -> { extra.roll=MathHelper.sin(age*.12f)*.05f; }
            case CRIMSON_PROPHET -> { extra.pitch=MathHelper.sin(age*.09f)*.12f; }
            default -> { extra.yaw=MathHelper.sin(age*.04f)*.05f; }
        }
    }
    @Override public void render(MatrixStack matrices, VertexConsumer vertices, int light, int overlay, int color){ root.render(matrices,vertices,light,overlay,color); }
}
