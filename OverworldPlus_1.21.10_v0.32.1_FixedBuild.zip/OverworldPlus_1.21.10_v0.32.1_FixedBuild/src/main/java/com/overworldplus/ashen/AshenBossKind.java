package com.overworldplus.ashen;

public enum AshenBossKind {
    ASHEN_WARDEN("ashen_warden", "The Ashen Warden", 0x6B5A54),
    CRIMSON_PROPHET("crimson_prophet", "The Crimson Prophet", 0xA00018),
    FLAME_KEEPER("flame_keeper", "The Flame Keeper", 0xFF6A00),
    MOLTEN_EXCAVATOR("molten_excavator", "The Molten Excavator", 0xFF3B00),
    IRON_TYRANT("iron_tyrant", "The Iron Tyrant", 0x4A4A4A),
    UNDYING_LORD("undying_lord", "The Undying Lord", 0x5C4A68),
    MAGMA_COLOSSUS("magma_colossus", "The Magma Colossus", 0xFF2200),
    VILLAGE_KEEPER("village_keeper", "The Village Keeper", 0x463737),
    HOLLOW_GIANT("hollow_giant", "The Hollow Giant", 0x1A1A24),
    FORGOTTEN_KING("forgotten_king", "The Forgotten King", 0x8C6A2A),
    INFERNAL_SERPENT("infernal_serpent", "The Infernal Serpent", 0xD82B00),
    CRIMSON_BEASTMASTER("crimson_beastmaster", "The Crimson Beastmaster", 0xB51F4A),
    BLACK_COMMANDER("black_commander", "The Black Commander", 0x101018),
    VOLKARION("volkarion_ashen", "Volkarion, Lord of the Magma", 0xFF4100);

    public final String id, title;
    public final int color;
    AshenBossKind(String id, String title, int color) { this.id = id; this.title = title; this.color = color; }
}
