package com.overworldplus.ashen.client;

import com.overworldplus.OverworldPlus;
import com.overworldplus.ashen.AshenBossEntity;
import com.overworldplus.ashen.AshenBossKind;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.MobEntityRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;

public class AshenBossRenderer extends MobEntityRenderer<AshenBossEntity, AshenBossModel> {
    private final AshenBossKind kind;
    public AshenBossRenderer(EntityRendererFactory.Context ctx, AshenBossModel model, AshenBossKind kind) { super(ctx, model, kind == AshenBossKind.INFERNAL_SERPENT ? 1.1f : 2.0f); this.kind=kind; }
    @Override public Identifier getTexture(AshenBossEntity entity) { return Identifier.of(OverworldPlus.MOD_ID, "textures/entity/ashen_boss/" + kind.id + ".png"); }
    @Override protected void scale(AshenBossEntity e, MatrixStack matrices, float amount) { float s = kind == AshenBossKind.INFERNAL_SERPENT ? 1.6f : (kind == AshenBossKind.VOLKARION ? 1.45f : 1.18f); matrices.scale(s,s,s); }
}
