package com.overworldplus.ashen;

import com.overworldplus.OverworldPlus;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

import java.util.EnumMap;
import java.util.Map;

public final class AshenBlocks {
    public static final Map<AshenMaterial, Block> ORES = new EnumMap<>(AshenMaterial.class);
    public static final Map<AshenMaterial, Block> BLOCKS = new EnumMap<>(AshenMaterial.class);
    public static final Map<String, Item> BLOCK_ITEMS = new java.util.HashMap<>();
    public static final Block ASHEN_STONE = register("ashen_stone", new Block(Block.Settings.copy(Blocks.STONE).strength(2.2f, 6f)));
    public static final Block ASHEN_BRICKS = register("ashen_bricks", new Block(Block.Settings.copy(Blocks.STONE_BRICKS).strength(2.8f, 8f)));
    public static final Block CRACKED_ASHEN_BRICKS = register("cracked_ashen_bricks", new Block(Block.Settings.copy(Blocks.STONE_BRICKS).strength(2.8f, 8f)));
    public static final Block CINDER_BRICKS = register("cinder_bricks", new Block(Block.Settings.copy(Blocks.NETHER_BRICKS).strength(3f, 8f)));
    public static final Block VOLCANIC_STONE = register("volcanic_stone", new Block(Block.Settings.copy(Blocks.BASALT).strength(3.2f, 9f)));
    public static final Block OBSIDIAN_BRICKS = register("obsidian_bricks", new Block(Block.Settings.copy(Blocks.OBSIDIAN).strength(25f, 1200f)));
    public static final Block CRIMSON_STONE = register("crimson_stone", new Block(Block.Settings.copy(Blocks.NETHERRACK).strength(2.5f, 7f)));
    public static final Block CRIMSON_CRYSTAL_BLOCK = register("crimson_crystal_block", new Block(Block.Settings.copy(Blocks.AMETHYST_BLOCK).strength(3f, 6f).luminance(s -> 6)));
    public static final Block MOLTEN_STONE = register("molten_stone", new Block(Block.Settings.copy(Blocks.MAGMA_BLOCK).strength(3.5f, 9f).luminance(s -> 5)));
    public static final Block LAVA_GLASS = register("lava_glass", new Block(Block.Settings.copy(Blocks.GLASS).strength(1.5f, 6f).luminance(s -> 8)));
    public static final Block CHARRED_WOOD = register("charred_wood", new Block(Block.Settings.copy(Blocks.DARK_OAK_PLANKS).strength(2.2f, 5f)));
    public static final Block ASHEN_MOSS = register("ashen_moss", new Block(Block.Settings.copy(Blocks.MOSS_BLOCK).strength(0.5f)));
    public static final Block ANCIENT_TILES = register("ancient_tiles", new Block(Block.Settings.copy(Blocks.DEEPSLATE_TILES).strength(4f, 10f)));
    public static final Block RUINED_TILES = register("ruined_tiles", new Block(Block.Settings.copy(Blocks.DEEPSLATE_TILES).strength(3f, 8f)));

    static {
        for (AshenMaterial m : AshenMaterial.values()) {
            BLOCKS.put(m, register(m.id + "_block", new Block(Block.Settings.copy(Blocks.IRON_BLOCK).strength(4f, 9f))));
            ORES.put(m, register(m.id + "_ore", new Block(Block.Settings.copy(Blocks.IRON_ORE).strength(3.2f, 7f))));
        }
    }

    private static Block register(String id, Block block) {
        return Registry.register(Registries.BLOCK, Identifier.of(OverworldPlus.MOD_ID, id), block);
    }
    public static void register() {
        registerBlockItem("ashen_stone", ASHEN_STONE); registerBlockItem("ashen_bricks", ASHEN_BRICKS); registerBlockItem("cracked_ashen_bricks", CRACKED_ASHEN_BRICKS);
        registerBlockItem("cinder_bricks", CINDER_BRICKS); registerBlockItem("volcanic_stone", VOLCANIC_STONE); registerBlockItem("obsidian_bricks", OBSIDIAN_BRICKS);
        registerBlockItem("crimson_stone", CRIMSON_STONE); registerBlockItem("crimson_crystal_block", CRIMSON_CRYSTAL_BLOCK); registerBlockItem("molten_stone", MOLTEN_STONE);
        registerBlockItem("lava_glass", LAVA_GLASS); registerBlockItem("charred_wood", CHARRED_WOOD); registerBlockItem("ashen_moss", ASHEN_MOSS);
        registerBlockItem("ancient_tiles", ANCIENT_TILES); registerBlockItem("ruined_tiles", RUINED_TILES);
        for (AshenMaterial m : AshenMaterial.values()) { registerBlockItem(m.id + "_block", BLOCKS.get(m)); registerBlockItem(m.id + "_ore", ORES.get(m)); }
    }
    private static void registerBlockItem(String id, Block block) { BLOCK_ITEMS.put(id, Registry.register(Registries.ITEM, Identifier.of(OverworldPlus.MOD_ID, id), new BlockItem(block, new Item.Settings()))); }
    private AshenBlocks() {}
}
