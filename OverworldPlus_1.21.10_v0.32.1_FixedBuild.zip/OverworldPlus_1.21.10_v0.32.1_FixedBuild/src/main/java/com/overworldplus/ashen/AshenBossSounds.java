package com.overworldplus.ashen;

import com.overworldplus.OverworldPlus;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.Identifier;

import java.util.EnumMap;
import java.util.Map;

public final class AshenBossSounds {
    private static final Map<AshenBossKind, SoundEvent> AMBIENT = new EnumMap<>(AshenBossKind.class);
    private static final Map<AshenBossKind, SoundEvent> HURT = new EnumMap<>(AshenBossKind.class);
    private static final Map<AshenBossKind, SoundEvent> DEATH = new EnumMap<>(AshenBossKind.class);
    private static final Map<AshenBossKind, SoundEvent> PHASE = new EnumMap<>(AshenBossKind.class);
    private static final Map<AshenBossKind, SoundEvent> ATTACK1 = new EnumMap<>(AshenBossKind.class);
    private static final Map<AshenBossKind, SoundEvent> ATTACK2 = new EnumMap<>(AshenBossKind.class);

    public static void register() {
        for (AshenBossKind k : AshenBossKind.values()) {
            String base = k.id;
            AMBIENT.put(k, register(base + ".ambient"));
            HURT.put(k, register(base + ".hurt"));
            DEATH.put(k, register(base + ".death"));
            PHASE.put(k, register(base + ".phase"));
            ATTACK1.put(k, register(base + ".attack1"));
            ATTACK2.put(k, register(base + ".attack2"));
        }
    }
    private static SoundEvent register(String id) {
        Identifier i = Identifier.of(OverworldPlus.MOD_ID, "ashen_boss." + id);
        return Registry.register(Registries.SOUND_EVENT, i, SoundEvent.of(i));
    }
    public static SoundEvent ambient(AshenBossKind k) { return AMBIENT.get(k); }
    public static SoundEvent hurt(AshenBossKind k) { return HURT.get(k); }
    public static SoundEvent death(AshenBossKind k) { return DEATH.get(k); }
    public static SoundEvent phase(AshenBossKind k) { return PHASE.get(k); }
    public static SoundEvent attack1(AshenBossKind k) { return ATTACK1.get(k); }
    public static SoundEvent attack2(AshenBossKind k) { return ATTACK2.get(k); }
    private AshenBossSounds() {}
}
