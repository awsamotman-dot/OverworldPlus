package com.overworldplus.ashen;

import net.minecraft.util.Identifier;

public enum AshenMaterial {
    CINDER("cinder", "Cinder"),
    MOLTEN("molten", "Molten"),
    ASHSTEEL("ashsteel", "Ashsteel"),
    CRIMSON("crimson", "Crimson"),
    OBSIDIANITE("obsidianite", "Obsidianite"),
    SOULSTONE("soulstone", "Soulstone"),
    VOLCANIC("volcanic", "Volcanic"),
    ANCIENT("ancient", "Ancient");

    public final String id;
    public final String display;
    AshenMaterial(String id, String display) { this.id = id; this.display = display; }
    public Identifier id(String suffix) { return Identifier.of("overworldplus", id + suffix); }
}
