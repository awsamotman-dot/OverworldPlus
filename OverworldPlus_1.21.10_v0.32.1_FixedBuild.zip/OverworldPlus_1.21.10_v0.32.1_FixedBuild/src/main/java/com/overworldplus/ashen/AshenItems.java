package com.overworldplus.ashen;

import com.overworldplus.OverworldPlus;
import net.minecraft.item.*;
import net.minecraft.item.equipment.ArmorItem;
import net.minecraft.item.equipment.ArmorMaterials;
import net.minecraft.item.equipment.EquipmentType;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

import java.util.EnumMap;
import java.util.Map;

public final class AshenItems {
    public static final Map<AshenMaterial, Item> INGOTS = new EnumMap<>(AshenMaterial.class);
    public static final Map<AshenMaterial, Item> NUGGETS = new EnumMap<>(AshenMaterial.class);
    public static final Map<AshenMaterial, Map<String, Item>> TOOLS = new EnumMap<>(AshenMaterial.class);
    public static final Map<AshenMaterial, Map<EquipmentType, Item>> ARMOR = new EnumMap<>(AshenMaterial.class);
    public static final Map<AshenBossKind, Item> KEYS = new EnumMap<>(AshenBossKind.class);
    public static final Map<AshenBossKind, Item> WEAPONS = new EnumMap<>(AshenBossKind.class);

    static {
        for (AshenMaterial m : AshenMaterial.values()) {
            INGOTS.put(m, register(m.id + "_ingot", new Item(new Item.Settings())));
            NUGGETS.put(m, register(m.id + "_nugget", new Item(new Item.Settings())));
            Map<String, Item> tools = new java.util.HashMap<>();
            tools.put("sword", register(m.id + "_sword", new SwordItem(ToolMaterial.NETHERITE, 5.5f + m.ordinal() * .35f, -2.3f, new Item.Settings().maxCount(1))));
            tools.put("pickaxe", register(m.id + "_pickaxe", new PickaxeItem(ToolMaterial.NETHERITE, 2.0f, -2.8f, new Item.Settings().maxCount(1))));
            tools.put("axe", register(m.id + "_axe", new AxeItem(ToolMaterial.NETHERITE, 7.0f, -3.0f, new Item.Settings().maxCount(1))));
            tools.put("shovel", register(m.id + "_shovel", new ShovelItem(ToolMaterial.NETHERITE, 2.5f, -3.0f, new Item.Settings().maxCount(1))));
            tools.put("hoe", register(m.id + "_hoe", new HoeItem(ToolMaterial.NETHERITE, -2.0f, -1.0f, new Item.Settings().maxCount(1))));
            TOOLS.put(m, tools);
            Map<EquipmentType, Item> armor = new EnumMap<>(EquipmentType.class);
            armor.put(EquipmentType.HELMET, register(m.id + "_helmet", new ArmorItem(ArmorMaterials.NETHERITE, EquipmentType.HELMET, new Item.Settings().maxCount(1))));
            armor.put(EquipmentType.CHESTPLATE, register(m.id + "_chestplate", new ArmorItem(ArmorMaterials.NETHERITE, EquipmentType.CHESTPLATE, new Item.Settings().maxCount(1))));
            armor.put(EquipmentType.LEGGINGS, register(m.id + "_leggings", new ArmorItem(ArmorMaterials.NETHERITE, EquipmentType.LEGGINGS, new Item.Settings().maxCount(1))));
            armor.put(EquipmentType.BOOTS, register(m.id + "_boots", new ArmorItem(ArmorMaterials.NETHERITE, EquipmentType.BOOTS, new Item.Settings().maxCount(1))));
            ARMOR.put(m, armor);
        }
        for (AshenBossKind boss : AshenBossKind.values()) {
            KEYS.put(boss, register(boss.id + "_key", new Item(new Item.Settings().maxCount(1))));
            WEAPONS.put(boss, register(boss.id + "_blade", new SwordItem(ToolMaterial.NETHERITE, 8.0f + boss.ordinal() * .3f, -2.5f, new Item.Settings().maxCount(1))));
        }
        register("ancient_blueprint", new Item(new Item.Settings().maxCount(1)));
        register("tome_of_cinders", new Item(new Item.Settings().maxCount(1)));
        register("tome_of_magma", new Item(new Item.Settings().maxCount(1)));
        register("tome_of_the_fallen", new Item(new Item.Settings().maxCount(1)));
        register("tome_of_shadows", new Item(new Item.Settings().maxCount(1)));
        register("tome_of_the_slayer", new Item(new Item.Settings().maxCount(1)));
    }

    private static Item register(String id, Item item) {
        return Registry.register(Registries.ITEM, Identifier.of(OverworldPlus.MOD_ID, id), item);
    }
    public static void register() {}
    private AshenItems() {}
}
