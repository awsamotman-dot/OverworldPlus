package com.overworldplus.ashen;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.state.StateManager;
import net.minecraft.state.property.IntProperty;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.network.packet.s2c.play.PositionFlag;
import net.minecraft.world.World;

public class AshenWorldGateBlock extends Block {
    public static final IntProperty KEYS = IntProperty.of("keys", 0, 14);
    public AshenWorldGateBlock() {
        super(Settings.copy(Blocks.OBSIDIAN).strength(60f, 1200f).luminance(s -> Math.min(15, 3 + s.get(KEYS))));
        setDefaultState(getStateManager().getDefaultState().with(KEYS, 0));
    }
    @Override protected void appendProperties(StateManager.Builder<Block, BlockState> builder) { builder.add(KEYS); }
    @Override protected ActionResult onUse(BlockState state, World world, BlockPos pos, PlayerEntity player, BlockHitResult hit) {
        if (world.isClient) return ActionResult.SUCCESS;
        if (state.get(KEYS) >= 14) {
            if (world.getServer() == null || !(player instanceof net.minecraft.server.network.ServerPlayerEntity sp)) return ActionResult.SUCCESS;
            RegistryKey<World> targetKey = RegistryKey.of(RegistryKeys.WORLD, Identifier.of("overworldplus", "frostveil"));
            ServerWorld target = world.getServer().getWorld(targetKey);
            if (target == null) {
                player.sendMessage(Text.literal("§cFrostveil is not available in this world save yet."), true);
                return ActionResult.SUCCESS;
            }
            sp.teleport(target, 0.5, 120, 0.5, java.util.Set.<PositionFlag>of(), sp.getYaw(), sp.getPitch(), true);
            return ActionResult.SUCCESS;
        }
        ItemStack held = player.getStackInHand(Hand.MAIN_HAND);
        AshenBossKind[] kinds = AshenBossKind.values();
        for (int i = state.get(KEYS); i < kinds.length; i++) {
            if (held.isOf(AshenItems.KEYS.get(kinds[i]))) {
                if (!player.getAbilities().creativeMode) held.decrement(1);
                int next = state.get(KEYS) + 1;
                world.setBlockState(pos, state.with(KEYS, next));
                player.sendMessage(Text.literal(next == 14 ? "§dTHE ASHEN WORLD GATE IS OPEN" : "§7ASHEN KEY INSERTED: " + next + "/14"), true);
                return ActionResult.SUCCESS;
            }
        }
        player.sendMessage(Text.literal("§8The gate requires the 14 Ashen boss keys in order."), true);
        return ActionResult.SUCCESS;
    }
}
