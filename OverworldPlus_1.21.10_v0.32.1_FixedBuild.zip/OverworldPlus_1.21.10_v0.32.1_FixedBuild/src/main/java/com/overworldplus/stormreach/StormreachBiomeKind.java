package com.overworldplus.stormreach;

public enum StormreachBiomeKind {
 STORMBOUND_PLAINS("stormbound_plains","Stormbound Plains","Stormwarden Hamlet","Stormvault Ruins","Storm Elk"),
 THUNDERSTEPPE("thundersteppe","Thundersteppe","Thunderhoof Encampment","Thunder Shrine","Thunder Ram"),
 TEMPEST_HIGHLANDS("tempest_highlands","Tempest Highlands","Galepeak Village","Tempest Monastery","Storm Lynx"),
 SKYREACH_ISLES("skyreach_isles","Skyreach Isles","Skydrift Settlement","Skyreach Temple","Sky Fox"),
 CELESTIAL_PEAKS("celestial_peaks","Celestial Peaks","Starwatch Hold","Celestial Observatory","Celestial Goat"),
 LIGHTNING_FOREST("lightning_forest","Lightning Forest","Sparkwood Village","Lightning Grove Ruins","Lightning Panther"),
 CLOUDSEA("cloudsea","Cloudsea","Cloudharbor","Cloud Temple","Cloud Whale"),
 STORMSCAR_CANYON("stormscar_canyon","Stormscar Canyon","Scarwatch Outpost","Canyon Vault","Canyon Drake"),
 THUNDER_MARSHES("thunder_marshes","Thunder Marshes","Boglight Village","Thunder Marsh Shrine","Electric Frog"),
 AZURE_EXPANSE("azure_expanse","Azure Expanse","Azure Port","Sunken Azure Temple","Azure Serpent"),
 FLOATING_KINGDOMS("floating_kingdoms","Floating Kingdoms","Aerial Capital","Floating Royal Vault","Royal Sky Lion"),
 TEMPEST_JUNGLE("tempest_jungle","Tempest Jungle","Stormvine Village","Jungle Thunder Temple","Storm Jaguar"),
 STORMFORGED_MOUNTAINS("stormforged_mountains","Stormforged Mountains","Ironcloud City","Stormforge Deep","Thunder Bear"),
 EYE_OF_THE_STORM("eye_of_the_storm","Eye of the Storm","Eyewatch Citadel","Eye Catacombs","Storm Wraith"),
 ASTRAL_COAST("astral_coast","Astral Coast","Starglass Port","Astral Observatory Vault","Astral Dolphin"),
 THUNDERFALL_VALLEY("thunderfall_valley","Thunderfall Valley","Fallsward Village","Thunderfall Caverns","Thunder Elk"),
 SKYGRAVE("skygrave","Skygrave","Gravewind Hamlet","Skygrave Necropolis","Grave Raven"),
 ETERNAL_TEMPEST("eternal_tempest","Eternal Tempest","Tempest Refuge","Eternal Storm Bastion","Eternal Storm Wolf"),
 STORMHEART_BASIN("stormheart_basin","Stormheart Basin","Heartforge City","Stormheart Sanctum","Stormheart Beast"),
 STORM_CROWN("storm_crown","The Storm Crown","Crownspire Capital","Crown Throne Dungeon","Crown Gryphon");
 public final String id,name,city,structure,creature;
 StormreachBiomeKind(String id,String name,String city,String structure,String creature){this.id=id;this.name=name;this.city=city;this.structure=structure;this.creature=creature;}
 public static StormreachBiomeKind byId(String id){for(StormreachBiomeKind k:values())if(k.id.equals(id))return k;return STORMBOUND_PLAINS;}
}
