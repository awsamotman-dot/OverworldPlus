package com.overworldplus.stormreach;
public enum StormreachCreatureKind {
 STORM_ELK("storm_elk","Storm Elk","stormbound_plains"),
 THUNDER_RAM("thunder_ram","Thunder Ram","thundersteppe"),
 STORM_LYNX("storm_lynx","Storm Lynx","tempest_highlands"),
 SKY_FOX("sky_fox","Sky Fox","skyreach_isles"),
 CELESTIAL_GOAT("celestial_goat","Celestial Goat","celestial_peaks"),
 LIGHTNING_PANTHER("lightning_panther","Lightning Panther","lightning_forest"),
 CLOUD_WHALE("cloud_whale","Cloud Whale","cloudsea"),
 CANYON_DRAKE("canyon_drake","Canyon Drake","stormscar_canyon"),
 ELECTRIC_FROG("electric_frog","Electric Frog","thunder_marshes"),
 AZURE_SERPENT("azure_serpent","Azure Serpent","azure_expanse"),
 ROYAL_SKY_LION("royal_sky_lion","Royal Sky Lion","floating_kingdoms"),
 STORM_JAGUAR("storm_jaguar","Storm Jaguar","tempest_jungle"),
 THUNDER_BEAR("thunder_bear","Thunder Bear","stormforged_mountains"),
 STORM_WRAITH("storm_wraith","Storm Wraith","eye_of_the_storm"),
 ASTRAL_DOLPHIN("astral_dolphin","Astral Dolphin","astral_coast"),
 THUNDER_ELK("thunder_elk","Thunder Elk","thunderfall_valley"),
 GRAVE_RAVEN("grave_raven","Grave Raven","skygrave"),
 ETERNAL_STORM_WOLF("eternal_storm_wolf","Eternal Storm Wolf","eternal_tempest"),
 STORMHEART_BEAST("stormheart_beast","Stormheart Beast","stormheart_basin"),
 CROWN_GRYPHON("crown_gryphon","Crown Gryphon","storm_crown");
 public final String id,name,biome; StormreachCreatureKind(String id,String name,String biome){this.id=id;this.name=name;this.biome=biome;}
}
