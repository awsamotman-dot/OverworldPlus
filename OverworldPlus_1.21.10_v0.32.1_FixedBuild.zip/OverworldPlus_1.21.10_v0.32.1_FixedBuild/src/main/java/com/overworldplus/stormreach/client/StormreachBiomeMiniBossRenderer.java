package com.overworldplus.stormreach.client;
import com.overworldplus.OverworldPlus;
import com.overworldplus.stormreach.StormreachBiomeMiniBossEntity;
import net.minecraft.client.render.entity.*;
import net.minecraft.client.render.entity.model.BipedEntityModel;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
public class StormreachBiomeMiniBossRenderer extends MobEntityRenderer<StormreachBiomeMiniBossEntity,BipedEntityModel<StormreachBiomeMiniBossEntity>>{
 public StormreachBiomeMiniBossRenderer(EntityRendererFactory.Context c){super(c,new BipedEntityModel<>(c.getPart(net.minecraft.client.render.entity.model.EntityModelLayers.ZOMBIE)),.8f);}
 @Override public Identifier getTexture(StormreachBiomeMiniBossEntity e){return Identifier.of(OverworldPlus.MOD_ID,"textures/entity/stormreach/biome_miniboss.png");}
 @Override protected void scale(StormreachBiomeMiniBossEntity e,MatrixStack m,float d){m.scale(1.7f,1.7f,1.7f);}
}
