package com.overworldplus.stormreach;

public enum StormreachStructureKind {
 SKY_CITADEL("sky_citadel","Sky Citadel","stormbound_plains","stormbound_plains,thundersteppe,skyreach_isles,floating_kingdoms"),
 THUNDER_FORTRESS("thunder_fortress","Thunder Fortress","thundersteppe","thundersteppe,stormforged_mountains,eternal_tempest"),
 TEMPEST_MONASTERY("tempest_monastery","Tempest Monastery","tempest_highlands","tempest_highlands,celestial_peaks,storm_crown"),
 CLOUD_TEMPLE("cloud_temple","Cloud Temple","cloudsea","cloudsea,azure_expanse,astral_coast"),
 STORM_CITADEL("storm_citadel","Storm Citadel","lightning_forest","lightning_forest,tempest_jungle,thunderfall_valley"),
 CANYON_KEEP("canyon_keep","Canyon Keep","stormscar_canyon","stormscar_canyon,thunderfall_valley"),
 MARSH_SHRINE("marsh_shrine","Marsh Shrine","thunder_marshes","thunder_marshes,azure_expanse"),
 ASTRAL_OBSERVATORY("astral_observatory","Astral Observatory","astral_coast","astral_coast,skygrave,celestial_peaks"),
 SKY_GRAVE_TEMPLE("sky_grave_temple","Sky Grave Temple","skygrave","skygrave,eternal_tempest"),
 STORMHEART_SANCTUM("stormheart_sanctum","Stormheart Sanctum","stormheart_basin","stormheart_basin,eye_of_the_storm"),
 CROWN_PALACE("crown_palace","Crown Palace","storm_crown","storm_crown,floating_kingdoms"),
 EYE_FORTRESS("eye_fortress","Eye Fortress","eye_of_the_storm","eye_of_the_storm,eternal_tempest")
; public final String id,name,anchorBiome; public final String[] biomes;
 StormreachStructureKind(String id,String name,String anchorBiome,String biomes){this.id=id;this.name=name;this.anchorBiome=anchorBiome;this.biomes=biomes.split(",");}
 public boolean matches(String biome){for(String b:biomes) if(b.equals(biome)) return true; return false;}
 public static StormreachStructureKind forBiome(String biome){for(StormreachStructureKind k:values()) if(k.matches(biome)) return k; return STORM_CITADEL;}
}
