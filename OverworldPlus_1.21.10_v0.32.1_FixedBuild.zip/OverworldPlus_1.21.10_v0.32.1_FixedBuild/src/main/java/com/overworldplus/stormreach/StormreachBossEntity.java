package com.overworldplus.stormreach;

import net.minecraft.entity.*;
import net.minecraft.entity.ai.goal.*;
import net.minecraft.entity.attribute.*;
import net.minecraft.entity.boss.ServerBossBar;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.sound.SoundEvent;
import net.minecraft.text.Text;
import net.minecraft.util.math.Box;
import net.minecraft.world.World;

public class StormreachBossEntity extends HostileEntity {
    private StormreachBossKind kind;
    private final ServerBossBar bar = new ServerBossBar(Text.literal("Stormreach Boss"), ServerBossBar.Color.BLUE, ServerBossBar.Style.PROGRESS);
    private int phase = 1;
    private int abilityCooldown = 60;

    public StormreachBossEntity(EntityType<? extends StormreachBossEntity> t, World w, StormreachBossKind k) {
        super(t, w); kind = k; setPersistent(); experiencePoints = 1000;
    }
    public StormreachBossKind getKind(){ return kind; }

    public static DefaultAttributeContainer.Builder attributes(){
        return HostileEntity.createHostileAttributes().add(EntityAttributes.MAX_HEALTH,1600)
                .add(EntityAttributes.ATTACK_DAMAGE,34).add(EntityAttributes.ARMOR,18)
                .add(EntityAttributes.ARMOR_TOUGHNESS,10).add(EntityAttributes.KNOCKBACK_RESISTANCE,.9)
                .add(EntityAttributes.MOVEMENT_SPEED,.28).add(EntityAttributes.FOLLOW_RANGE,110);
    }
    @Override protected void initGoals(){
        goalSelector.add(2,new MeleeAttackGoal(this,1.1,true));
        goalSelector.add(7,new LookAtEntityGoal(this,PlayerEntity.class,40));
        targetSelector.add(1,new ActiveTargetGoal<>(this,PlayerEntity.class,true));
    }
    @Override public Text getDisplayName(){ return Text.literal(kind.name); }
    @Override protected SoundEvent getAmbientSound(){ return StormreachSounds.BOSS_AMBIENT.get(kind); }
    @Override protected SoundEvent getHurtSound(net.minecraft.entity.damage.DamageSource s){ return StormreachSounds.BOSS_HURT.get(kind); }
    @Override protected SoundEvent getDeathSound(){ return StormreachSounds.BOSS_DEATH.get(kind); }

    @Override protected void mobTick(){
        super.mobTick();
        float hp=getHealth()/getMaxHealth();
        int np=hp<=.20?5:hp<=.40?4:hp<=.60?3:hp<=.80?2:1;
        if(np!=phase){ phase=np; bar.setColor(phase>=4?ServerBossBar.Color.RED:phase==3?ServerBossBar.Color.YELLOW:ServerBossBar.Color.BLUE); playSound(StormreachSounds.BOSS_PHASE.get(kind),2f,1f); phaseBurst(); }
        bar.setPercent(Math.max(0,Math.min(1,hp)));
        if(!getWorld().isClient && getTarget()!=null){
            if(abilityCooldown>0) abilityCooldown--;
            if(abilityCooldown<=0){ useSignatureAbility(); abilityCooldown=Math.max(35,90-phase*10); }
            if(age%90==0) applyPassivePhaseEffect();
        }
    }

    private void phaseBurst(){
        for(int i=0;i<45;i++) getWorld().addParticle(ParticleTypes.ELECTRIC_SPARK,getX()+getRandom().nextGaussian()*3,getY()+1+getRandom().nextDouble()*3,getZ()+getRandom().nextGaussian()*3,0,.12,0);
        if(phase>=4) heal(30);
    }
    private void applyPassivePhaseEffect(){
        PlayerEntity t=getTarget();
        if(t==null)return;
        switch(kind){
            case THUNDER_KING -> t.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS,45,phase-1));
            case SKY_SERPENT -> t.addStatusEffect(new StatusEffectInstance(StatusEffects.LEVITATION,25,phase>=4?1:0));
            case STORM_TITAN -> t.addStatusEffect(new StatusEffectInstance(StatusEffects.MINING_FATIGUE,50,phase-1));
            case CLOUD_EMPRESS -> t.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOW_FALLING,35,0));
            case TEMPEST_WARLORD -> t.addStatusEffect(new StatusEffectInstance(StatusEffects.WEAKNESS,45,phase>=4?1:0));
            case LIGHTNING_DRAGON -> t.addStatusEffect(new StatusEffectInstance(StatusEffects.GLOWING,55,0));
            case ASTRAL_STORMCALLER -> t.addStatusEffect(new StatusEffectInstance(StatusEffects.DARKNESS,35,0));
            case EYE_GUARDIAN -> t.addStatusEffect(new StatusEffectInstance(StatusEffects.BLINDNESS,30,0));
            case FORGOTTEN_SKY_KING -> t.addStatusEffect(new StatusEffectInstance(StatusEffects.WITHER,35,phase>=5?1:0));
            case HEART_OF_STORMREACH -> t.addStatusEffect(new StatusEffectInstance(StatusEffects.WEAKNESS,50,phase>=4?2:1));
        }
    }
    private void useSignatureAbility(){
        PlayerEntity t=getTarget(); if(t==null)return;
        switch(kind){
            case THUNDER_KING -> lightningRing(t,phase+2,7+phase*2);
            case SKY_SERPENT -> diveStrike(t);
            case STORM_TITAN -> shockwave(t,9+phase*2,10+phase*2);
            case CLOUD_EMPRESS -> cloudPrison(t);
            case TEMPEST_WARLORD -> warlordRush(t);
            case LIGHTNING_DRAGON -> lightningBreath(t);
            case ASTRAL_STORMCALLER -> meteorBurst(t);
            case EYE_GUARDIAN -> eyeBeam(t);
            case FORGOTTEN_SKY_KING -> summonRoyalGuards(t);
            case HEART_OF_STORMREACH -> heartNova(t);
        }
    }
    private void lightningRing(PlayerEntity t,int count,double damage){
        for(int i=0;i<count;i++){double a=(Math.PI*2*i)/count;double x=t.getX()+Math.cos(a)*4,y=t.getY(),z=t.getZ()+Math.sin(a)*4;getWorld().addParticle(ParticleTypes.ELECTRIC_SPARK,x,y+1,z,0,.3,0);if(t.squaredDistanceTo(x,y,z)<4*4)t.damage(getWorld().getDamageSources().lightningBolt(),(float)damage);}
    }
    private void diveStrike(PlayerEntity t){
        setVelocity(0,0.9,0); getWorld().addParticle(ParticleTypes.CLOUD,getX(),getY()+2,getZ(),0,0.2,0); t.damage(getWorld().getDamageSources().mobAttack(this),10+phase*4);
    }
    private void shockwave(PlayerEntity t,double radius,double damage){
        for(int i=0;i<40;i++){double a=i*Math.PI*2/40;getWorld().addParticle(ParticleTypes.CLOUD,getX()+Math.cos(a)*radius/2,getY()+.2,getZ()+Math.sin(a)*radius/2,0,.1,0);}
        for(PlayerEntity p:getWorld().getPlayers())if(p.squaredDistanceTo(getX(),getY(),getZ())<=radius*radius)p.damage(getWorld().getDamageSources().mobAttack(this),(float)damage);
    }
    private void cloudPrison(PlayerEntity t){
        t.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS,90,3)); t.addStatusEffect(new StatusEffectInstance(StatusEffects.LEVITATION,45,0));
        for(int i=0;i<60;i++)getWorld().addParticle(ParticleTypes.CLOUD,t.getX()+getRandom().nextGaussian()*3,t.getY()+getRandom().nextDouble()*3,t.getZ()+getRandom().nextGaussian()*3,0,.04,0);
    }
    private void warlordRush(PlayerEntity t){
        setVelocity((t.getX()-getX())*.18,.18,(t.getZ()-getZ())*.18);t.damage(getWorld().getDamageSources().mobAttack(this),12+phase*3);
    }
    private void lightningBreath(PlayerEntity t){
        Box box=t.getBoundingBox().expand(5+phase);for(PlayerEntity p:getWorld().getPlayers())if(box.intersects(p.getBoundingBox()))p.damage(getWorld().getDamageSources().magic(),14+phase*4);
        for(int i=0;i<70;i++)getWorld().addParticle(ParticleTypes.ELECTRIC_SPARK,t.getX()+getRandom().nextGaussian()*2,t.getY()+1,t.getZ()+getRandom().nextGaussian()*2,0,.2,0);
    }
    private void meteorBurst(PlayerEntity t){
        for(int i=0;i<phase+2;i++){double x=t.getX()+getRandom().nextGaussian()*5,z=t.getZ()+getRandom().nextGaussian()*5;for(int j=0;j<12;j++)getWorld().addParticle(ParticleTypes.END_ROD,x,getY()+j*.6,z,0,.05,0);}t.damage(getWorld().getDamageSources().magic(),12+phase*4);
    }
    private void eyeBeam(PlayerEntity t){
        t.addStatusEffect(new StatusEffectInstance(StatusEffects.BLINDNESS,55,0));t.damage(getWorld().getDamageSources().magic(),16+phase*3);
        for(int i=0;i<80;i++){double f=i/20.0;getWorld().addParticle(ParticleTypes.END_ROD,getX()+(t.getX()-getX())*f/4,getY()+1+(t.getY()-getY())*f/4,getZ()+(t.getZ()-getZ())*f/4,0,0,0);}
    }
    private void summonRoyalGuards(PlayerEntity t){
        for(int i=0;i<Math.min(phase,4);i++){getWorld().addParticle(ParticleTypes.SOUL_FIRE_FLAME,t.getX()+getRandom().nextGaussian()*4,t.getY()+1,t.getZ()+getRandom().nextGaussian()*4,0,.1,0);}
        t.addStatusEffect(new StatusEffectInstance(StatusEffects.WITHER,45,phase>=4?1:0));
    }
    private void heartNova(PlayerEntity t){
        shockwave(t,12+phase*2,14+phase*4);if(phase>=4)heal(50);if(phase==5)t.addStatusEffect(new StatusEffectInstance(StatusEffects.BLINDNESS,60,0));
    }

    @Override protected void dropLoot(net.minecraft.entity.damage.DamageSource source,boolean causedByPlayer){
        super.dropLoot(source,causedByPlayer);
        String m=switch(kind){case THUNDER_KING->"thundrium";case SKY_SERPENT->"skysteel";case STORM_TITAN->"stormite";case CLOUD_EMPRESS->"tempest_crystal";case TEMPEST_WARLORD->"thundrium";case LIGHTNING_DRAGON->"stormheart";case ASTRAL_STORMCALLER->"celestium";case EYE_GUARDIAN->"tempest_crystal";case FORGOTTEN_SKY_KING->"celestium";default->"stormheart";};
        drop(new ItemStack(StormreachItems.INGOTS.get(m),4+getRandom().nextInt(7)));
        drop(new ItemStack(StormreachItems.SWORDS.get(m)));
        drop(new ItemStack(StormreachItems.BOSS_RELICS.get(kind)));
        drop(new ItemStack(StormreachItems.BOSS_WEAPONS.get(kind)));
        if(kind==StormreachBossKind.HEART_OF_STORMREACH) drop(new ItemStack(StormreachItems.HEART_SIGIL));
    }
    @Override public void onStartedTrackingBy(net.minecraft.server.network.ServerPlayerEntity p){super.onStartedTrackingBy(p);bar.addPlayer(p);}
    @Override public void onStoppedTrackingBy(net.minecraft.server.network.ServerPlayerEntity p){super.onStoppedTrackingBy(p);bar.removePlayer(p);}
    @Override public void writeCustomDataToNbt(NbtCompound n){super.writeCustomDataToNbt(n);n.putString("StormreachBoss",kind.id);n.putInt("StormreachPhase",phase);n.putInt("StormreachAbilityCooldown",abilityCooldown);}
    @Override public void readCustomDataFromNbt(NbtCompound n){super.readCustomDataFromNbt(n);String id=n.getString("StormreachBoss");for(StormreachBossKind k:StormreachBossKind.values())if(k.id.equals(id))kind=k;phase=n.getInt("StormreachPhase");abilityCooldown=n.getInt("StormreachAbilityCooldown");}
}
