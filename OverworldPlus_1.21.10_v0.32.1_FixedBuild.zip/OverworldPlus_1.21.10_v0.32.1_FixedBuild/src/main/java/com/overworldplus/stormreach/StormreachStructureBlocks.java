package com.overworldplus.stormreach;
import com.overworldplus.OverworldPlus;
import net.minecraft.block.*; import net.minecraft.item.BlockItem; import net.minecraft.registry.*; import net.minecraft.util.Identifier; import java.util.*;
public final class StormreachStructureBlocks {
 public static final Map<StormreachStructureKind,Block> WALL=new EnumMap<>(StormreachStructureKind.class);
 public static final Map<StormreachStructureKind,Block> FLOOR=new EnumMap<>(StormreachStructureKind.class);
 public static final Map<StormreachStructureKind,Block> RELIC=new EnumMap<>(StormreachStructureKind.class);
 private static Block reg(String id, Block b){return Registry.register(Registries.BLOCK,Identifier.of(OverworldPlus.MOD_ID,id),b);}
 static {
  WALL.put(StormreachStructureKind.SKY_CITADEL,reg("sky_citadel_wall",new Block(AbstractBlock.Settings.copy(Blocks.POLISHED_DEEPSLATE).strength(5.5f,25f))));
  FLOOR.put(StormreachStructureKind.SKY_CITADEL,reg("sky_citadel_floor",new Block(AbstractBlock.Settings.copy(Blocks.DEEPSLATE_TILES).strength(4.5f,20f))));
  RELIC.put(StormreachStructureKind.SKY_CITADEL,reg("sky_citadel_relic",new Block(AbstractBlock.Settings.copy(Blocks.AMETHYST_BLOCK).strength(3.5f,18f).luminance(s->9))));
  WALL.put(StormreachStructureKind.THUNDER_FORTRESS,reg("thunder_fortress_wall",new Block(AbstractBlock.Settings.copy(Blocks.POLISHED_DEEPSLATE).strength(5.5f,25f))));
  FLOOR.put(StormreachStructureKind.THUNDER_FORTRESS,reg("thunder_fortress_floor",new Block(AbstractBlock.Settings.copy(Blocks.DEEPSLATE_TILES).strength(4.5f,20f))));
  RELIC.put(StormreachStructureKind.THUNDER_FORTRESS,reg("thunder_fortress_relic",new Block(AbstractBlock.Settings.copy(Blocks.AMETHYST_BLOCK).strength(3.5f,18f).luminance(s->9))));
  WALL.put(StormreachStructureKind.TEMPEST_MONASTERY,reg("tempest_monastery_wall",new Block(AbstractBlock.Settings.copy(Blocks.POLISHED_DEEPSLATE).strength(5.5f,25f))));
  FLOOR.put(StormreachStructureKind.TEMPEST_MONASTERY,reg("tempest_monastery_floor",new Block(AbstractBlock.Settings.copy(Blocks.DEEPSLATE_TILES).strength(4.5f,20f))));
  RELIC.put(StormreachStructureKind.TEMPEST_MONASTERY,reg("tempest_monastery_relic",new Block(AbstractBlock.Settings.copy(Blocks.AMETHYST_BLOCK).strength(3.5f,18f).luminance(s->9))));
  WALL.put(StormreachStructureKind.CLOUD_TEMPLE,reg("cloud_temple_wall",new Block(AbstractBlock.Settings.copy(Blocks.POLISHED_DEEPSLATE).strength(5.5f,25f))));
  FLOOR.put(StormreachStructureKind.CLOUD_TEMPLE,reg("cloud_temple_floor",new Block(AbstractBlock.Settings.copy(Blocks.DEEPSLATE_TILES).strength(4.5f,20f))));
  RELIC.put(StormreachStructureKind.CLOUD_TEMPLE,reg("cloud_temple_relic",new Block(AbstractBlock.Settings.copy(Blocks.AMETHYST_BLOCK).strength(3.5f,18f).luminance(s->9))));
  WALL.put(StormreachStructureKind.STORM_CITADEL,reg("storm_citadel_wall",new Block(AbstractBlock.Settings.copy(Blocks.POLISHED_DEEPSLATE).strength(5.5f,25f))));
  FLOOR.put(StormreachStructureKind.STORM_CITADEL,reg("storm_citadel_floor",new Block(AbstractBlock.Settings.copy(Blocks.DEEPSLATE_TILES).strength(4.5f,20f))));
  RELIC.put(StormreachStructureKind.STORM_CITADEL,reg("storm_citadel_relic",new Block(AbstractBlock.Settings.copy(Blocks.AMETHYST_BLOCK).strength(3.5f,18f).luminance(s->9))));
  WALL.put(StormreachStructureKind.CANYON_KEEP,reg("canyon_keep_wall",new Block(AbstractBlock.Settings.copy(Blocks.POLISHED_DEEPSLATE).strength(5.5f,25f))));
  FLOOR.put(StormreachStructureKind.CANYON_KEEP,reg("canyon_keep_floor",new Block(AbstractBlock.Settings.copy(Blocks.DEEPSLATE_TILES).strength(4.5f,20f))));
  RELIC.put(StormreachStructureKind.CANYON_KEEP,reg("canyon_keep_relic",new Block(AbstractBlock.Settings.copy(Blocks.AMETHYST_BLOCK).strength(3.5f,18f).luminance(s->9))));
  WALL.put(StormreachStructureKind.MARSH_SHRINE,reg("marsh_shrine_wall",new Block(AbstractBlock.Settings.copy(Blocks.POLISHED_DEEPSLATE).strength(5.5f,25f))));
  FLOOR.put(StormreachStructureKind.MARSH_SHRINE,reg("marsh_shrine_floor",new Block(AbstractBlock.Settings.copy(Blocks.DEEPSLATE_TILES).strength(4.5f,20f))));
  RELIC.put(StormreachStructureKind.MARSH_SHRINE,reg("marsh_shrine_relic",new Block(AbstractBlock.Settings.copy(Blocks.AMETHYST_BLOCK).strength(3.5f,18f).luminance(s->9))));
  WALL.put(StormreachStructureKind.ASTRAL_OBSERVATORY,reg("astral_observatory_wall",new Block(AbstractBlock.Settings.copy(Blocks.POLISHED_DEEPSLATE).strength(5.5f,25f))));
  FLOOR.put(StormreachStructureKind.ASTRAL_OBSERVATORY,reg("astral_observatory_floor",new Block(AbstractBlock.Settings.copy(Blocks.DEEPSLATE_TILES).strength(4.5f,20f))));
  RELIC.put(StormreachStructureKind.ASTRAL_OBSERVATORY,reg("astral_observatory_relic",new Block(AbstractBlock.Settings.copy(Blocks.AMETHYST_BLOCK).strength(3.5f,18f).luminance(s->9))));
  WALL.put(StormreachStructureKind.SKY_GRAVE_TEMPLE,reg("sky_grave_temple_wall",new Block(AbstractBlock.Settings.copy(Blocks.POLISHED_DEEPSLATE).strength(5.5f,25f))));
  FLOOR.put(StormreachStructureKind.SKY_GRAVE_TEMPLE,reg("sky_grave_temple_floor",new Block(AbstractBlock.Settings.copy(Blocks.DEEPSLATE_TILES).strength(4.5f,20f))));
  RELIC.put(StormreachStructureKind.SKY_GRAVE_TEMPLE,reg("sky_grave_temple_relic",new Block(AbstractBlock.Settings.copy(Blocks.AMETHYST_BLOCK).strength(3.5f,18f).luminance(s->9))));
  WALL.put(StormreachStructureKind.STORMHEART_SANCTUM,reg("stormheart_sanctum_wall",new Block(AbstractBlock.Settings.copy(Blocks.POLISHED_DEEPSLATE).strength(5.5f,25f))));
  FLOOR.put(StormreachStructureKind.STORMHEART_SANCTUM,reg("stormheart_sanctum_floor",new Block(AbstractBlock.Settings.copy(Blocks.DEEPSLATE_TILES).strength(4.5f,20f))));
  RELIC.put(StormreachStructureKind.STORMHEART_SANCTUM,reg("stormheart_sanctum_relic",new Block(AbstractBlock.Settings.copy(Blocks.AMETHYST_BLOCK).strength(3.5f,18f).luminance(s->9))));
  WALL.put(StormreachStructureKind.CROWN_PALACE,reg("crown_palace_wall",new Block(AbstractBlock.Settings.copy(Blocks.POLISHED_DEEPSLATE).strength(5.5f,25f))));
  FLOOR.put(StormreachStructureKind.CROWN_PALACE,reg("crown_palace_floor",new Block(AbstractBlock.Settings.copy(Blocks.DEEPSLATE_TILES).strength(4.5f,20f))));
  RELIC.put(StormreachStructureKind.CROWN_PALACE,reg("crown_palace_relic",new Block(AbstractBlock.Settings.copy(Blocks.AMETHYST_BLOCK).strength(3.5f,18f).luminance(s->9))));
  WALL.put(StormreachStructureKind.EYE_FORTRESS,reg("eye_fortress_wall",new Block(AbstractBlock.Settings.copy(Blocks.POLISHED_DEEPSLATE).strength(5.5f,25f))));
  FLOOR.put(StormreachStructureKind.EYE_FORTRESS,reg("eye_fortress_floor",new Block(AbstractBlock.Settings.copy(Blocks.DEEPSLATE_TILES).strength(4.5f,20f))));
  RELIC.put(StormreachStructureKind.EYE_FORTRESS,reg("eye_fortress_relic",new Block(AbstractBlock.Settings.copy(Blocks.AMETHYST_BLOCK).strength(3.5f,18f).luminance(s->9))));
 }
 public static void register(){for(StormreachStructureKind k:StormreachStructureKind.values()){item(k.id+"_wall",WALL.get(k));item(k.id+"_floor",FLOOR.get(k));item(k.id+"_relic",RELIC.get(k));}}
 private static void item(String id,Block b){Registry.register(Registries.ITEM,Identifier.of(OverworldPlus.MOD_ID,id),new BlockItem(b,new net.minecraft.item.Item.Settings()));}
 private StormreachStructureBlocks(){}
}