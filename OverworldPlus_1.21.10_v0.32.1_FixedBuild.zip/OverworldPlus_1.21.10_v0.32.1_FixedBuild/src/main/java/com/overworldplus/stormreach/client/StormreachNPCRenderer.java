package com.overworldplus.stormreach.client;
import com.overworldplus.OverworldPlus;
import com.overworldplus.stormreach.StormreachNPCEntity;
import net.minecraft.client.render.entity.MobEntityRenderer;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.model.BipedEntityModel;
import net.minecraft.client.render.entity.model.EntityModelLayers;
import net.minecraft.util.Identifier;
public class StormreachNPCRenderer extends MobEntityRenderer<StormreachNPCEntity,BipedEntityModel<StormreachNPCEntity>>{
 public StormreachNPCRenderer(EntityRendererFactory.Context c){super(c,new BipedEntityModel<>(c.getPart(EntityModelLayers.ZOMBIE)),.5f);}
 @Override public Identifier getTexture(StormreachNPCEntity e){return Identifier.of(OverworldPlus.MOD_ID,"textures/entity/stormreach/stormreach_npc.png");}
}
