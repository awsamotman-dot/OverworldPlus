package com.overworldplus.stormreach;
import com.overworldplus.OverworldPlus; import net.minecraft.item.*; import net.minecraft.item.equipment.*; import net.minecraft.registry.*; import net.minecraft.util.Identifier; import java.util.*;
public final class StormreachItems {
 public static final Map<String,Item> INGOTS=new LinkedHashMap<>(), SWORDS=new LinkedHashMap<>(); public static final Map<String,Item[]> ARMOR=new LinkedHashMap<>(); public static final Map<StormreachBossKind,Item> BOSS_RELICS=new EnumMap<>(StormreachBossKind.class), BOSS_WEAPONS=new EnumMap<>(StormreachBossKind.class);
 private static Item reg(String id,Item i){return Registry.register(Registries.ITEM,Identifier.of(OverworldPlus.MOD_ID,id),i);}
 static {
  INGOTS.put("stormite",reg("stormite_ingot",new Item(new Item.Settings().maxCount(64))));
  SWORDS.put("stormite",reg("stormite_stormblade",new SwordItem(ToolMaterial.NETHERITE,9,-2.35f,new Item.Settings().maxCount(1))));
  Item[] a=new Item[4]; a[0]=reg("stormite_helmet",new ArmorItem(ArmorMaterials.NETHERITE,EquipmentType.HELMET,new Item.Settings().maxCount(1))); a[1]=reg("stormite_chestplate",new ArmorItem(ArmorMaterials.NETHERITE,EquipmentType.CHESTPLATE,new Item.Settings().maxCount(1))); a[2]=reg("stormite_leggings",new ArmorItem(ArmorMaterials.NETHERITE,EquipmentType.LEGGINGS,new Item.Settings().maxCount(1))); a[3]=reg("stormite_boots",new ArmorItem(ArmorMaterials.NETHERITE,EquipmentType.BOOTS,new Item.Settings().maxCount(1))); ARMOR.put("stormite",a);
  INGOTS.put("thundrium",reg("thundrium_ingot",new Item(new Item.Settings().maxCount(64))));
  SWORDS.put("thundrium",reg("thundrium_stormblade",new SwordItem(ToolMaterial.NETHERITE,9,-2.35f,new Item.Settings().maxCount(1))));
  Item[] a=new Item[4]; a[0]=reg("thundrium_helmet",new ArmorItem(ArmorMaterials.NETHERITE,EquipmentType.HELMET,new Item.Settings().maxCount(1))); a[1]=reg("thundrium_chestplate",new ArmorItem(ArmorMaterials.NETHERITE,EquipmentType.CHESTPLATE,new Item.Settings().maxCount(1))); a[2]=reg("thundrium_leggings",new ArmorItem(ArmorMaterials.NETHERITE,EquipmentType.LEGGINGS,new Item.Settings().maxCount(1))); a[3]=reg("thundrium_boots",new ArmorItem(ArmorMaterials.NETHERITE,EquipmentType.BOOTS,new Item.Settings().maxCount(1))); ARMOR.put("thundrium",a);
  INGOTS.put("skysteel",reg("skysteel_ingot",new Item(new Item.Settings().maxCount(64))));
  SWORDS.put("skysteel",reg("skysteel_stormblade",new SwordItem(ToolMaterial.NETHERITE,9,-2.35f,new Item.Settings().maxCount(1))));
  Item[] a=new Item[4]; a[0]=reg("skysteel_helmet",new ArmorItem(ArmorMaterials.NETHERITE,EquipmentType.HELMET,new Item.Settings().maxCount(1))); a[1]=reg("skysteel_chestplate",new ArmorItem(ArmorMaterials.NETHERITE,EquipmentType.CHESTPLATE,new Item.Settings().maxCount(1))); a[2]=reg("skysteel_leggings",new ArmorItem(ArmorMaterials.NETHERITE,EquipmentType.LEGGINGS,new Item.Settings().maxCount(1))); a[3]=reg("skysteel_boots",new ArmorItem(ArmorMaterials.NETHERITE,EquipmentType.BOOTS,new Item.Settings().maxCount(1))); ARMOR.put("skysteel",a);
  INGOTS.put("tempest_crystal",reg("tempest_crystal_ingot",new Item(new Item.Settings().maxCount(64))));
  SWORDS.put("tempest_crystal",reg("tempest_crystal_stormblade",new SwordItem(ToolMaterial.NETHERITE,9,-2.35f,new Item.Settings().maxCount(1))));
  Item[] a=new Item[4]; a[0]=reg("tempest_crystal_helmet",new ArmorItem(ArmorMaterials.NETHERITE,EquipmentType.HELMET,new Item.Settings().maxCount(1))); a[1]=reg("tempest_crystal_chestplate",new ArmorItem(ArmorMaterials.NETHERITE,EquipmentType.CHESTPLATE,new Item.Settings().maxCount(1))); a[2]=reg("tempest_crystal_leggings",new ArmorItem(ArmorMaterials.NETHERITE,EquipmentType.LEGGINGS,new Item.Settings().maxCount(1))); a[3]=reg("tempest_crystal_boots",new ArmorItem(ArmorMaterials.NETHERITE,EquipmentType.BOOTS,new Item.Settings().maxCount(1))); ARMOR.put("tempest_crystal",a);
  INGOTS.put("celestium",reg("celestium_ingot",new Item(new Item.Settings().maxCount(64))));
  SWORDS.put("celestium",reg("celestium_stormblade",new SwordItem(ToolMaterial.NETHERITE,9,-2.35f,new Item.Settings().maxCount(1))));
  Item[] a=new Item[4]; a[0]=reg("celestium_helmet",new ArmorItem(ArmorMaterials.NETHERITE,EquipmentType.HELMET,new Item.Settings().maxCount(1))); a[1]=reg("celestium_chestplate",new ArmorItem(ArmorMaterials.NETHERITE,EquipmentType.CHESTPLATE,new Item.Settings().maxCount(1))); a[2]=reg("celestium_leggings",new ArmorItem(ArmorMaterials.NETHERITE,EquipmentType.LEGGINGS,new Item.Settings().maxCount(1))); a[3]=reg("celestium_boots",new ArmorItem(ArmorMaterials.NETHERITE,EquipmentType.BOOTS,new Item.Settings().maxCount(1))); ARMOR.put("celestium",a);
  INGOTS.put("stormheart",reg("stormheart_ingot",new Item(new Item.Settings().maxCount(64))));
  SWORDS.put("stormheart",reg("stormheart_stormblade",new SwordItem(ToolMaterial.NETHERITE,9,-2.35f,new Item.Settings().maxCount(1))));
  Item[] a=new Item[4]; a[0]=reg("stormheart_helmet",new ArmorItem(ArmorMaterials.NETHERITE,EquipmentType.HELMET,new Item.Settings().maxCount(1))); a[1]=reg("stormheart_chestplate",new ArmorItem(ArmorMaterials.NETHERITE,EquipmentType.CHESTPLATE,new Item.Settings().maxCount(1))); a[2]=reg("stormheart_leggings",new ArmorItem(ArmorMaterials.NETHERITE,EquipmentType.LEGGINGS,new Item.Settings().maxCount(1))); a[3]=reg("stormheart_boots",new ArmorItem(ArmorMaterials.NETHERITE,EquipmentType.BOOTS,new Item.Settings().maxCount(1))); ARMOR.put("stormheart",a);
  public static final Item HEART_SIGIL=reg("stormheart_sigil",new Item(new Item.Settings().maxCount(1)));
  static {
   BOSS_RELICS.put(StormreachBossKind.THUNDER_KING,reg("thunder_king_relic",new Item(new Item.Settings().maxCount(1))));
   BOSS_RELICS.put(StormreachBossKind.SKY_SERPENT,reg("sky_serpent_fang",new Item(new Item.Settings().maxCount(1))));
   BOSS_RELICS.put(StormreachBossKind.STORM_TITAN,reg("titan_core",new Item(new Item.Settings().maxCount(1))));
   BOSS_RELICS.put(StormreachBossKind.CLOUD_EMPRESS,reg("empress_crystal",new Item(new Item.Settings().maxCount(1))));
   BOSS_RELICS.put(StormreachBossKind.TEMPEST_WARLORD,reg("warlord_core",new Item(new Item.Settings().maxCount(1))));
   BOSS_RELICS.put(StormreachBossKind.LIGHTNING_DRAGON,reg("lightning_dragon_heart",new Item(new Item.Settings().maxCount(1))));
   BOSS_RELICS.put(StormreachBossKind.ASTRAL_STORMCALLER,reg("astral_core",new Item(new Item.Settings().maxCount(1))));
   BOSS_RELICS.put(StormreachBossKind.EYE_GUARDIAN,reg("eye_of_the_storm",new Item(new Item.Settings().maxCount(1))));
   BOSS_RELICS.put(StormreachBossKind.FORGOTTEN_SKY_KING,reg("ancient_sky_core",new Item(new Item.Settings().maxCount(1))));
   BOSS_RELICS.put(StormreachBossKind.HEART_OF_STORMREACH,reg("heart_of_stormreach",new Item(new Item.Settings().maxCount(1))));
   for(StormreachBossKind k:StormreachBossKind.values()) BOSS_WEAPONS.put(k,reg(k.id+"_weapon",new SwordItem(ToolMaterial.NETHERITE,11,-2.25f,new Item.Settings().maxCount(1))));
  }
 } public static void register(){} private StormreachItems(){}
}
