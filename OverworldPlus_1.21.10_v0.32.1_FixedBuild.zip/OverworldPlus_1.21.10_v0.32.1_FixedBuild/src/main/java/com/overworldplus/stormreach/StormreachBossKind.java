package com.overworldplus.stormreach;
public enum StormreachBossKind {
 THUNDER_KING("thunder_king","The Thunder King"),
 SKY_SERPENT("sky_serpent","The Sky Serpent"),
 STORM_TITAN("storm_titan","The Storm Titan"),
 CLOUD_EMPRESS("cloud_empress","The Cloud Empress"),
 TEMPEST_WARLORD("tempest_warlord","The Tempest Warlord"),
 LIGHTNING_DRAGON("lightning_dragon","The Lightning Dragon"),
 ASTRAL_STORMCALLER("astral_stormcaller","The Astral Stormcaller"),
 EYE_GUARDIAN("eye_guardian","The Eye Guardian"),
 FORGOTTEN_SKY_KING("forgotten_sky_king","The Forgotten Sky King"),
 HEART_OF_STORMREACH("heart_of_stormreach","The Heart of Stormreach");
 public final String id,name; StormreachBossKind(String id,String name){this.id=id;this.name=name;}
}
