package com.overworldplus.stormreach;
import com.overworldplus.OverworldPlus; import net.minecraft.registry.*; import net.minecraft.sound.SoundEvent; import net.minecraft.util.Identifier; import java.util.*;
public final class StormreachSounds {
 public static final Map<String,SoundEvent> AMBIENT=new HashMap<>(),HURT=new HashMap<>(),DEATH=new HashMap<>(),ATTACK=new HashMap<>();
 public static final Map<StormreachBossKind,SoundEvent> BOSS_AMBIENT=new EnumMap<>(StormreachBossKind.class),BOSS_HURT=new EnumMap<>(StormreachBossKind.class),BOSS_DEATH=new EnumMap<>(StormreachBossKind.class),BOSS_PHASE=new EnumMap<>(StormreachBossKind.class);
 private static SoundEvent reg(String id){Identifier i=Identifier.of(OverworldPlus.MOD_ID,id);return Registry.register(Registries.SOUND_EVENT,i,SoundEvent.of(i));}
 public static void register(){for(StormreachCreatureKind k:StormreachCreatureKind.values()){AMBIENT.put(k.id,reg("stormreach."+k.id+".ambient"));HURT.put(k.id,reg("stormreach."+k.id+".hurt"));DEATH.put(k.id,reg("stormreach."+k.id+".death"));ATTACK.put(k.id,reg("stormreach."+k.id+".attack"));}for(StormreachBossKind k:StormreachBossKind.values()){BOSS_AMBIENT.put(k,reg("stormreach.boss."+k.id+".ambient"));BOSS_HURT.put(k,reg("stormreach.boss."+k.id+".hurt"));BOSS_DEATH.put(k,reg("stormreach.boss."+k.id+".death"));BOSS_PHASE.put(k,reg("stormreach.boss."+k.id+".phase"));}}
 private StormreachSounds(){}
}
