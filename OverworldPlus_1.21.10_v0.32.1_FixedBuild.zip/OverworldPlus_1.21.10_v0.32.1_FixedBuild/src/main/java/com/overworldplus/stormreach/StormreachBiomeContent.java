package com.overworldplus.stormreach;

import com.overworldplus.OverworldPlus;
import net.minecraft.block.*;
import net.minecraft.item.BlockItem;
import net.minecraft.registry.*;
import net.minecraft.util.Identifier;
import java.util.*;

/** Eight visual/material families per biome: surface, stone, crystal, wood, leaves, brick, rune and moss. */
public final class StormreachBiomeContent {
 public static final Map<String,Block> STONE=new LinkedHashMap<>(), SOIL=new LinkedHashMap<>(), CRYSTAL=new LinkedHashMap<>(), WOOD=new LinkedHashMap<>(), LEAVES=new LinkedHashMap<>(), BRICK=new LinkedHashMap<>(), RUNE=new LinkedHashMap<>(), MOSS=new LinkedHashMap<>();
 private static final int[] HUES={85,38,210,155,270,120,195,25,100,205,280,95,35,300,225,170,315,45,185,265};
 private static Block reg(String id, AbstractBlock.Settings s){return Registry.register(Registries.BLOCK,Identifier.of(OverworldPlus.MOD_ID,id),new Block(s));}
 private static void add(StormreachBiomeKind k,int i){String p=k.id;int h=HUES[i];
  STONE.put(p,reg(p+"_bedrock",AbstractBlock.Settings.copy(Blocks.STONE).strength(3.8f,10f)));
  SOIL.put(p,reg(p+"_soil",AbstractBlock.Settings.copy(Blocks.GRASS_BLOCK).strength(.9f,3f)));
  CRYSTAL.put(p,reg(p+"_crystal",AbstractBlock.Settings.copy(Blocks.AMETHYST_BLOCK).strength(3f,12f).luminance(s->7)));
  WOOD.put(p,reg(p+"_wood",AbstractBlock.Settings.copy(Blocks.OAK_PLANKS).strength(2.4f,5f)));
  LEAVES.put(p,reg(p+"_leaves",AbstractBlock.Settings.copy(Blocks.OAK_LEAVES).strength(.4f,1f).nonOpaque()));
  BRICK.put(p,reg(p+"_brick",AbstractBlock.Settings.copy(Blocks.POLISHED_DEEPSLATE).strength(4.8f,18f)));
  RUNE.put(p,reg(p+"_rune",AbstractBlock.Settings.copy(Blocks.SCULK).strength(5f,20f).luminance(s->10)));
  MOSS.put(p,reg(p+"_moss",AbstractBlock.Settings.copy(Blocks.MOSS_BLOCK).strength(.7f,2f)));
 }
 static {int i=0;for(StormreachBiomeKind k:StormreachBiomeKind.values())add(k,i++);}
 public static void register(){for(StormreachBiomeKind k:StormreachBiomeKind.values()){String p=k.id;item(p+"_bedrock",STONE.get(p));item(p+"_soil",SOIL.get(p));item(p+"_crystal",CRYSTAL.get(p));item(p+"_wood",WOOD.get(p));item(p+"_leaves",LEAVES.get(p));item(p+"_brick",BRICK.get(p));item(p+"_rune",RUNE.get(p));item(p+"_moss",MOSS.get(p));}}
 private static void item(String id,Block b){Registry.register(Registries.ITEM,Identifier.of(OverworldPlus.MOD_ID,id),new BlockItem(b,new net.minecraft.item.Item.Settings()));}
 private StormreachBiomeContent(){}
}
