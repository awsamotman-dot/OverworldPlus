package com.overworldplus.stormreach;
import com.overworldplus.OverworldPlus; import net.fabricmc.fabric.api.event.lifecycle.v1.ServerChunkEvents; import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents; import net.minecraft.block.*; import net.minecraft.entity.EntityType; import net.minecraft.entity.ItemEntity; import net.minecraft.item.ItemStack; import net.minecraft.particle.ParticleTypes; import net.minecraft.server.network.ServerPlayerEntity; import net.minecraft.server.world.ServerWorld; import net.minecraft.text.Text; import net.minecraft.util.math.BlockPos; import net.minecraft.world.Heightmap; import net.minecraft.entity.attribute.EntityAttributes; import net.minecraft.registry.*; import net.minecraft.world.World; import java.util.*;
public final class StormreachWorldSystems {private static final Set<Long> POP=Collections.synchronizedSet(new HashSet<>()); private static final Map<String,StormreachCreatureKind> MOB=new HashMap<>(); static{for(StormreachCreatureKind k:StormreachCreatureKind.values())MOB.put(k.biome,k);} public static void register(){ServerChunkEvents.CHUNK_LOAD.register((w,c)->{if(!(w instanceof ServerWorld sw)||!isStorm(sw))return;long key=(((long)c.getPos().x)<<32)^(c.getPos().z&0xffffffffL);if(POP.add(key))populate(sw,c.getPos().x,c.getPos().z);});ServerTickEvents.END_WORLD_TICK.register(StormreachWorldSystems::tick);}
 private static boolean isStorm(ServerWorld w){return w.getRegistryKey().getValue().getPath().equals("stormreach");} private static long hash(int x,int z,long s){long h=((long)x*341873128712L)^((long)z*132897987541L)^s;h^=h>>>33;h*=0xff51afd7ed558ccdL;h^=h>>>33;return h;} private static String biome(ServerWorld w,BlockPos p){return w.getBiome(p).getKey().map(k->k.getValue().getPath()).orElse("stormbound_plains");}
 private static void populate(ServerWorld w,int cx,int cz){int x0=cx*16,z0=cz*16;BlockPos p=new BlockPos(x0+8,w.getTopY(Heightmap.Type.WORLD_SURFACE,x0+8,z0+8),z0+8);String b=biome(w,p);long h=hash(cx,cz,w.getSeed());BlockPos marker=new BlockPos(x0+8,Math.max(w.getBottomY()+4,p.getY()-1),z0+8);if(w.getBlockState(marker).isOf(StormreachBlocks.DUNGEON_CORE.get(b)))return;shape(w,x0,z0,b,h);caves(w,x0,z0,b,h);if(Math.floorMod(h,113)==7)structure(w,p,b,h);if(Math.floorMod(h,191)==17)dungeon(w,p,b,h);if(Math.floorMod(h,271)==31)spawnMob(w,p,b,h);if(Math.floorMod(h,631)==19)spawnElite(w,p,b);if(Math.floorMod(h,149)==11)spawnNpc(w,p,h);if(Math.floorMod(h,503)==7)biomeCity(w,p,b,h);if(Math.floorMod(h,367)==11)biomeLandmark(w,p,b,h);if(Math.floorMod(h,313)==19)biomeDungeon(w,p,b,h);oreVeins(w,x0,z0,b,h);w.setBlockState(new BlockPos(x0+8,Math.max(w.getBottomY()+2,p.getY()-8),z0+8),StormreachBlocks.DUNGEON_CORE.get(b).getDefaultState());}
 private static double smooth(double t){return t*t*(3.0-2.0*t);}
 private static double valueNoise(int x,int z,long seed,int scale){int gx=Math.floorDiv(x,scale),gz=Math.floorDiv(z,scale);double fx=(double)Math.floorMod(x,scale)/scale,fz=(double)Math.floorMod(z,scale)/scale;double a=unit(gx,gz,seed),bb=unit(gx+1,gz,seed),c=unit(gx,gz+1,seed),d=unit(gx+1,gz+1,seed);double ux=smooth(fx),uz=smooth(fz);return (a+(bb-a)*ux)+((c+(d-c)*ux)-(a+(bb-a)*ux))*uz;}
 private static double unit(int x,int z,long seed){long h=hash(x,z,seed);return ((h>>>11)&0x1fffff)/1048575.0*2.0-1.0;}
 private static double fractal(int x,int z,long seed,int base){double n=valueNoise(x,z,seed,base)*0.55;n+=valueNoise(x,z,seed^0x5deece66dL,base/2)*0.3;n+=valueNoise(x,z,seed^0x1234abcdL,base/4)*0.15;return n;}
 private static double terrainProfile(String b,double continent,double macro,double detail,double ridge,double canyon,double x,double z,long seed){
  double waves=Math.sin(x*0.018+seed*0.00000013)+Math.cos(z*0.021-seed*0.00000009);
  double ridges=Math.abs(Math.sin(x*0.011+z*0.007))+Math.abs(Math.cos(z*0.014-x*0.006));
  return switch(b){
   case "stormbound_plains" -> continent*22+macro*12+detail*7+ridge*12;
   case "thundersteppe" -> continent*20+macro*16+detail*5+Math.sin(x*.035+z*.012)*11;
   case "tempest_highlands" -> continent*26+macro*22+ridge*24+detail*8;
   case "skyreach_isles" -> continent*12+macro*8+detail*6+Math.max(0,waves)*13;
   case "celestial_peaks" -> continent*18+macro*28+ridge*38+Math.max(0,detail)*20;
   case "lightning_forest" -> continent*24+macro*15+detail*9+Math.sin(x*.027)*8;
   case "cloudsea" -> continent*8+macro*5+detail*3-Math.abs(canyon)*7;
   case "stormscar_canyon" -> continent*18+macro*15-detail*4-Math.abs(canyon)*62-ridge*18;
   case "thunder_marshes" -> continent*9+macro*6+detail*3-Math.abs(canyon)*18;
   case "azure_expanse" -> continent*6+macro*4+detail*2-Math.abs(canyon)*8;
   case "floating_kingdoms" -> continent*13+macro*9+detail*7+Math.max(0,waves)*15;
   case "tempest_jungle" -> continent*22+macro*20+detail*12+Math.sin(x*.019)*9;
   case "stormforged_mountains" -> continent*24+macro*30+ridge*45+Math.max(0,detail)*24;
   case "eye_of_the_storm" -> continent*18+macro*12+detail*8+22-Math.abs(canyon)*72-ridge*10;
   case "astral_coast" -> continent*7+macro*5+detail*4-Math.abs(canyon)*10+Math.sin(x*.012)*5;
   case "thunderfall_valley" -> continent*17+macro*14+detail*6-Math.abs(canyon)*58-ridge*15;
   case "skygrave" -> continent*15+macro*18+ridge*30+Math.max(0,detail)*10;
   case "eternal_tempest" -> continent*28+macro*24+ridge*32+Math.sin(x*.025+z*.019)*14;
   case "stormheart_basin" -> continent*24+macro*18+detail*10-Math.abs(canyon)*48-ridge*22;
   case "storm_crown" -> continent*22+macro*26+ridge*52+Math.max(0,detail)*28;
   default -> continent*24+macro*16+detail*8+ridge*12;
  };
 }
 private static void shape(ServerWorld w,int x0,int z0,String b,long seed){
  Block stone=StormreachBiomeContent.STONE.get(b),soil=StormreachBiomeContent.SOIL.get(b),cr=StormreachBiomeContent.CRYSTAL.get(b);
  int mode=MOB.get(b)==null?0:MOB.get(b).ordinal();
  boolean sky=b.equals("skyreach_isles")||b.equals("floating_kingdoms")||b.equals("cloudsea")||b.equals("skygrave");
  boolean water=b.equals("cloudsea")||b.equals("azure_expanse")||b.equals("astral_coast")||b.equals("thunder_marshes");
  for(int dx=0;dx<16;dx++)for(int dz=0;dz<16;dz++){
   int x=x0+dx,z=z0+dz,top=w.getTopY(Heightmap.Type.WORLD_SURFACE,x,z);
   double continent=fractal(x,z,seed^0x4f1bbcdcL,768);
   double macro=fractal(x,z,seed^0x72d5a17bL,320);
   double detail=fractal(x,z,seed^(0x5deece66dL+mode*7919L),96);
   double ridge=1.0-Math.abs(fractal(x,z,seed^0x55aa11L,160));
   double canyon=fractal(x,z,seed^0x9e3779b9L,72);
   double land=terrainProfile(b,continent,macro,detail,ridge,canyon,x,z,seed)-12.0;
   int target=(int)Math.round(72+land);
   if(water)target=Math.min(target,b.equals("cloudsea")?68:62);
   if(b.equals("stormscar_canyon")||b.equals("thunderfall_valley"))target-=Math.max(0,(int)(Math.abs(canyon)*18));
   if(b.equals("stormheart_basin"))target-=Math.max(0,(int)(ridge*16));
   target=Math.max(w.getBottomY()+6,Math.min(w.getTopY()-10,target));
   if(target>top){for(int y=top;y<=target;y++)w.setBlockState(new BlockPos(x,y,z),(y==target?soil:stone).getDefaultState());}
   else if(target<top-1){for(int y=top;y>target;y--)w.setBlockState(new BlockPos(x,y,z),Blocks.AIR.getDefaultState());w.setBlockState(new BlockPos(x,target,z),soil.getDefaultState());}
   if(water && target<(b.equals("cloudsea")?67:61)){int sea=b.equals("cloudsea")?67:61;for(int y=target+1;y<=sea;y++)w.setBlockState(new BlockPos(x,y,z),Blocks.WATER.getDefaultState());}
   // Biome signatures: stable, seed-dependent formations that make each biome visually distinct.
   long q=hash(x,z,seed^0x7f4a7c15L);
   if(Math.floorMod(q,211)==9&&target>w.getBottomY()+4)w.setBlockState(new BlockPos(x,target+1,z),cr.getDefaultState());
   if(b.equals("stormscar_canyon")&&Math.floorMod(q,17)==2)for(int y=target-2;y<=target+2;y++)if(y>w.getBottomY())w.setBlockState(new BlockPos(x,y,z),stone.getDefaultState());
   if(b.equals("thunderfall_valley")&&Math.floorMod(q,19)==3)for(int y=target-3;y<=target;y++)if(y>w.getBottomY())w.setBlockState(new BlockPos(x,y,z),Blocks.WATER.getDefaultState());
   if((b.equals("stormheart_basin")||b.equals("eye_of_the_storm"))&&Math.floorMod(q,29)==4)for(int y=target-1;y<=target+2;y++)if(y>w.getBottomY())w.setBlockState(new BlockPos(x,y,z),cr.getDefaultState());
   if((mode==3||mode==10||mode==19)&&Math.floorMod(hash(x,z,seed^99),83)==2)for(int y=target-2;y<=target;y++)if(y>w.getBottomY())w.setBlockState(new BlockPos(x,y,z),Blocks.WATER.getDefaultState());
   if(sky){double island=valueNoise(x,z,seed^0x6a09e667L,256)+0.42*valueNoise(x,z,seed^0xbb67ae85L,96);if(island>0.58){int iy=126+(int)Math.round(island*42.0)+Math.floorMod((int)hash(x>>4,z>>4,seed),20);int thickness=5+(int)Math.floorMod(hash(x,z,seed^77),10);double edge=valueNoise(x,z,seed^0x3c6ef372L,56);if(edge> -0.55){for(int y=iy-thickness;y<=iy;y++){double fall=(iy-y)/(double)Math.max(1,thickness);if(fall<0.92)w.setBlockState(new BlockPos(x,y,z),(y==iy?soil:stone).getDefaultState());}if(Math.floorMod(hash(x,z,seed^88),43)==3)w.setBlockState(new BlockPos(x,iy+1,z),cr.getDefaultState());}}}
  }
 }
 private static void caves(ServerWorld w,int x0,int z0,String b,long seed){long h=hash(x0>>4,z0>>4,seed^0x9e3779b97f4a7c15L);if(Math.floorMod(h,3)!=0)return;int cx=x0+4+(int)Math.floorMod(h,8),cz=z0+4+(int)Math.floorMod(h>>8,8),cy=12+(int)Math.floorMod(h>>16,58);int chambers=5+(int)Math.floorMod(h,4);for(int i=0;i<chambers;i++){double a=i*Math.PI*2.0/chambers;int tx=cx+(int)Math.round(Math.cos(a)*(16+i*3)),tz=cz+(int)Math.round(Math.sin(a)*(16+i*3)),ty=cy+(int)Math.floorMod(h>>(i*5),15)-7;carve(w,cx,cy,cz,5+(i%3),4+(i%2),5+(i%3));carve(w,tx,ty,tz,6,4,6);tunnel(w,cx,cy,cz,tx,ty,tz);decorateCave(w,tx,ty,tz,b,h+i);}if(b.contains("marsh")||b.equals("cloudsea")||b.equals("azure_expanse")||b.equals("astral_coast")){for(int dx=-5;dx<=5;dx++)for(int dz=-5;dz<=5;dz++)if(dx*dx+dz*dz<25)w.setBlockState(new BlockPos(cx+dx,cy-4,cz+dz),Blocks.WATER.getDefaultState());}if(Math.floorMod(h,5)==2)spawnMob(w,new BlockPos(cx,cy,cz),b,h);}
 private static void decorateCave(ServerWorld w,int x,int y,int z,String b,long h){Block cr=sb(b,StormreachBiomeContent.CRYSTAL),moss=sb(b,StormreachBiomeContent.MOSS),rune=sb(b,StormreachBiomeContent.RUNE);for(int i=0;i<12;i++){int dx=(int)Math.floorMod(hash(x+i,z-i,h),11)-5,dz=(int)Math.floorMod(hash(x-i,z+i,h^33),11)-5;BlockPos q=new BlockPos(x+dx,y+(int)Math.floorMod(h+i,5)-2,z+dz);if(w.getBlockState(q).isAir())w.setBlockState(q,cr.getDefaultState());if(i%3==0&&w.getBlockState(q.down()).isAir())w.setBlockState(q.down(),moss.getDefaultState());}if(Math.floorMod(h,7)==1)w.setBlockState(new BlockPos(x,y+2,z),rune.getDefaultState());}
 private static void carve(ServerWorld w,int cx,int cy,int cz,int rx,int ry,int rz){for(int x=-rx;x<=rx;x++)for(int y=-ry;y<=ry;y++)for(int z=-rz;z<=rz;z++)if((x*x)/(double)(rx*rx)+(y*y)/(double)(ry*ry)+(z*z)/(double)(rz*rz)<1)w.setBlockState(new BlockPos(cx+x,cy+y,cz+z),Blocks.AIR.getDefaultState());} private static void tunnel(ServerWorld w,int x1,int y1,int z1,int x2,int y2,int z2){int s=Math.max(Math.abs(x2-x1),Math.max(Math.abs(y2-y1),Math.abs(z2-z1)));for(int i=0;i<=s;i++){double t=s==0?0:(double)i/s;carve(w,(int)Math.round(x1+(x2-x1)*t),(int)Math.round(y1+(y2-y1)*t),(int)Math.round(z1+(z2-z1)*t),2,2,2);}}
 private static void structure(ServerWorld w,BlockPos p,String b,long h){
  StormreachStructureKind sk=StormreachStructureKind.forBiome(b);
  Block wall=StormreachStructureBlocks.WALL.get(sk), floor=StormreachStructureBlocks.FLOOR.get(sk), relic=StormreachStructureBlocks.RELIC.get(sk);
  int r=10+(int)Math.floorMod(h,9), height=7+(int)Math.floorMod(h>>8,6);
  for(int x=-r;x<=r;x++)for(int z=-r;z<=r;z++){boolean edge=Math.abs(x)==r||Math.abs(z)==r; if(edge)for(int y=0;y<=height;y++)w.setBlockState(p.add(x,y,z),wall.getDefaultState()); else w.setBlockState(p.add(x,0,z),floor.getDefaultState());}
  for(int y=1;y<height;y+=2){for(int x=-r+2;x<=r-2;x+=4){w.setBlockState(p.add(x,y,-r+1),relic.getDefaultState());w.setBlockState(p.add(x,y,r-1),relic.getDefaultState());}for(int z=-r+2;z<=r-2;z+=4){w.setBlockState(p.add(-r+1,y,z),relic.getDefaultState());w.setBlockState(p.add(r-1,y,z),relic.getDefaultState());}}
  for(int x=-2;x<=2;x++)for(int z=-2;z<=2;z++)w.setBlockState(p.add(x,height,z),relic.getDefaultState());
  // Four guards + one stronger warden; every structure therefore has its own enemy family.
  for(int i=0;i<4;i++){BlockPos q=p.add((i%2==0?-r+3:r-3),1,(i<2?-r+3:r-3));spawnStructureMob(w,q,sk);}
  spawnStructureMiniBoss(w,p.up(1),sk);
}
 private static void dungeon(ServerWorld w,BlockPos p,String b,long h){Block core=StormreachBlocks.DUNGEON_CORE.get(b),stone=StormreachBlocks.BIOME_STONE.get(b);BlockPos c=p.down(18);for(int i=0;i<7;i++){BlockPos r=c.add((i%3)*14,(i==6?-2:0),(i/3)*14);for(int x=-6;x<=6;x++)for(int y=-3;y<=5;y++)for(int z=-6;z<=6;z++){boolean shell=Math.abs(x)==6||Math.abs(z)==6||y==-3||y==5;w.setBlockState(r.add(x,y,z),shell?core.getDefaultState():Blocks.AIR.getDefaultState());}w.setBlockState(r.up(4),stone.getDefaultState());if(i<6)tunnel(w,r.getX(),r.getY(),r.getZ(),c.add(((i+1)%3)*14,0,((i+1)/3)*14).getX(),c.getY(),c.add(((i+1)%3)*14,0,((i+1)/3)*14).getZ());}/* Main bosses are placed by deterministic seed-based world sites, not by every dungeon. */}
 private static void spawnStructureMob(ServerWorld w,BlockPos p,StormreachStructureKind k){EntityType<StormreachStructureMobEntity> t=OverworldPlus.STORMREACH_STRUCTURE_MOBS.get(k);if(t==null)return;StormreachStructureMobEntity e=new StormreachStructureMobEntity(t,w,k);e.refreshPositionAndAngles(p.getX()+.5,p.getY()+1,p.getZ()+.5,0,0);w.spawnEntity(e);}
 private static void spawnStructureMiniBoss(ServerWorld w,BlockPos p,StormreachStructureKind k){EntityType<StormreachStructureMiniBossEntity> t=OverworldPlus.STORMREACH_STRUCTURE_MINI_BOSSES.get(k);if(t==null)return;StormreachStructureMiniBossEntity e=new StormreachStructureMiniBossEntity(t,w,k);e.refreshPositionAndAngles(p.getX()+.5,p.getY()+1,p.getZ()+.5,0,0);w.spawnEntity(e);}
 private static void spawnMob(ServerWorld w,BlockPos p,String b,long h){StormreachCreatureKind k=MOB.get(b);EntityType<StormreachCreatureEntity> t=OverworldPlus.STORMREACH_CREATURES.get(k);if(t==null)return;StormreachCreatureEntity e=new StormreachCreatureEntity(t,w,k);e.refreshPositionAndAngles(p.getX()+.5,p.getY()+1,p.getZ()+.5,0,0);w.spawnEntity(e);}
 private static void spawnElite(ServerWorld w,BlockPos p,String b){StormreachCreatureKind k=MOB.get(b);EntityType<StormreachCreatureEntity> t=OverworldPlus.STORMREACH_CREATURES.get(k);if(t==null)return;StormreachCreatureEntity e=new StormreachCreatureEntity(t,w,k);e.setElite(true);e.refreshPositionAndAngles(p.getX()+.5,p.getY()+1,p.getZ()+.5,0,0);w.spawnEntity(e);}
 private static void spawnNpc(ServerWorld w,BlockPos p,long h){if(OverworldPlus.STORMREACH_NPC==null)return;StormreachNPCEntity e=new StormreachNPCEntity(OverworldPlus.STORMREACH_NPC,w);e.setProfession(StormreachNpcProfession.values()[(int)Math.floorMod(h,StormreachNpcProfession.values().length)]);e.refreshPositionAndAngles(p.getX()+2.5,p.getY()+1,p.getZ()+2.5,0,0);w.spawnEntity(e);}
 private static void tryMainBossSite(ServerWorld w,int cx,int cz){
  long seed=w.getSeed();
  for(int i=0;i<StormreachBossKind.values().length;i++){
   long a=hash((int)(seed+i*0x45d9f3bL),(int)(seed^(i*0x27d4eb2dL)),seed^0x6a09e667L);
   int targetX=(int)Math.floorMod(a,4096)-2048;
   int targetZ=(int)Math.floorMod(a>>>32,4096)-2048;
   if(Math.abs(cx-targetX)>0||Math.abs(cz-targetZ)>0)continue;
   StormreachBossKind k=StormreachBossKind.values()[i];
   BlockPos center=new BlockPos(cx*16+8,w.getTopY(Heightmap.Type.WORLD_SURFACE,cx*16+8,cz*16+8)+2,cz*16+8);
   if(!isBossSiteSuitable(w,center,k))return;
   BlockPos marker=center.down();
   if(w.getBlockState(marker).isOf(StormreachBlocks.DUNGEON_CORE.get(biome(w,center))))return;
   buildBossArena(w,center,k);
   w.setBlockState(marker,StormreachBlocks.DUNGEON_CORE.get(biome(w,center)).getDefaultState());
   EntityType<StormreachBossEntity> t=OverworldPlus.STORMREACH_BOSSES.get(k);if(t==null)return;
   StormreachBossEntity e=new StormreachBossEntity(t,w,k);e.refreshPositionAndAngles(center.getX()+.5,center.getY()+1,center.getZ()+.5,0,0);e.setPersistent();w.spawnEntity(e);
   return;
  }
 }
 private static boolean isBossSiteSuitable(ServerWorld w,BlockPos p,StormreachBossKind k){
  String b=biome(w,p);return switch(k){
   case THUNDER_KING->b.equals("thundersteppe")||b.equals("stormbound_plains");
   case SKY_SERPENT->b.equals("skyreach_isles")||b.equals("cloudsea");
   case STORM_TITAN->b.equals("stormforged_mountains")||b.equals("tempest_highlands");
   case CLOUD_EMPRESS->b.equals("floating_kingdoms")||b.equals("cloudsea");
   case TEMPEST_WARLORD->b.equals("tempest_highlands")||b.equals("thundersteppe");
   case LIGHTNING_DRAGON->b.equals("eternal_tempest");
   case ASTRAL_STORMCALLER->b.equals("astral_coast");
   case EYE_GUARDIAN->b.equals("eye_of_the_storm");
   case FORGOTTEN_SKY_KING->b.equals("skygrave");
   case HEART_OF_STORMREACH->b.equals("stormheart_basin")||b.equals("storm_crown");
  };}
 private static void spawnBoss(ServerWorld w,BlockPos p,int idx){StormreachBossKind k=StormreachBossKind.values()[idx];EntityType<StormreachBossEntity> t=OverworldPlus.STORMREACH_BOSSES.get(k);if(t==null)return;buildBossArena(w,p,k);StormreachBossEntity e=new StormreachBossEntity(t,w,k);e.refreshPositionAndAngles(p.getX()+.5,p.getY()+1,p.getZ()+.5,0,0);w.spawnEntity(e);}
 private static void buildBossArena(ServerWorld w,BlockPos p,StormreachBossKind k){
  String b=switch(k){case THUNDER_KING->"thundersteppe";case SKY_SERPENT->"skyreach_isles";case STORM_TITAN->"stormforged_mountains";case CLOUD_EMPRESS->"floating_kingdoms";case TEMPEST_WARLORD->"tempest_highlands";case LIGHTNING_DRAGON->"eternal_tempest";case ASTRAL_STORMCALLER->"astral_coast";case EYE_GUARDIAN->"eye_of_the_storm";case FORGOTTEN_SKY_KING->"skygrave";case HEART_OF_STORMREACH->"stormheart_basin";};
  Block floor=StormreachBiomeContent.STONE.get(b), rune=StormreachBiomeContent.RUNE.get(b), crystal=StormreachBiomeContent.CRYSTAL.get(b); int r=13;
  for(int x=-r;x<=r;x++)for(int z=-r;z<=r;z++){double d=Math.sqrt(x*x+z*z);if(d<=r)w.setBlockState(p.add(x,0,z),floor.getDefaultState());}
  for(int x=-r;x<=r;x++)for(int z=-r;z<=r;z++){double d=Math.sqrt(x*x+z*z);if(d>r-1&&d<=r+1)for(int y=1;y<=4;y++)w.setBlockState(p.add(x,y,z),rune.getDefaultState());}
  int pillars=switch(k){case LIGHTNING_DRAGON,HEART_OF_STORMREACH->8;case STORM_TITAN,FORGOTTEN_SKY_KING->6;default->4;};
  for(int i=0;i<pillars;i++){double a=i*Math.PI*2/pillars;int x=(int)Math.round(Math.cos(a)*9),z=(int)Math.round(Math.sin(a)*9);for(int y=1;y<=5+(i%3);y++)w.setBlockState(p.add(x,y,z),crystal.getDefaultState());}
  w.setBlockState(p.up(5),crystal.getDefaultState());
 }
 
 private static StormreachBiomeKind profile(String b){return StormreachBiomeKind.byId(b);}
 private static Block sb(String b, Map<String,Block> map){return map.getOrDefault(b,Blocks.STONE);}
 private static void biomeCity(ServerWorld w,BlockPos p,String b,long h){
  StormreachBiomeKind k=profile(b); Block brick=sb(b,StormreachBiomeContent.BRICK),floor=sb(b,StormreachBiomeContent.WOOD),rune=sb(b,StormreachBiomeContent.RUNE),soil=sb(b,StormreachBiomeContent.SOIL),stone=sb(b,StormreachBiomeContent.STONE);
  int r=16+(int)Math.floorMod(h,8); BlockPos c=p.add(0,1,0);
  for(int x=-r;x<=r;x++)for(int z=-r;z<=r;z++){double d=Math.max(Math.abs(x),Math.abs(z)); if(d==r||d==r-1)w.setBlockState(c.add(x,0,z),brick.getDefaultState()); else if(d<r-2)w.setBlockState(c.add(x,0,z),floor.getDefaultState());}
  for(int x=-2;x<=2;x++)for(int z=-2;z<=2;z++)w.setBlockState(c.add(x,1,z),rune.getDefaultState());
  int[][] houses={{-11,-11},{11,-11},{-11,11},{11,11}};
  for(int[] q:houses) cityHouse(w,c.add(q[0],0,q[1]),brick,floor,rune,soil,Math.floorMod(h+q[0]*31L+q[1],3)+1);
  for(int i=0;i<3;i++){BlockPos np=c.add(-2+i*2,1,5);if(w.getBlockState(np).isAir())spawnNpc(w,np,h+i*77);}
  for(int x=-3;x<=3;x++)for(int z=-3;z<=3;z++)if((Math.abs(x)+Math.abs(z))%2==0)w.setBlockState(c.add(x,1,z),rune.getDefaultState());
  w.setBlockState(c.add(0,2,0),sb(b,StormreachBiomeContent.CRYSTAL).getDefaultState());
 }
 private static void cityHouse(ServerWorld w,BlockPos c,Block brick,Block floor,Block rune,Block soil,int style){
  int r=4,h=3+style;for(int x=-r;x<=r;x++)for(int z=-r;z<=r;z++){boolean edge=Math.abs(x)==r||Math.abs(z)==r;for(int y=0;y<=h;y++)if(edge||y==h)w.setBlockState(c.add(x,y,z),y==h?floor.getDefaultState():brick.getDefaultState());else w.setBlockState(c.add(x,y,z),Blocks.AIR.getDefaultState());}
  for(int x=-r+1;x<=r-1;x+=2)for(int z=-r+1;z<=r-1;z+=2)w.setBlockState(c.add(x,h+1,z),rune.getDefaultState());
  w.setBlockState(c.add(0,1,r),Blocks.AIR.getDefaultState());
 }
 private static void biomeLandmark(ServerWorld w,BlockPos p,String b,long h){
  Block brick=sb(b,StormreachBiomeContent.BRICK),floor=sb(b,StormreachBiomeContent.STONE),rune=sb(b,StormreachBiomeContent.RUNE),cr=sb(b,StormreachBiomeContent.CRYSTAL);int r=9+(int)Math.floorMod(h,6),height=8+(int)Math.floorMod(h>>7,8);
  for(int x=-r;x<=r;x++)for(int z=-r;z<=r;z++){if(Math.abs(x)==r||Math.abs(z)==r)for(int y=0;y<=height;y++)w.setBlockState(p.add(x,y,z),brick.getDefaultState());else w.setBlockState(p.add(x,0,z),floor.getDefaultState());}
  for(int i=0;i<4;i++){int dx=i<2?-r+2:r-2,dz=i%2==0?-r+2:r-2;for(int y=height/2;y<=height+2;y++)w.setBlockState(p.add(dx,y,dz),rune.getDefaultState());}
  for(int y=1;y<height;y+=2)for(int a=0;a<8;a++){double ang=a*Math.PI/4;int x=(int)Math.round(Math.cos(ang)*(r-2)),z=(int)Math.round(Math.sin(ang)*(r-2));w.setBlockState(p.add(x,y,z),cr.getDefaultState());}
  w.setBlockState(p.up(height+2),cr.getDefaultState());
  spawnBiomeMiniBoss(w,p.up(1),b);
  for(int i=0;i<4;i++)spawnMob(w,p.add(-3+i*2,1,-r+3),b,h+i);
 }
 private static void biomeDungeon(ServerWorld w,BlockPos p,String b,long h){
  Block brick=sb(b,StormreachBiomeContent.BRICK),floor=sb(b,StormreachBiomeContent.STONE),rune=sb(b,StormreachBiomeContent.RUNE),cr=sb(b,StormreachBiomeContent.CRYSTAL);BlockPos c=p.down(24);int rooms=9;
  for(int i=0;i<rooms;i++){int gx=(i%3)*16-16,gz=(i/3)*16-16,gy=(i==8?2:0);BlockPos r=c.add(gx,gy,gz);for(int x=-6;x<=6;x++)for(int z=-6;z<=6;z++)for(int y=-3;y<=5;y++){boolean wall=Math.abs(x)==6||Math.abs(z)==6||y==-3||y==5;w.setBlockState(r.add(x,y,z),wall?brick.getDefaultState():floor.getDefaultState());if(!wall&&y<4)w.setBlockState(r.add(x,y+1,z),Blocks.AIR.getDefaultState());}w.setBlockState(r.up(4),cr.getDefaultState());if(i<8){int nx=((i+1)%3)*16-16,nz=((i+1)/3)*16-16;tunnel(w,r.getX(),r.getY(),r.getZ(),c.getX()+nx,c.getY()+gy,c.getZ()+nz);}if(i%2==0)spawnMob(w,r.add(0,1,0),b,h+i*17);}
  BlockPos boss=c.add(16,2,16);for(int x=-7;x<=7;x++)for(int z=-7;z<=7;z++)if(Math.abs(x)==7||Math.abs(z)==7)for(int y=0;y<=5;y++)w.setBlockState(boss.add(x,y,z),rune.getDefaultState());w.setBlockState(boss.up(5),cr.getDefaultState());spawnBiomeMiniBoss(w,boss.up(1),b);
 }
 private static void spawnBiomeMiniBoss(ServerWorld w,BlockPos p,String b){for(StormreachBiomeMiniBossKind k:StormreachBiomeMiniBossKind.values())if(k.biome.equals(b)){EntityType<StormreachBiomeMiniBossEntity> t=OverworldPlus.STORMREACH_BIOME_MINI_BOSSES.get(k);if(t==null)return;StormreachBiomeMiniBossEntity e=new StormreachBiomeMiniBossEntity(t,w,k);e.refreshPositionAndAngles(p.getX()+.5,p.getY()+1,p.getZ()+.5,0,0);w.spawnEntity(e);return;}}
 private static void oreVeins(ServerWorld w,int x0,int z0,String b,long seed){
  for(String ore:new String[]{"stormite","thundrium","skysteel","tempest_crystal","celestium","stormheart"}){
   Block ob=StormreachBlocks.ORES.get(ore); if(ob==null)continue;
   int rarity=ore.equals("stormheart")?97:ore.equals("celestium")?61:37;
   for(int i=0;i<2;i++){long h=hash(x0+i*17,z0-i*23,seed^ore.hashCode());if(Math.floorMod(h,rarity)!=i)continue;int x=x0+2+(int)Math.floorMod(h,12),z=z0+2+(int)Math.floorMod(h>>8,12),y=8+(int)Math.floorMod(h>>16,42);BlockPos base=new BlockPos(x,y,z);for(int dx=-1;dx<=1;dx++)for(int dy=-1;dy<=1;dy++)for(int dz=-1;dz<=1;dz++)if(Math.abs(dx)+Math.abs(dy)+Math.abs(dz)<=2&&w.getBlockState(base.add(dx,dy,dz)).isAir())w.setBlockState(base.add(dx,dy,dz),ob.getDefaultState());}
  }
 }
 private static void tick(ServerWorld w){if(!isStorm(w)||w.getTime()%900!=0)return;for(ServerPlayerEntity p:w.getPlayers()){long h=hash(p.getBlockX()>>4,p.getBlockZ()>>4,w.getSeed()^w.getTime());if(Math.floorMod(h,4)==0){w.setWeather(0,500, true,false);w.spawnParticles(ParticleTypes.ELECTRIC_SPARK,p.getX(),p.getY()+2,p.getZ(),120,6,4,6,.15);p.sendMessage(Text.literal("§bA violent Stormreach storm tears across the sky!"),true);}}}
 private StormreachWorldSystems(){} }
