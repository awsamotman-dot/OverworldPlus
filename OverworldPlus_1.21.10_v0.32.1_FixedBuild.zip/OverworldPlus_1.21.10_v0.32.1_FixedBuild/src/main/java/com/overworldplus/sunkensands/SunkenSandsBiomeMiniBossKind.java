package com.overworldplus.sunkensands;
public enum SunkenSandsBiomeMiniBossKind {
 DUNE_RAVAGER("dune_ravager","Dune Ravager","golden_dunes"),
 BURIED_KING("buried_king","Buried King","buried_kingdom"),
 SCORPION_LORD("scorpion_lord","Scorpion Lord","scorpion_wastes"),
 OASIS_GUARDIAN("oasis_guardian","Oasis Guardian","sunken_oasis"),
 RED_DUNE_BEAST("red_dune_beast","Red Dune Beast","red_sand_expanse"),
 OBSIDIAN_GOLEM("obsidian_golem","Obsidian Golem","obsidian_desert"),
 CANYON_WARLORD("canyon_warlord","Canyon Warlord","ancient_canyon"),
 STORM_DERVISH("storm_dervish","Storm Dervish","sandstorm_plains"),
 CRYSTAL_COLOSSUS("crystal_colossus","Crystal Colossus","crystal_sands"),
 DEAD_OASIS_WITCH("dead_oasis_witch","Dead Oasis Witch","dead_oasis"),
 GRAVE_KEEPER("grave_keeper","Grave Keeper","dune_graveyard"),
 JUNGLE_DEVOURER("jungle_devourer","Jungle Devourer","lost_jungle"),
 MOUNTAIN_TITAN("mountain_titan","Mountain Titan","sandswept_mountains"),
 SINKHOLE_HORROR("sinkhole_horror_boss","Sinkhole Horror","great_sinkhole"),
 DROWNED_GUARDIAN("drowned_guardian_mini","Drowned Guardian","flooded_ruins"),
 MOON_STALKER("moon_stalker","Moon Stalker","moonlit_desert"),
 SERPENT_CHAMPION("serpent_champion","Serpent Champion","serpent_valley"),
 BLACK_DUNE_LORD("black_dune_lord","Black Dune Lord","black_sand_sea"),
 ANCIENT_SUN_GUARDIAN("ancient_sun_guardian","Ancient Sun Guardian","ancient_sunlands"),
 THRONE_EXECUTIONER("throne_executioner","Throne Executioner","sunken_throne");
 public final String id,name,biome; SunkenSandsBiomeMiniBossKind(String id,String name,String biome){this.id=id;this.name=name;this.biome=biome;}
}
