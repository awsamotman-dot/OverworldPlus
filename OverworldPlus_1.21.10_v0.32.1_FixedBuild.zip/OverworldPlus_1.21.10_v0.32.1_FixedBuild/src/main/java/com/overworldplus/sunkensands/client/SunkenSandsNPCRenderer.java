package com.overworldplus.sunkensands.client;
import com.overworldplus.OverworldPlus;
import com.overworldplus.sunkensands.SunkenSandsNPCEntity;
import net.minecraft.client.render.entity.MobEntityRenderer;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.model.BipedEntityModel;
import net.minecraft.client.render.entity.model.EntityModelLayers;
import net.minecraft.util.Identifier;
public class SunkenSandsNPCRenderer extends MobEntityRenderer<SunkenSandsNPCEntity,BipedEntityModel<SunkenSandsNPCEntity>>{
 public SunkenSandsNPCRenderer(EntityRendererFactory.Context c){super(c,new BipedEntityModel<>(c.getPart(EntityModelLayers.ZOMBIE)),.5f);}
 @Override public Identifier getTexture(SunkenSandsNPCEntity e){return Identifier.of(OverworldPlus.MOD_ID,"textures/entity/sunken_sands/sunken_sands_npc.png");}
}
