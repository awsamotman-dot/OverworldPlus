package com.overworldplus.sunkensands;
import com.overworldplus.OverworldPlus;import net.minecraft.registry.*;import net.minecraft.sound.SoundEvent;import net.minecraft.util.Identifier;import java.util.*;
public final class SunkenSandsSounds{
 public static final Map<String,SoundEvent> AMBIENT=new HashMap<>(),HURT=new HashMap<>(),DEATH=new HashMap<>(),ATTACK=new HashMap<>();
 public static final Map<SunkenSandsBossKind,SoundEvent>BOSS_AMBIENT=new EnumMap<>(SunkenSandsBossKind.class),BOSS_HURT=new EnumMap<>(SunkenSandsBossKind.class),BOSS_DEATH=new EnumMap<>(SunkenSandsBossKind.class),BOSS_PHASE=new EnumMap<>(SunkenSandsBossKind.class),BOSS_ATTACK=new EnumMap<>(SunkenSandsBossKind.class);
 public static final Map<SunkenSandsBiomeMiniBossKind,SoundEvent> BIOME_BOSS_AMBIENT=new EnumMap<>(SunkenSandsBiomeMiniBossKind.class),BIOME_BOSS_ATTACK=new EnumMap<>(SunkenSandsBiomeMiniBossKind.class),BIOME_BOSS_DEATH=new EnumMap<>(SunkenSandsBiomeMiniBossKind.class);
 public static final Map<SunkenSandsStructureKind,SoundEvent> STRUCTURE_AMBIENT=new EnumMap<>(SunkenSandsStructureKind.class),STRUCTURE_ATTACK=new EnumMap<>(SunkenSandsStructureKind.class),STRUCTURE_DEATH=new EnumMap<>(SunkenSandsStructureKind.class),STRUCTURE_BOSS_ATTACK=new EnumMap<>(SunkenSandsStructureKind.class),STRUCTURE_BOSS_DEATH=new EnumMap<>(SunkenSandsStructureKind.class);
 private static SoundEvent reg(String id){Identifier i=Identifier.of(OverworldPlus.MOD_ID,id);return Registry.register(Registries.SOUND_EVENT,i,SoundEvent.of(i));}
 public static void register(){
  for(SunkenSandsCreatureKind k:SunkenSandsCreatureKind.values()){AMBIENT.put(k.id,reg("sunken_sands."+k.id+".ambient"));HURT.put(k.id,reg("sunken_sands."+k.id+".hurt"));DEATH.put(k.id,reg("sunken_sands."+k.id+".death"));ATTACK.put(k.id,reg("sunken_sands."+k.id+".attack"));}
  for(SunkenSandsBossKind k:SunkenSandsBossKind.values()){BOSS_AMBIENT.put(k,reg("sunken_sands.boss."+k.id+".ambient"));BOSS_HURT.put(k,reg("sunken_sands.boss."+k.id+".hurt"));BOSS_DEATH.put(k,reg("sunken_sands.boss."+k.id+".death"));BOSS_PHASE.put(k,reg("sunken_sands.boss."+k.id+".phase"));BOSS_ATTACK.put(k,reg("sunken_sands.boss."+k.id+".attack"));}
  for(SunkenSandsBiomeMiniBossKind k:SunkenSandsBiomeMiniBossKind.values()){BIOME_BOSS_AMBIENT.put(k,reg("sunken_sands.biome_boss."+k.id+".ambient"));BIOME_BOSS_ATTACK.put(k,reg("sunken_sands.biome_boss."+k.id+".attack"));BIOME_BOSS_DEATH.put(k,reg("sunken_sands.biome_boss."+k.id+".death"));}
  for(SunkenSandsStructureKind k:SunkenSandsStructureKind.values()){STRUCTURE_AMBIENT.put(k,reg("sunken_sands.structure."+k.id+".ambient"));STRUCTURE_ATTACK.put(k,reg("sunken_sands.structure."+k.id+".attack"));STRUCTURE_DEATH.put(k,reg("sunken_sands.structure."+k.id+".death"));STRUCTURE_BOSS_ATTACK.put(k,reg("sunken_sands.structure_boss."+k.id+".attack"));STRUCTURE_BOSS_DEATH.put(k,reg("sunken_sands.structure_boss."+k.id+".death"));}
 }
 private SunkenSandsSounds(){}
}
