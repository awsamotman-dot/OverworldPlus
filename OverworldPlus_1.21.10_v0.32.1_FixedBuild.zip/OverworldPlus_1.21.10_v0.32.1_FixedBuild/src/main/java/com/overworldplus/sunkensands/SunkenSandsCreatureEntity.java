package com.overworldplus.sunkensands;

import net.minecraft.entity.*;import net.minecraft.entity.ai.goal.*;import net.minecraft.entity.attribute.*;import net.minecraft.entity.effect.*;import net.minecraft.entity.mob.HostileEntity;import net.minecraft.entity.player.PlayerEntity;import net.minecraft.nbt.NbtCompound;import net.minecraft.particle.ParticleTypes;import net.minecraft.sound.SoundEvent;import net.minecraft.text.Text;import net.minecraft.util.math.Box;import net.minecraft.world.World;

/** Hostile wildlife with individual active skills, movement flavor and persistent elite state. */
public class SunkenSandsCreatureEntity extends HostileEntity {
 private SunkenSandsCreatureKind kind; private boolean elite; private int skillCooldown=50; private int skillTimer=0;
 public SunkenSandsCreatureEntity(EntityType<? extends SunkenSandsCreatureEntity> t,World w,SunkenSandsCreatureKind k){super(t,w);kind=k;setPersistent();experiencePoints=20;}
 public SunkenSandsCreatureKind getKind(){return kind;} public boolean isElite(){return elite;} public int getSkillTimer(){return skillTimer;}
 public void setElite(boolean value){elite=value;if(value){var hp=getAttributeInstance(EntityAttributes.MAX_HEALTH);if(hp!=null){hp.setBaseValue(96);setHealth(Math.min(getHealth(),96));}var atk=getAttributeInstance(EntityAttributes.ATTACK_DAMAGE);if(atk!=null)atk.setBaseValue(15);var armor=getAttributeInstance(EntityAttributes.ARMOR);if(armor!=null)armor.setBaseValue(8);experiencePoints=80;}}
 public static DefaultAttributeContainer.Builder attributes(){return HostileEntity.createHostileAttributes().add(EntityAttributes.MAX_HEALTH,38).add(EntityAttributes.ATTACK_DAMAGE,7).add(EntityAttributes.ARMOR,3).add(EntityAttributes.MOVEMENT_SPEED,.30).add(EntityAttributes.FOLLOW_RANGE,32);}
 @Override protected void initGoals(){goalSelector.add(2,new MeleeAttackGoal(this,1.15,true));goalSelector.add(7,new LookAtEntityGoal(this,PlayerEntity.class,18));targetSelector.add(1,new ActiveTargetGoal<>(this,PlayerEntity.class,true));}
 @Override protected SoundEvent getAmbientSound(){return SunkenSandsSounds.AMBIENT.get(kind.id);}@Override protected SoundEvent getHurtSound(net.minecraft.entity.damage.DamageSource s){return SunkenSandsSounds.HURT.get(kind.id);}@Override protected SoundEvent getDeathSound(){return SunkenSandsSounds.DEATH.get(kind.id);}
 @Override public Text getDisplayName(){return Text.literal((elite?"Elite ":"")+kind.name);}
 @Override protected void mobTick(){super.mobTick();if(skillTimer>0)skillTimer--;if(!getWorld().isClient&&getTarget()!=null){if(skillCooldown>0)skillCooldown--;if(skillCooldown<=0){useSkill();skillCooldown=70+getRandom().nextInt(45);skillTimer=12;}if(age%120==0){PlayerEntity t=getTarget();if(t!=null&&kind==SunkenSandsCreatureKind.SAND_SERPENT)t.addStatusEffect(new StatusEffectInstance(StatusEffects.MINING_FATIGUE,50,0));}}}
 private void useSkill(){PlayerEntity t=getTarget();if(t==null)return;playSound(SunkenSandsSounds.ATTACK.get(kind.id),1.2f,0.75f+getRandom().nextFloat()*.45f);double d=t.squaredDistanceTo(this);switch(kind){
  case GOLDEN_CAMEL->{t.addStatusEffect(new StatusEffectInstance(StatusEffects.SPEED,55,1));t.damage(getWorld().getDamageSources().mobAttack(this),5);}
  case SAND_JACKAL,BLACK_JACKAL->{t.addStatusEffect(new StatusEffectInstance(StatusEffects.WEAKNESS,70,1));t.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS,35,1));}
  case BLACK_SCORPION,POISON_SCORPION->{t.addStatusEffect(new StatusEffectInstance(StatusEffects.POISON,80,elite?2:1));}
  case OASIS_GAZELLE,SUN_GAZELLE->{t.addStatusEffect(new StatusEffectInstance(StatusEffects.BLINDNESS,25,0));addVelocityToward(t,0.5);}
  case RED_DROMEDARY->{t.addStatusEffect(new StatusEffectInstance(StatusEffects.WEAKNESS,50,1));aoeDamage(4.5,7);}
  case OBSIDIAN_BEETLE->{t.addStatusEffect(new StatusEffectInstance(StatusEffects.MINING_FATIGUE,90,1));aoeDamage(3.5,6);}
  case CANYON_DRAKE->{t.addStatusEffect(new StatusEffectInstance(StatusEffects.LEVITATION,35,0));t.damage(getWorld().getDamageSources().magic(),9);}
  case SAND_VULTURE->{t.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS,75,2));t.addStatusEffect(new StatusEffectInstance(StatusEffects.BLINDNESS,30,0));}
  case CRYSTAL_BEETLE->{aoeDamage(5,9);for(int i=0;i<18;i++)getWorld().addParticle(ParticleTypes.END_ROD,getX()+getRandom().nextGaussian()*2,getY()+1,getZ()+getRandom().nextGaussian()*2,0,.05,0);}
  case DUNE_RAVEN->{t.addStatusEffect(new StatusEffectInstance(StatusEffects.DARKNESS,45,0));}
  case JUNGLE_PANTHER->{addVelocityToward(t,0.85);t.damage(getWorld().getDamageSources().mobAttack(this),10);}
  case SAND_RAM->{addVelocityToward(t,1.1);t.damage(getWorld().getDamageSources().mobAttack(this),12);}
  case SINKHOLE_HORROR->{t.addStatusEffect(new StatusEffectInstance(StatusEffects.DARKNESS,60,0));t.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS,55,2));}
  case OASIS_CROCODILE->{t.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS,80,3));t.damage(getWorld().getDamageSources().mobAttack(this),11);}
  case MOON_MOTH->{t.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION,80,0));t.addStatusEffect(new StatusEffectInstance(StatusEffects.NAUSEA,45,0));}
  case SAND_SERPENT->{addVelocityToward(t,.65);t.damage(getWorld().getDamageSources().magic(),13);}
  case ROYAL_CAMEL->{t.addStatusEffect(new StatusEffectInstance(StatusEffects.LEVITATION,35,1));aoeDamage(4,8);}
  default->{}
 }}
 private void addVelocityToward(PlayerEntity t,double strength){double dx=t.getX()-getX(),dz=t.getZ()-getZ(),len=Math.max(.01,Math.sqrt(dx*dx+dz*dz));setVelocity(dx/len*strength,getVelocity().y,dz/len*strength);}
 private void aoeDamage(double radius,float damage){for(PlayerEntity p:getWorld().getPlayers())if(p!=this&&p.squaredDistanceTo(getX(),getY(),getZ())<=radius*radius)p.damage(getWorld().getDamageSources().mobAttack(this),damage);}
 @Override public void writeCustomDataToNbt(NbtCompound n){super.writeCustomDataToNbt(n);n.putString("SunkenSandsKind",kind.id);n.putBoolean("SunkenSandsElite",elite);n.putInt("SkillCooldown",skillCooldown);}
 @Override public void readCustomDataFromNbt(NbtCompound n){super.readCustomDataFromNbt(n);String id=n.getString("SunkenSandsKind");for(SunkenSandsCreatureKind k:SunkenSandsCreatureKind.values())if(k.id.equals(id))kind=k;elite=n.getBoolean("SunkenSandsElite");skillCooldown=n.getInt("SkillCooldown");if(elite)setElite(true);}
 @Override protected void dropLoot(net.minecraft.entity.damage.DamageSource source,boolean causedByPlayer){super.dropLoot(source,causedByPlayer);String m=switch(kind){case GOLDEN_CAMEL,OASIS_GAZELLE,JUNGLE_PANTHER,MOON_MOTH->"stormite";case SAND_JACKAL,BLACK_SCORPION,RED_DROMEDARY,OBSIDIAN_BEETLE,SAND_VULTURE,SAND_RAM->"thundrium";case CANYON_DRAKE,CRYSTAL_BEETLE,SINKHOLE_HORROR,SAND_SERPENT->"tempest_crystal";case POISON_SCORPION,OASIS_CROCODILE->"celestium";case DUNE_RAVEN,BLACK_JACKAL->"skysteel";case SUN_GAZELLE,ROYAL_CAMEL->"stormheart";};if(elite||getRandom().nextInt(4)==0){var item=SunkenSandsItems.INGOTS.get(m);if(item!=null)drop(new net.minecraft.item.ItemStack(item));}}
}
