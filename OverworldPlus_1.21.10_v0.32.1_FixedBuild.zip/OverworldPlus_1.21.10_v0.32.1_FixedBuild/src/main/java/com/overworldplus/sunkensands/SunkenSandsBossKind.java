package com.overworldplus.sunkensands;
public enum SunkenSandsBossKind {
 SUN_KING("sun_king","The Sun King"), SCORPION_EMPEROR("scorpion_emperor","Scorpion Emperor"), SAND_SERPENT("sand_serpent_boss","The Sand Serpent"), PHARAOH("pharaoh_lost_kingdom","Pharaoh of the Lost Kingdom"), DUNE_TYRANT("dune_tyrant","The Dune Tyrant"), BURIED_LICH("buried_lich","The Buried Lich"), ANCIENT_COLOSSUS("ancient_colossus","The Ancient Colossus"), DROWNED_GUARDIAN("drowned_guardian","The Drowned Guardian"), MOON_QUEEN("moon_queen","The Moon Queen"), SUNKEN_GOD("sunken_god","The Sunken God");
 public final String id,name; SunkenSandsBossKind(String id,String name){this.id=id;this.name=name;}
}
