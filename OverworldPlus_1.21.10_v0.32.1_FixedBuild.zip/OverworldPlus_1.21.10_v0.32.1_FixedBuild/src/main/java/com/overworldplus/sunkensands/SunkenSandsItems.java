package com.overworldplus.sunkensands;
import com.overworldplus.OverworldPlus;
import net.minecraft.item.*;
import net.minecraft.item.equipment.*;
import net.minecraft.registry.*;
import net.minecraft.util.Identifier;
import java.util.*;

public final class SunkenSandsItems {
 public static final Map<String,Item> INGOTS=new LinkedHashMap<>(), SWORDS=new LinkedHashMap<>(), PICKAXES=new LinkedHashMap<>(), AXES=new LinkedHashMap<>(), SHOVELS=new LinkedHashMap<>(), HOES=new LinkedHashMap<>();
 public static final Map<String,Item[]> ARMOR=new LinkedHashMap<>();
 public static final Map<String,Item> ABILITIES=new LinkedHashMap<>();
 public static Item SHADOW_FRAGMENT, SHADOW_EYE;
 public static final Map<SunkenSandsBossKind,Item> BOSS_RELICS=new EnumMap<>(SunkenSandsBossKind.class), BOSS_WEAPONS=new EnumMap<>(SunkenSandsBossKind.class);
 private static Item reg(String id,Item i){return Registry.register(Registries.ITEM,Identifier.of(OverworldPlus.MOD_ID,id),i);}
 private static void material(String id){
  INGOTS.put(id,reg("sunken_sands_"+id+"_ingot",new Item(new Item.Settings().maxCount(64))));
  SWORDS.put(id,reg("sunken_sands_"+id+"_sword",new SwordItem(ToolMaterial.NETHERITE,9,-2.35f,new Item.Settings().maxCount(1))));
  PICKAXES.put(id,reg("sunken_sands_"+id+"_pickaxe",new PickaxeItem(ToolMaterial.NETHERITE,2.0f,-2.8f,new Item.Settings().maxCount(1))));
  AXES.put(id,reg("sunken_sands_"+id+"_axe",new AxeItem(ToolMaterial.NETHERITE,7.0f,-3.0f,new Item.Settings().maxCount(1))));
  SHOVELS.put(id,reg("sunken_sands_"+id+"_shovel",new ShovelItem(ToolMaterial.NETHERITE,2.5f,-3.0f,new Item.Settings().maxCount(1))));
  HOES.put(id,reg("sunken_sands_"+id+"_hoe",new HoeItem(ToolMaterial.NETHERITE,-2.0f,-1.0f,new Item.Settings().maxCount(1))));
  Item[] a=new Item[4];
  a[0]=reg("sunken_sands_"+id+"_helmet",new ArmorItem(ArmorMaterials.NETHERITE,EquipmentType.HELMET,new Item.Settings().maxCount(1)));
  a[1]=reg("sunken_sands_"+id+"_chestplate",new ArmorItem(ArmorMaterials.NETHERITE,EquipmentType.CHESTPLATE,new Item.Settings().maxCount(1)));
  a[2]=reg("sunken_sands_"+id+"_leggings",new ArmorItem(ArmorMaterials.NETHERITE,EquipmentType.LEGGINGS,new Item.Settings().maxCount(1)));
  a[3]=reg("sunken_sands_"+id+"_boots",new ArmorItem(ArmorMaterials.NETHERITE,EquipmentType.BOOTS,new Item.Settings().maxCount(1)));
  ARMOR.put(id,a);
 }
 static {
  material("sandsteel"); material("sun_crystal"); material("scorpite"); material("duneite"); material("moon_crystal"); material("serpentium"); material("pharaohite"); material("sunken_core");
  // Ability relics: holding + sneaking activates them through the world tick system.
  ABILITIES.put("fire_dash",reg("sunken_sands_fire_dash",new Item(new Item.Settings().maxCount(1))));
  ABILITIES.put("solar_beam",reg("sunken_sands_solar_beam",new Item(new Item.Settings().maxCount(1))));
  ABILITIES.put("venom_strike",reg("sunken_sands_venom_strike",new Item(new Item.Settings().maxCount(1))));
  ABILITIES.put("sand_dash",reg("sunken_sands_sand_dash",new Item(new Item.Settings().maxCount(1))));
  ABILITIES.put("moon_step",reg("sunken_sands_moon_step",new Item(new Item.Settings().maxCount(1))));
  ABILITIES.put("ancient_barrier",reg("sunken_sands_ancient_barrier",new Item(new Item.Settings().maxCount(1))));
  ABILITIES.put("sandstorm",reg("sunken_sands_sandstorm",new Item(new Item.Settings().maxCount(1))));
  ABILITIES.put("dune_explosion",reg("sunken_sands_dune_explosion",new Item(new Item.Settings().maxCount(1))));
  ABILITIES.put("serpent_summon",reg("sunken_sands_serpent_summon",new Item(new Item.Settings().maxCount(1))));
  ABILITIES.put("pharaohs_wrath",reg("sunken_sands_pharaohs_wrath",new Item(new Item.Settings().maxCount(1))));
  SHADOW_FRAGMENT=reg("sunken_sands_shadow_fragment",new Item(new Item.Settings().maxCount(9)));
  SHADOW_EYE=reg("shadow_eye",new Item(new Item.Settings().maxCount(1)));
  BOSS_RELICS.put(SunkenSandsBossKind.SUN_KING,reg("sunken_sands_sun_king_relic",new Item(new Item.Settings().maxCount(1))));
  BOSS_RELICS.put(SunkenSandsBossKind.SCORPION_EMPEROR,reg("sunken_sands_scorpion_emperor_relic",new Item(new Item.Settings().maxCount(1))));
  BOSS_RELICS.put(SunkenSandsBossKind.SAND_SERPENT,reg("sunken_sands_sand_serpent_relic",new Item(new Item.Settings().maxCount(1))));
  BOSS_RELICS.put(SunkenSandsBossKind.PHARAOH,reg("sunken_sands_pharaoh_relic",new Item(new Item.Settings().maxCount(1))));
  BOSS_RELICS.put(SunkenSandsBossKind.DUNE_TYRANT,reg("sunken_sands_dune_tyrant_relic",new Item(new Item.Settings().maxCount(1))));
  BOSS_RELICS.put(SunkenSandsBossKind.BURIED_LICH,reg("sunken_sands_buried_lich_relic",new Item(new Item.Settings().maxCount(1))));
  BOSS_RELICS.put(SunkenSandsBossKind.ANCIENT_COLOSSUS,reg("sunken_sands_ancient_colossus_relic",new Item(new Item.Settings().maxCount(1))));
  BOSS_RELICS.put(SunkenSandsBossKind.DROWNED_GUARDIAN,reg("sunken_sands_drowned_guardian_relic",new Item(new Item.Settings().maxCount(1))));
  BOSS_RELICS.put(SunkenSandsBossKind.MOON_QUEEN,reg("sunken_sands_moon_queen_relic",new Item(new Item.Settings().maxCount(1))));
  BOSS_RELICS.put(SunkenSandsBossKind.SUNKEN_GOD,reg("sunken_sands_sunken_god_relic",new Item(new Item.Settings().maxCount(1))));
  for(SunkenSandsBossKind k:SunkenSandsBossKind.values()) BOSS_WEAPONS.put(k,reg(k.id+"_weapon",new SwordItem(ToolMaterial.NETHERITE,11,-2.25f,new Item.Settings().maxCount(1))));
 }
 public static void register(){}
 private SunkenSandsItems(){}
}
