package com.overworldplus.sunkensands.client;

import com.overworldplus.sunkensands.*;
import net.minecraft.client.model.*;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.MathHelper;

/** Unique silhouette kits for all ten Sunken Sands main bosses. */
public class SunkenSandsBossModel extends EntityModel<SunkenSandsBossEntity> {
 private final ModelPart root,body,head,leftArm,rightArm,leftLeg,rightLeg,extra,core; private final SunkenSandsBossKind kind;
 public SunkenSandsBossModel(ModelPart r,SunkenSandsBossKind k){super(r);root=r;kind=k;body=r.getChild("body");head=r.getChild("head");leftArm=r.getChild("left_arm");rightArm=r.getChild("right_arm");leftLeg=r.getChild("left_leg");rightLeg=r.getChild("right_leg");extra=r.getChild("extra");core=r.getChild("core");}
 public static TexturedModelData create(SunkenSandsBossKind k){ModelData d=new ModelData();ModelPartData r=d.getRoot();
  r.addChild("body",ModelPartBuilder.create().uv(0,0).cuboid(-11,-23,-8,22,31,16),ModelTransform.pivot(0,4,0));
  r.addChild("head",ModelPartBuilder.create().uv(0,40).cuboid(-9,-11,-8,18,18,16),ModelTransform.pivot(0,-20,-1));
  r.addChild("left_arm",ModelPartBuilder.create().uv(72,0).cuboid(-6,-2,-6,12,31,12),ModelTransform.pivot(18,-15,0));
  r.addChild("right_arm",ModelPartBuilder.create().uv(72,43).cuboid(-6,-2,-6,12,31,12),ModelTransform.pivot(-18,-15,0));
  r.addChild("left_leg",ModelPartBuilder.create().uv(0,78).cuboid(-7,0,-7,14,30,14),ModelTransform.pivot(7,31,0));
  r.addChild("right_leg",ModelPartBuilder.create().uv(56,78).cuboid(-7,0,-7,14,30,14),ModelTransform.pivot(-7,31,0));
  r.addChild("core",ModelPartBuilder.create().uv(112,78).cuboid(-5,-5,-10,10,10,4),ModelTransform.pivot(0,0,0));
  switch(k){
   case SUN_KING -> r.addChild("extra",ModelPartBuilder.create().uv(0,112).cuboid(-22,-34,-3,44,8,6).cuboid(-12,-46,-2,24,12,4),ModelTransform.pivot(0,0,0));
   case SCORPION_EMPEROR -> r.addChild("extra",ModelPartBuilder.create().uv(0,132).cuboid(-28,-12,-8,56,18,16).cuboid(-4,-50,-4,8,22,8),ModelTransform.pivot(0,0,0));
   case SAND_SERPENT -> r.addChild("extra",ModelPartBuilder.create().uv(0,158).cuboid(-30,-10,-12,60,18,24).cuboid(-8,-38,-8,16,28,16),ModelTransform.pivot(0,0,0));
   case PHARAOH -> r.addChild("extra",ModelPartBuilder.create().uv(72,112).cuboid(-24,-34,-4,48,9,8).cuboid(-14,-47,-5,28,14,10),ModelTransform.pivot(0,0,0));
   case DUNE_TYRANT -> r.addChild("extra",ModelPartBuilder.create().uv(72,136).cuboid(-26,-30,-10,52,22,20).cuboid(-8,-51,-8,16,23,16),ModelTransform.pivot(0,0,0));
   case BURIED_LICH -> r.addChild("extra",ModelPartBuilder.create().uv(72,178).cuboid(-22,-35,-3,44,8,6).cuboid(-5,-51,-5,10,18,10),ModelTransform.pivot(0,0,0));
   case ANCIENT_COLOSSUS -> r.addChild("extra",ModelPartBuilder.create().uv(0,194).cuboid(-30,-34,-14,60,24,28).cuboid(-10,-57,-10,20,23,20),ModelTransform.pivot(0,0,0));
   case DROWNED_GUARDIAN -> r.addChild("extra",ModelPartBuilder.create().uv(72,204).cuboid(-28,-31,-10,56,20,20).cuboid(-18,-48,-5,36,12,10),ModelTransform.pivot(0,0,0));
   case MOON_QUEEN -> r.addChild("extra",ModelPartBuilder.create().uv(0,242).cuboid(-23,-35,-3,46,7,6).cuboid(-14,-49,-2,28,14,4),ModelTransform.pivot(0,0,0));
   case SUNKEN_GOD -> r.addChild("extra",ModelPartBuilder.create().uv(72,242).cuboid(-32,-38,-14,64,28,28).cuboid(-12,-65,-12,24,28,24),ModelTransform.pivot(0,0,0));
  }
  return TexturedModelData.of(d,256,256);
 }
 @Override public void setAngles(SunkenSandsBossEntity e,float limb,float distance,float age,float yaw,float pitch){head.yaw=yaw*MathHelper.RADIANS_PER_DEGREE;head.pitch=pitch*MathHelper.RADIANS_PER_DEGREE;float w=MathHelper.cos(limb*.45f)*distance*.65f;leftLeg.pitch=w;rightLeg.pitch=-w;leftArm.pitch=-w*.5f;rightArm.pitch=w*.5f;float b=MathHelper.sin(age*.07f)*.6f;body.pivotY=4+b;core.pivotY=b;extra.yaw=MathHelper.sin(age*.035f)*.04f;core.pitch=MathHelper.sin(age*.12f)*.16f;if(e.getPhase()>=3){extra.roll=MathHelper.sin(age*.11f)*.07f;leftArm.pitch-=.18f;rightArm.pitch-=.18f;}if(e.getSkillTimer()>0){float p=MathHelper.sin((e.getSkillTimer()/14f)*MathHelper.PI);leftArm.pitch-=1.15f*p;rightArm.pitch-=1.15f*p;body.pitch=.14f*p;}}
 @Override public void render(MatrixStack m,VertexConsumer v,int l,int o,int c){root.render(m,v,l,o,c);}
}
