package com.overworldplus.sunkensands;
import com.overworldplus.OverworldPlus; import net.fabricmc.fabric.api.event.lifecycle.v1.ServerChunkEvents; import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents; import net.minecraft.block.*; import net.minecraft.entity.EntityType; import net.minecraft.entity.ItemEntity; import net.minecraft.item.ItemStack; import net.minecraft.particle.ParticleTypes; import net.minecraft.server.network.ServerPlayerEntity; import net.minecraft.server.world.ServerWorld; import net.minecraft.text.Text; import net.minecraft.util.math.BlockPos; import net.minecraft.world.Heightmap; import net.minecraft.entity.attribute.EntityAttributes; import net.minecraft.entity.effect.StatusEffectInstance; import net.minecraft.entity.effect.StatusEffects; import net.minecraft.registry.*; import net.minecraft.world.World; import java.util.*;
public final class SunkenSandsWorldSystems {private static final Set<Long> POP=Collections.synchronizedSet(new HashSet<>()); private static final Map<String,SunkenSandsCreatureKind> MOB=new HashMap<>(); static{for(SunkenSandsCreatureKind k:SunkenSandsCreatureKind.values())MOB.put(k.biome,k);} public static void register(){ServerChunkEvents.CHUNK_LOAD.register((w,c)->{if(!(w instanceof ServerWorld sw)||!isStorm(sw))return;long key=(((long)c.getPos().x)<<32)^(c.getPos().z&0xffffffffL);if(POP.add(key))populate(sw,c.getPos().x,c.getPos().z);});ServerTickEvents.END_WORLD_TICK.register(SunkenSandsWorldSystems::tick);}
 private static boolean isStorm(ServerWorld w){return w.getRegistryKey().getValue().getPath().equals("sunken_sands");} private static long hash(int x,int z,long s){long h=((long)x*341873128712L)^((long)z*132897987541L)^s;h^=h>>>33;h*=0xff51afd7ed558ccdL;h^=h>>>33;return h;} private static final String[] RANDOM_BIOMES={"golden_dunes","buried_kingdom","scorpion_wastes","sunken_oasis","red_sand_expanse","obsidian_desert","ancient_canyon","sandstorm_plains","crystal_sands","dead_oasis","dune_graveyard","lost_jungle","sandswept_mountains","great_sinkhole","flooded_ruins","moonlit_desert","serpent_valley","black_sand_sea","ancient_sunlands","sunken_throne"};
 private static String biome(ServerWorld w,BlockPos p){return randomBiomeAt(p.getX(),p.getZ(),w.getSeed());}
 private static String randomBiomeAt(int x,int z,long seed){
  // Large seed-driven biome continents: a warped Voronoi field gives Minecraft-like
  // broad regions while keeping every seed materially different.
  double warpX=valueNoise(x,z,seed^0x13579bdfL,768)*220.0+valueNoise(x,z,seed^0x2468ace0L,192)*55.0;
  double warpZ=valueNoise(x,z,seed^0xabcdef01L,768)*220.0+valueNoise(x,z,seed^0x10203040L,192)*55.0;
  double wx=x+warpX,wz=z+warpZ;
  int cell=720; int gx=(int)Math.floor(wx/cell),gz=(int)Math.floor(wz/cell);
  double best=Double.MAX_VALUE; int bestX=gx,bestZ=gz;
  for(int ox=-1;ox<=1;ox++)for(int oz=-1;oz<=1;oz++){int cx=gx+ox,cz=gz+oz;long h=hash(cx,cz,seed^0x7f4a7c15L);double px=(cx+0.18+((h>>>8)&0xffff)/65535.0*0.64)*cell;double pz=(cz+0.18+((h>>>24)&0xffff)/65535.0*0.64)*cell;double dx=wx-px,dz=wz-pz;double d=dx*dx+dz*dz;if(d<best){best=d;bestX=cx;bestZ=cz;}}
  long regionHash=hash(bestX,bestZ,seed^0x9e3779b97f4a7c15L);
  return RANDOM_BIOMES[(int)Math.floorMod(regionHash,RANDOM_BIOMES.length)];
 }
 private static void populate(ServerWorld w,int cx,int cz){int x0=cx*16,z0=cz*16;BlockPos p=new BlockPos(x0+8,w.getTopY(Heightmap.Type.WORLD_SURFACE,x0+8,z0+8),z0+8);String b=biome(w,p);long h=hash(cx,cz,w.getSeed());buildShadowShrineIfNeeded(w,cx,cz);BlockPos marker=new BlockPos(x0+8,Math.max(w.getBottomY()+4,p.getY()-1),z0+8);if(w.getBlockState(marker).isOf(SunkenSandsBlocks.DUNGEON_CORE.get(b)))return;shape(w,x0,z0,b,h);caves(w,x0,z0,b,h);if(Math.floorMod(h,97)==7)structure(w,p,b,h,randomStructureKind(h));if(Math.floorMod(h,191)==17)dungeon(w,p,b,h);if(Math.floorMod(h,271)==31)spawnMob(w,p,b,h);if(Math.floorMod(h,631)==19)spawnElite(w,p,b);if(Math.floorMod(h,149)==11)spawnNpc(w,p,h);if(Math.floorMod(h,521)==7)biomeCity(w,p,b,h);if(Math.floorMod(h,389)==11)biomeLandmark(w,p,b,h);if(Math.floorMod(h,337)==19)biomeDungeon(w,p,b,h);if(Math.floorMod(h,811)==37)structure(w,p,b,h,randomStructureKind(h^0x55aa55aaL));oreVeins(w,x0,z0,b,h);tryMainBossSite(w,cx,cz);w.setBlockState(new BlockPos(x0+8,Math.max(w.getBottomY()+2,p.getY()-8),z0+8),SunkenSandsBlocks.DUNGEON_CORE.get(b).getDefaultState());}
 private static int shrineChunkX(long seed,int i){return 110+(int)Math.floorMod(hash(i*977,31,seed^0x51ed2705L),240)-120+(i*29);}
 private static int shrineChunkZ(long seed,int i){return -90+(int)Math.floorMod(hash(i*613,-17,seed^0x243f6a88L),220)-110+(i*37);}
 private static void buildShadowShrineIfNeeded(ServerWorld w,int cx,int cz){
  long seed=w.getSeed();
  for(int i=0;i<10;i++){
   int sx=shrineChunkX(seed,i),sz=shrineChunkZ(seed,i);
   if(cx!=sx||cz!=sz)continue;
   int x=cx*16+8,z=cz*16+8,y=w.getTopY(Heightmap.Type.WORLD_SURFACE,x,z)-1;
   BlockPos base=new BlockPos(x,y,z);
   if(w.getBlockState(base.up(1)).isOf(SunkenSandsBlocks.DUNGEON_CORE.get("dune_graveyard")))continue;
   Block stone=SunkenSandsBiomeContent.STONE.get("dune_graveyard"),rune=SunkenSandsBiomeContent.RUNE.get("moonlit_desert"),cr=SunkenSandsBiomeContent.CRYSTAL.get("crystal_sands");
   for(int dx=-8;dx<=8;dx++)for(int dz=-8;dz<=8;dz++){if(dx*dx+dz*dz<=64){for(int yy=0;yy<3;yy++)w.setBlockState(base.add(dx,yy,dz),stone.getDefaultState());}}
   for(int dx=-6;dx<=6;dx++)for(int dz=-6;dz<=6;dz++)if(Math.abs(dx)==6||Math.abs(dz)==6)for(int yy=3;yy<=7;yy++)w.setBlockState(base.add(dx,yy,dz),stone.getDefaultState());
   w.setBlockState(base.up(3),cr.getDefaultState());
   boolean truth=i==Math.floorMod((int)(seed^(seed>>>32)),10);
   // The true shrine is never advertised by name; its geometry is subtly different.
   if(truth){for(int dx=-2;dx<=2;dx++)for(int dz=-2;dz<=2;dz++)if(Math.abs(dx)==2||Math.abs(dz)==2)w.setBlockState(base.add(dx,8,dz),rune.getDefaultState());
    EntityType<SunkenSandsStructureMiniBossEntity> t=OverworldPlus.SUNKEN_SANDS_STRUCTURE_MINI_BOSSES.get(SunkenSandsStructureKind.GRAVE_PYRAMID);
    if(t!=null&&!hasUmbralWarden(w,base)){SunkenSandsStructureMiniBossEntity e=new SunkenSandsStructureMiniBossEntity(t,w,SunkenSandsStructureKind.GRAVE_PYRAMID);e.setUmbralWarden(true);e.refreshPositionAndAngles(x+.5,y+4,z+.5,0,0);w.spawnEntity(e);}
   } else {
    w.setBlockState(base.up(3),rune.getDefaultState());
    if(!hasFragmentMarker(w,base))w.spawnEntity(new ItemEntity(w,x+.5,y+4,z+.5,new ItemStack(SunkenSandsItems.SHADOW_FRAGMENT)));
   }
   w.setBlockState(base.up(1),SunkenSandsBlocks.DUNGEON_CORE.get("dune_graveyard").getDefaultState());
  }
 }
 private static boolean hasUmbralWarden(ServerWorld w,BlockPos p){for(SunkenSandsStructureMiniBossEntity e:w.getEntitiesByType(OverworldPlus.SUNKEN_SANDS_STRUCTURE_MINI_BOSSES.get(SunkenSandsStructureKind.GRAVE_PYRAMID),q->q.squaredDistanceTo(p.toCenterPos())<36)return true;return false;}
 private static boolean hasFragmentMarker(ServerWorld w,BlockPos p){return !w.getBlockState(p.up(1)).isOf(SunkenSandsBlocks.DUNGEON_CORE.get("dune_graveyard"));}
 private static int shadowFragmentCount(ServerPlayerEntity p){int n=0;for(int i=0;i<p.getInventory().size();i++)if(p.getInventory().getStack(i).isOf(SunkenSandsItems.SHADOW_FRAGMENT))n+=p.getInventory().getStack(i).getCount();return n;}
 private static void guideToTrueShrine(ServerPlayerEntity p,ServerWorld w){if(shadowFragmentCount(p)<9)return;long seed=w.getSeed();int idx=Math.floorMod((int)(seed^(seed>>>32)),10),x=shrineChunkX(seed,idx)*16+8,z=shrineChunkZ(seed,idx)*16+8;double dx=x-p.getX(),dz=z-p.getZ();double dist=Math.sqrt(dx*dx+dz*dz);if(dist>24){String dir=Math.abs(dx)>Math.abs(dz)?(dx>0?"east":"west"):(dz>0?"south":"north");p.sendMessage(Text.literal("§5The Shadow Fragments resonate... True Shrine: §d"+dir+" §7("+(int)dist+"m)"),true);}}
 private static double smooth(double t){return t*t*(3.0-2.0*t);}
 private static double valueNoise(int x,int z,long seed,int scale){int gx=Math.floorDiv(x,scale),gz=Math.floorDiv(z,scale);double fx=(double)Math.floorMod(x,scale)/scale,fz=(double)Math.floorMod(z,scale)/scale;double a=unit(gx,gz,seed),bb=unit(gx+1,gz,seed),c=unit(gx,gz+1,seed),d=unit(gx+1,gz+1,seed);double ux=smooth(fx),uz=smooth(fz);return (a+(bb-a)*ux)+((c+(d-c)*ux)-(a+(bb-a)*ux))*uz;}
 private static double unit(int x,int z,long seed){long h=hash(x,z,seed);return ((h>>>11)&0x1fffff)/1048575.0*2.0-1.0;}
 private static double fractal(int x,int z,long seed,int base){double n=valueNoise(x,z,seed,base)*0.55;n+=valueNoise(x,z,seed^0x5deece66dL,base/2)*0.3;n+=valueNoise(x,z,seed^0x1234abcdL,base/4)*0.15;return n;}
 private static double terrainProfile(String b,double continent,double macro,double detail,double ridge,double canyon,double x,double z,long seed){
  double waves=Math.sin(x*0.018+seed*0.00000013)+Math.cos(z*0.021-seed*0.00000009);
  return switch(b){
   case "golden_dunes" -> continent*22+macro*12+detail*7+ridge*12+Math.sin(x*.021+z*.013)*9;
   case "buried_kingdom" -> continent*14+macro*10+detail*6+Math.max(0,waves)*16;
   case "scorpion_wastes" -> continent*20+macro*15+detail*8+Math.sin(x*.03)*10;
   case "sunken_oasis" -> continent*9+macro*6+detail*3-Math.abs(canyon)*18;
   case "red_sand_expanse" -> continent*20+macro*17+detail*5+Math.sin(x*.035+z*.012)*11;
   case "obsidian_desert" -> continent*24+macro*22+ridge*25+detail*8;
   case "ancient_canyon" -> continent*18+macro*15-detail*4-Math.abs(canyon)*62-ridge*18;
   case "sandstorm_plains" -> continent*12+macro*8+detail*6+Math.max(0,waves)*18;
   case "crystal_sands" -> continent*7+macro*5+detail*3-Math.abs(canyon)*8;
   case "dead_oasis" -> continent*10+macro*7+detail*4-Math.abs(canyon)*22;
   case "dune_graveyard" -> continent*16+macro*19+ridge*31+Math.max(0,detail)*10;
   case "lost_jungle" -> continent*24+macro*18+detail*12+Math.sin(x*.019)*9;
   case "sandswept_mountains" -> continent*25+macro*31+ridge*45+Math.max(0,detail)*25;
   case "great_sinkhole" -> continent*17+macro*11+detail*7+20-Math.abs(canyon)*75-ridge*11;
   case "flooded_ruins" -> continent*7+macro*5+detail*3-Math.abs(canyon)*9;
   case "moonlit_desert" -> continent*8+macro*5+detail*4-Math.abs(canyon)*10+Math.sin(x*.012)*6;
   case "serpent_valley" -> continent*17+macro*14+detail*6-Math.abs(canyon)*58-ridge*15;
   case "black_sand_sea" -> continent*9+macro*6+detail*4-Math.abs(canyon)*15+Math.sin(z*.017)*8;
   case "ancient_sunlands" -> continent*22+macro*27+ridge*50+Math.max(0,detail)*28;
   case "sunken_throne" -> continent*24+macro*19+detail*11-Math.abs(canyon)*50-ridge*23;
   default -> continent*24+macro*16+detail*8+ridge*12;
  };
 }
 private static void shape(ServerWorld w,int x0,int z0,String b,long seed){
  Block stone=SunkenSandsBiomeContent.STONE.get(b),soil=SunkenSandsBiomeContent.SOIL.get(b),cr=SunkenSandsBiomeContent.CRYSTAL.get(b);
  int mode=MOB.get(b)==null?0:MOB.get(b).ordinal();
  boolean sky=b.equals("sandstorm_plains")||b.equals("buried_kingdom")||b.equals("flooded_ruins")||b.equals("dune_graveyard");
  boolean water=b.equals("flooded_ruins")||b.equals("crystal_sands")||b.equals("moonlit_desert")||b.equals("sunken_oasis");
  for(int dx=0;dx<16;dx++)for(int dz=0;dz<16;dz++){
   int x=x0+dx,z=z0+dz,top=w.getTopY(Heightmap.Type.WORLD_SURFACE,x,z);
   double continent=fractal(x,z,seed^0x4f1bbcdcL,768);
   double macro=fractal(x,z,seed^0x72d5a17bL,320);
   double detail=fractal(x,z,seed^(0x5deece66dL+mode*7919L),96);
   double ridge=1.0-Math.abs(fractal(x,z,seed^0x55aa11L,160));
   double canyon=fractal(x,z,seed^0x9e3779b9L,72);
   double land=terrainProfile(b,continent,macro,detail,ridge,canyon,x,z,seed)-12.0;
   int target=(int)Math.round(72+land);
   if(water)target=Math.min(target,b.equals("flooded_ruins")?68:62);
   if(b.equals("ancient_canyon")||b.equals("serpent_valley"))target-=Math.max(0,(int)(Math.abs(canyon)*18));
   if(b.equals("sunken_throne"))target-=Math.max(0,(int)(ridge*16));
   target=Math.max(w.getBottomY()+6,Math.min(w.getTopY()-10,target));
   if(target>top){for(int y=top;y<=target;y++)w.setBlockState(new BlockPos(x,y,z),(y==target?soil:stone).getDefaultState());}
   else if(target<top-1){for(int y=top;y>target;y--)w.setBlockState(new BlockPos(x,y,z),Blocks.AIR.getDefaultState());w.setBlockState(new BlockPos(x,target,z),soil.getDefaultState());}
   if(water && target<(b.equals("flooded_ruins")?67:61)){int sea=b.equals("flooded_ruins")?67:61;for(int y=target+1;y<=sea;y++)w.setBlockState(new BlockPos(x,y,z),Blocks.WATER.getDefaultState());}
   // Biome signatures: stable, seed-dependent formations that make each biome visually distinct.
   long q=hash(x,z,seed^0x7f4a7c15L);
   if(Math.floorMod(q,211)==9&&target>w.getBottomY()+4)w.setBlockState(new BlockPos(x,target+1,z),cr.getDefaultState());
   if(b.equals("ancient_canyon")&&Math.floorMod(q,17)==2)for(int y=target-2;y<=target+2;y++)if(y>w.getBottomY())w.setBlockState(new BlockPos(x,y,z),stone.getDefaultState());
   if(b.equals("serpent_valley")&&Math.floorMod(q,19)==3)for(int y=target-3;y<=target;y++)if(y>w.getBottomY())w.setBlockState(new BlockPos(x,y,z),Blocks.WATER.getDefaultState());
   if((b.equals("sunken_throne")||b.equals("great_sinkhole"))&&Math.floorMod(q,29)==4)for(int y=target-1;y<=target+2;y++)if(y>w.getBottomY())w.setBlockState(new BlockPos(x,y,z),cr.getDefaultState());
   if((mode==3||mode==10||mode==19)&&Math.floorMod(hash(x,z,seed^99),83)==2)for(int y=target-2;y<=target;y++)if(y>w.getBottomY())w.setBlockState(new BlockPos(x,y,z),Blocks.WATER.getDefaultState());
   if(sky){double island=valueNoise(x,z,seed^0x6a09e667L,256)+0.42*valueNoise(x,z,seed^0xbb67ae85L,96);if(island>0.58){int iy=126+(int)Math.round(island*42.0)+Math.floorMod((int)hash(x>>4,z>>4,seed),20);int thickness=5+(int)Math.floorMod(hash(x,z,seed^77),10);double edge=valueNoise(x,z,seed^0x3c6ef372L,56);if(edge> -0.55){for(int y=iy-thickness;y<=iy;y++){double fall=(iy-y)/(double)Math.max(1,thickness);if(fall<0.92)w.setBlockState(new BlockPos(x,y,z),(y==iy?soil:stone).getDefaultState());}if(Math.floorMod(hash(x,z,seed^88),43)==3)w.setBlockState(new BlockPos(x,iy+1,z),cr.getDefaultState());}}}
  }
 }
 private static void caves(ServerWorld w,int x0,int z0,String b,long seed){
  long h=hash(x0>>4,z0>>4,seed^0x9e3779b97f4a7c15L);
  // Huge connected-looking cave networks. Each chunk gets several deterministic
  // segments, while anchor coordinates are based on larger regions so adjacent
  // chunks naturally continue the same cave systems.
  int networks=1+(int)Math.floorMod(h,4);
  for(int n=0;n<networks;n++){
   long nh=hash((x0>>4)+n*31,(z0>>4)-n*17,seed^0x6a09e667f3bcc909L);
   int cx=x0+8+(int)Math.floorMod(nh,12)-6;
   int cz=z0+8+(int)Math.floorMod(nh>>9,12)-6;
   int cy=10+(int)Math.floorMod(nh>>18,58);
   int chambers=9+(int)Math.floorMod(nh>>27,13);
   int px=cx,py=cy,pz=cz;
   for(int i=0;i<chambers;i++){
    long ch=hash((x0>>4)+i*13,(z0>>4)-i*19,nh);
    int tx=px+(int)Math.floorMod(ch,31)-15;
    int tz=pz+(int)Math.floorMod(ch>>8,31)-15;
    int ty=Math.max(7,Math.min(72,py+(int)Math.floorMod(ch>>16,17)-8));
    int rx=5+(int)Math.floorMod(ch>>24,11), rz=5+(int)Math.floorMod(ch>>31,11), ry=3+(int)Math.floorMod(ch>>39,7);
    carve(w,tx,ty,tz,rx,ry,rz);
    tunnel(w,px,py,pz,tx,ty,tz);
    if(i%2==0) decorateCave(w,tx,ty,tz,b,ch);
    px=tx;py=ty;pz=tz;
   }
   // Rare gigantic chamber, the Sunken Sands equivalent of a giant Minecraft cave.
   if(Math.floorMod(nh,23)==4){
    int gx=x0+8+(int)Math.floorMod(nh>>10,9)-4, gz=z0+8+(int)Math.floorMod(nh>>20,9)-4;
    int gy=14+(int)Math.floorMod(nh>>30,38);
    carve(w,gx,gy,gz,22,13,22);
    carve(w,gx,gy+9,gz,15,8,15);
    decorateCave(w,gx,gy,gz,b,nh^0x51ed270bL);
   }
   if(b.equals("flooded_ruins")||b.equals("crystal_sands")||b.equals("moonlit_desert")||b.equals("sunken_oasis")){
    int waterY=Math.max(8,cy-3);
    for(int dx=-6;dx<=6;dx++)for(int dz=-6;dz<=6;dz++)if(dx*dx+dz*dz<34)w.setBlockState(new BlockPos(cx+dx,waterY,cz+dz),Blocks.WATER.getDefaultState());
   }
   if(Math.floorMod(nh,17)==3)spawnMob(w,new BlockPos(cx,cy,cz),b,nh);
  }
 }
 private static void decorateCave(ServerWorld w,int x,int y,int z,String b,long h){Block cr=sb(b,SunkenSandsBiomeContent.CRYSTAL),moss=sb(b,SunkenSandsBiomeContent.MOSS),rune=sb(b,SunkenSandsBiomeContent.RUNE);for(int i=0;i<12;i++){int dx=(int)Math.floorMod(hash(x+i,z-i,h),11)-5,dz=(int)Math.floorMod(hash(x-i,z+i,h^33),11)-5;BlockPos q=new BlockPos(x+dx,y+(int)Math.floorMod(h+i,5)-2,z+dz);if(w.getBlockState(q).isAir())w.setBlockState(q,cr.getDefaultState());if(i%3==0&&w.getBlockState(q.down()).isAir())w.setBlockState(q.down(),moss.getDefaultState());}if(Math.floorMod(h,7)==1)w.setBlockState(new BlockPos(x,y+2,z),rune.getDefaultState());}
 private static void carve(ServerWorld w,int cx,int cy,int cz,int rx,int ry,int rz){for(int x=-rx;x<=rx;x++)for(int y=-ry;y<=ry;y++)for(int z=-rz;z<=rz;z++)if((x*x)/(double)(rx*rx)+(y*y)/(double)(ry*ry)+(z*z)/(double)(rz*rz)<1)w.setBlockState(new BlockPos(cx+x,cy+y,cz+z),Blocks.AIR.getDefaultState());} private static void tunnel(ServerWorld w,int x1,int y1,int z1,int x2,int y2,int z2){int s=Math.max(Math.abs(x2-x1),Math.max(Math.abs(y2-y1),Math.abs(z2-z1)));for(int i=0;i<=s;i++){double t=s==0?0:(double)i/s;carve(w,(int)Math.round(x1+(x2-x1)*t),(int)Math.round(y1+(y2-y1)*t),(int)Math.round(z1+(z2-z1)*t),3,3,3);}}
 private static SunkenSandsStructureKind randomStructureKind(long h){return SunkenSandsStructureKind.values()[(int)Math.floorMod(h>>>7,SunkenSandsStructureKind.values().length)];}
 private static void structure(ServerWorld w,BlockPos p,String b,long h,SunkenSandsStructureKind sk){
  Block wall=SunkenSandsStructureBlocks.WALL.get(sk), floor=SunkenSandsStructureBlocks.FLOOR.get(sk), relic=SunkenSandsStructureBlocks.RELIC.get(sk);
  int r=10+(int)Math.floorMod(h,9), height=7+(int)Math.floorMod(h>>8,6);
  for(int x=-r;x<=r;x++)for(int z=-r;z<=r;z++){boolean edge=Math.abs(x)==r||Math.abs(z)==r; if(edge)for(int y=0;y<=height;y++)w.setBlockState(p.add(x,y,z),wall.getDefaultState()); else w.setBlockState(p.add(x,0,z),floor.getDefaultState());}
  for(int y=1;y<height;y+=2){for(int x=-r+2;x<=r-2;x+=4){w.setBlockState(p.add(x,y,-r+1),relic.getDefaultState());w.setBlockState(p.add(x,y,r-1),relic.getDefaultState());}for(int z=-r+2;z<=r-2;z+=4){w.setBlockState(p.add(-r+1,y,z),relic.getDefaultState());w.setBlockState(p.add(r-1,y,z),relic.getDefaultState());}}
  for(int x=-2;x<=2;x++)for(int z=-2;z<=2;z++)w.setBlockState(p.add(x,height,z),relic.getDefaultState());
  // Four guards + one stronger warden; every structure therefore has its own enemy family.
  for(int i=0;i<4;i++){BlockPos q=p.add((i%2==0?-r+3:r-3),1,(i<2?-r+3:r-3));spawnStructureMob(w,q,sk);}
  spawnStructureMiniBoss(w,p.up(1),sk);
}
 private static void dungeon(ServerWorld w,BlockPos p,String b,long h){Block core=SunkenSandsBlocks.DUNGEON_CORE.get(b),stone=SunkenSandsBlocks.BIOME_STONE.get(b);BlockPos c=p.down(18);for(int i=0;i<7;i++){BlockPos r=c.add((i%3)*14,(i==6?-2:0),(i/3)*14);for(int x=-6;x<=6;x++)for(int y=-3;y<=5;y++)for(int z=-6;z<=6;z++){boolean shell=Math.abs(x)==6||Math.abs(z)==6||y==-3||y==5;w.setBlockState(r.add(x,y,z),shell?core.getDefaultState():Blocks.AIR.getDefaultState());}w.setBlockState(r.up(4),stone.getDefaultState());if(i<6)tunnel(w,r.getX(),r.getY(),r.getZ(),c.add(((i+1)%3)*14,0,((i+1)/3)*14).getX(),c.getY(),c.add(((i+1)%3)*14,0,((i+1)/3)*14).getZ());}/* Main bosses are placed by deterministic seed-based world sites, not by every dungeon. */}
 private static void spawnStructureMob(ServerWorld w,BlockPos p,SunkenSandsStructureKind k){EntityType<SunkenSandsStructureMobEntity> t=OverworldPlus.SUNKEN_SANDS_STRUCTURE_MOBS.get(k);if(t==null)return;SunkenSandsStructureMobEntity e=new SunkenSandsStructureMobEntity(t,w,k);e.refreshPositionAndAngles(p.getX()+.5,p.getY()+1,p.getZ()+.5,0,0);w.spawnEntity(e);}
 private static void spawnStructureMiniBoss(ServerWorld w,BlockPos p,SunkenSandsStructureKind k){EntityType<SunkenSandsStructureMiniBossEntity> t=OverworldPlus.SUNKEN_SANDS_STRUCTURE_MINI_BOSSES.get(k);if(t==null)return;SunkenSandsStructureMiniBossEntity e=new SunkenSandsStructureMiniBossEntity(t,w,k);e.refreshPositionAndAngles(p.getX()+.5,p.getY()+1,p.getZ()+.5,0,0);w.spawnEntity(e);}
 private static void spawnMob(ServerWorld w,BlockPos p,String b,long h){SunkenSandsCreatureKind k=MOB.get(b);EntityType<SunkenSandsCreatureEntity> t=OverworldPlus.SUNKEN_SANDS_CREATURES.get(k);if(t==null)return;SunkenSandsCreatureEntity e=new SunkenSandsCreatureEntity(t,w,k);e.refreshPositionAndAngles(p.getX()+.5,p.getY()+1,p.getZ()+.5,0,0);w.spawnEntity(e);}
 private static void spawnElite(ServerWorld w,BlockPos p,String b){SunkenSandsCreatureKind k=MOB.get(b);EntityType<SunkenSandsCreatureEntity> t=OverworldPlus.SUNKEN_SANDS_CREATURES.get(k);if(t==null)return;SunkenSandsCreatureEntity e=new SunkenSandsCreatureEntity(t,w,k);e.setElite(true);e.refreshPositionAndAngles(p.getX()+.5,p.getY()+1,p.getZ()+.5,0,0);w.spawnEntity(e);}
 private static void spawnNpc(ServerWorld w,BlockPos p,long h){if(OverworldPlus.SUNKEN_SANDS_NPC==null)return;SunkenSandsNPCEntity e=new SunkenSandsNPCEntity(OverworldPlus.SUNKEN_SANDS_NPC,w);e.setProfession(SunkenSandsNpcProfession.values()[(int)Math.floorMod(h,SunkenSandsNpcProfession.values().length)]);e.refreshPositionAndAngles(p.getX()+2.5,p.getY()+1,p.getZ()+2.5,0,0);w.spawnEntity(e);}
 private static void tryMainBossSite(ServerWorld w,int cx,int cz){
  long seed=w.getSeed();
  for(int i=0;i<SunkenSandsBossKind.values().length;i++){
   long a=hash((int)(seed+i*0x45d9f3bL),(int)(seed^(i*0x27d4eb2dL)),seed^0x6a09e667L);
   int targetX=(int)Math.floorMod(a,4096)-2048;
   int targetZ=(int)Math.floorMod(a>>>32,4096)-2048;
   if(Math.abs(cx-targetX)>0||Math.abs(cz-targetZ)>0)continue;
   SunkenSandsBossKind k=SunkenSandsBossKind.values()[i];
   BlockPos center=new BlockPos(cx*16+8,w.getTopY(Heightmap.Type.WORLD_SURFACE,cx*16+8,cz*16+8)+2,cz*16+8);
   if(!isBossSiteSuitable(w,center,k))return;
   BlockPos marker=center.down();
   if(w.getBlockState(marker).isOf(SunkenSandsBlocks.DUNGEON_CORE.get(biome(w,center))))return;
   buildBossArena(w,center,k);
   w.setBlockState(marker,SunkenSandsBlocks.DUNGEON_CORE.get(biome(w,center)).getDefaultState());
   EntityType<SunkenSandsBossEntity> t=OverworldPlus.SUNKEN_SANDS_BOSSES.get(k);if(t==null)return;
   SunkenSandsBossEntity e=new SunkenSandsBossEntity(t,w,k);e.refreshPositionAndAngles(center.getX()+.5,center.getY()+1,center.getZ()+.5,0,0);e.setPersistent();w.spawnEntity(e);
   return;
  }
 }
 private static boolean isBossSiteSuitable(ServerWorld w,BlockPos p,SunkenSandsBossKind k){
  String b=biome(w,p);return switch(k){
   case SUN_KING->b.equals("red_sand_expanse")||b.equals("golden_dunes");
   case SCORPION_EMPEROR->b.equals("sandstorm_plains")||b.equals("flooded_ruins");
   case SAND_SERPENT->b.equals("sandswept_mountains")||b.equals("sandswept_mountains");
   case PHARAOH->b.equals("buried_kingdom")||b.equals("flooded_ruins");
   case DUNE_TYRANT->b.equals("sandswept_mountains")||b.equals("red_sand_expanse");
   case BURIED_LICH->b.equals("sandstorm_plains");
   case ANCIENT_COLOSSUS->b.equals("moonlit_desert");
   case DROWNED_GUARDIAN->b.equals("great_sinkhole");
   case MOON_QUEEN->b.equals("dune_graveyard");
   case SUNKEN_GOD->b.equals("sunken_throne")||b.equals("ancient_sunlands");
  };}
 private static void spawnBoss(ServerWorld w,BlockPos p,int idx){SunkenSandsBossKind k=SunkenSandsBossKind.values()[idx];EntityType<SunkenSandsBossEntity> t=OverworldPlus.SUNKEN_SANDS_BOSSES.get(k);if(t==null)return;buildBossArena(w,p,k);SunkenSandsBossEntity e=new SunkenSandsBossEntity(t,w,k);e.refreshPositionAndAngles(p.getX()+.5,p.getY()+1,p.getZ()+.5,0,0);w.spawnEntity(e);}
 private static void buildBossArena(ServerWorld w,BlockPos p,SunkenSandsBossKind k){
  String b=switch(k){case SUN_KING->"red_sand_expanse";case SCORPION_EMPEROR->"sandstorm_plains";case SAND_SERPENT->"sandswept_mountains";case PHARAOH->"buried_kingdom";case DUNE_TYRANT->"sandswept_mountains";case BURIED_LICH->"sandstorm_plains";case ANCIENT_COLOSSUS->"moonlit_desert";case DROWNED_GUARDIAN->"great_sinkhole";case MOON_QUEEN->"dune_graveyard";case SUNKEN_GOD->"sunken_throne";};
  Block floor=SunkenSandsBiomeContent.STONE.get(b), rune=SunkenSandsBiomeContent.RUNE.get(b), crystal=SunkenSandsBiomeContent.CRYSTAL.get(b); int r=13;
  for(int x=-r;x<=r;x++)for(int z=-r;z<=r;z++){double d=Math.sqrt(x*x+z*z);if(d<=r)w.setBlockState(p.add(x,0,z),floor.getDefaultState());}
  for(int x=-r;x<=r;x++)for(int z=-r;z<=r;z++){double d=Math.sqrt(x*x+z*z);if(d>r-1&&d<=r+1)for(int y=1;y<=4;y++)w.setBlockState(p.add(x,y,z),rune.getDefaultState());}
  int pillars=switch(k){case BURIED_LICH,SUNKEN_GOD->8;case SAND_SERPENT,MOON_QUEEN->6;default->4;};
  for(int i=0;i<pillars;i++){double a=i*Math.PI*2/pillars;int x=(int)Math.round(Math.cos(a)*9),z=(int)Math.round(Math.sin(a)*9);for(int y=1;y<=5+(i%3);y++)w.setBlockState(p.add(x,y,z),crystal.getDefaultState());}
  w.setBlockState(p.up(5),crystal.getDefaultState());
 }
 
 private static SunkenSandsBiomeKind profile(String b){return SunkenSandsBiomeKind.byId(b);}
 private static Block sb(String b, Map<String,Block> map){return map.getOrDefault(b,Blocks.STONE);}
 private static void biomeCity(ServerWorld w,BlockPos p,String b,long h){
  SunkenSandsBiomeKind k=profile(b); Block brick=sb(b,SunkenSandsBiomeContent.BRICK),floor=sb(b,SunkenSandsBiomeContent.WOOD),rune=sb(b,SunkenSandsBiomeContent.RUNE),soil=sb(b,SunkenSandsBiomeContent.SOIL),stone=sb(b,SunkenSandsBiomeContent.STONE);
  int r=16+(int)Math.floorMod(h,8); BlockPos c=p.add(0,1,0);
  for(int x=-r;x<=r;x++)for(int z=-r;z<=r;z++){double d=Math.max(Math.abs(x),Math.abs(z)); if(d==r||d==r-1)w.setBlockState(c.add(x,0,z),brick.getDefaultState()); else if(d<r-2)w.setBlockState(c.add(x,0,z),floor.getDefaultState());}
  for(int x=-2;x<=2;x++)for(int z=-2;z<=2;z++)w.setBlockState(c.add(x,1,z),rune.getDefaultState());
  int[][] houses={{-11,-11},{11,-11},{-11,11},{11,11}};
  for(int[] q:houses) cityHouse(w,c.add(q[0],0,q[1]),brick,floor,rune,soil,Math.floorMod(h+q[0]*31L+q[1],3)+1);
  for(int i=0;i<3;i++){BlockPos np=c.add(-2+i*2,1,5);if(w.getBlockState(np).isAir())spawnNpc(w,np,h+i*77);}
  for(int x=-3;x<=3;x++)for(int z=-3;z<=3;z++)if((Math.abs(x)+Math.abs(z))%2==0)w.setBlockState(c.add(x,1,z),rune.getDefaultState());
  w.setBlockState(c.add(0,2,0),sb(b,SunkenSandsBiomeContent.CRYSTAL).getDefaultState());
 }
 private static void cityHouse(ServerWorld w,BlockPos c,Block brick,Block floor,Block rune,Block soil,int style){
  int r=4,h=3+style;for(int x=-r;x<=r;x++)for(int z=-r;z<=r;z++){boolean edge=Math.abs(x)==r||Math.abs(z)==r;for(int y=0;y<=h;y++)if(edge||y==h)w.setBlockState(c.add(x,y,z),y==h?floor.getDefaultState():brick.getDefaultState());else w.setBlockState(c.add(x,y,z),Blocks.AIR.getDefaultState());}
  for(int x=-r+1;x<=r-1;x+=2)for(int z=-r+1;z<=r-1;z+=2)w.setBlockState(c.add(x,h+1,z),rune.getDefaultState());
  w.setBlockState(c.add(0,1,r),Blocks.AIR.getDefaultState());
 }
 private static void biomeLandmark(ServerWorld w,BlockPos p,String b,long h){
  Block brick=sb(b,SunkenSandsBiomeContent.BRICK),floor=sb(b,SunkenSandsBiomeContent.STONE),rune=sb(b,SunkenSandsBiomeContent.RUNE),cr=sb(b,SunkenSandsBiomeContent.CRYSTAL);int r=9+(int)Math.floorMod(h,6),height=8+(int)Math.floorMod(h>>7,8);
  for(int x=-r;x<=r;x++)for(int z=-r;z<=r;z++){if(Math.abs(x)==r||Math.abs(z)==r)for(int y=0;y<=height;y++)w.setBlockState(p.add(x,y,z),brick.getDefaultState());else w.setBlockState(p.add(x,0,z),floor.getDefaultState());}
  for(int i=0;i<4;i++){int dx=i<2?-r+2:r-2,dz=i%2==0?-r+2:r-2;for(int y=height/2;y<=height+2;y++)w.setBlockState(p.add(dx,y,dz),rune.getDefaultState());}
  for(int y=1;y<height;y+=2)for(int a=0;a<8;a++){double ang=a*Math.PI/4;int x=(int)Math.round(Math.cos(ang)*(r-2)),z=(int)Math.round(Math.sin(ang)*(r-2));w.setBlockState(p.add(x,y,z),cr.getDefaultState());}
  w.setBlockState(p.up(height+2),cr.getDefaultState());
  spawnBiomeMiniBoss(w,p.up(1),b);
  for(int i=0;i<4;i++)spawnMob(w,p.add(-3+i*2,1,-r+3),b,h+i);
 }
 private static void biomeDungeon(ServerWorld w,BlockPos p,String b,long h){
  Block brick=sb(b,SunkenSandsBiomeContent.BRICK),floor=sb(b,SunkenSandsBiomeContent.STONE),rune=sb(b,SunkenSandsBiomeContent.RUNE),cr=sb(b,SunkenSandsBiomeContent.CRYSTAL);BlockPos c=p.down(24);int rooms=9;
  for(int i=0;i<rooms;i++){int gx=(i%3)*16-16,gz=(i/3)*16-16,gy=(i==8?2:0);BlockPos r=c.add(gx,gy,gz);for(int x=-6;x<=6;x++)for(int z=-6;z<=6;z++)for(int y=-3;y<=5;y++){boolean wall=Math.abs(x)==6||Math.abs(z)==6||y==-3||y==5;w.setBlockState(r.add(x,y,z),wall?brick.getDefaultState():floor.getDefaultState());if(!wall&&y<4)w.setBlockState(r.add(x,y+1,z),Blocks.AIR.getDefaultState());}w.setBlockState(r.up(4),cr.getDefaultState());if(i<8){int nx=((i+1)%3)*16-16,nz=((i+1)/3)*16-16;tunnel(w,r.getX(),r.getY(),r.getZ(),c.getX()+nx,c.getY()+gy,c.getZ()+nz);}if(i%2==0)spawnMob(w,r.add(0,1,0),b,h+i*17);}
  BlockPos boss=c.add(16,2,16);for(int x=-7;x<=7;x++)for(int z=-7;z<=7;z++)if(Math.abs(x)==7||Math.abs(z)==7)for(int y=0;y<=5;y++)w.setBlockState(boss.add(x,y,z),rune.getDefaultState());w.setBlockState(boss.up(5),cr.getDefaultState());spawnBiomeMiniBoss(w,boss.up(1),b);
 }
 private static void spawnBiomeMiniBoss(ServerWorld w,BlockPos p,String b){for(SunkenSandsBiomeMiniBossKind k:SunkenSandsBiomeMiniBossKind.values())if(k.biome.equals(b)){EntityType<SunkenSandsBiomeMiniBossEntity> t=OverworldPlus.SUNKEN_SANDS_BIOME_MINI_BOSSES.get(k);if(t==null)return;SunkenSandsBiomeMiniBossEntity e=new SunkenSandsBiomeMiniBossEntity(t,w,k);e.refreshPositionAndAngles(p.getX()+.5,p.getY()+1,p.getZ()+.5,0,0);w.spawnEntity(e);return;}}
 private static void oreVeins(ServerWorld w,int x0,int z0,String b,long seed){
  // Large deterministic ore clusters. Rarer ores are deeper and have smaller veins.
  String[] ores={"sandsteel","sun_crystal","scorpite","duneite","moon_crystal","serpentium","pharaohite","sunken_core"};
  for(int oi=0;oi<ores.length;oi++){
   String ore=ores[oi];
   Block ob=SunkenSandsBlocks.ORES.get(ore);
   if(ob==null)continue;
   int rarity=ore.equals("sunken_core")?181:ore.equals("pharaohite")?97:ore.equals("moon_crystal")?67:31;
   long h=hash(x0/16+oi*17,z0/16-oi*23,seed^ore.hashCode()*0x9e3779b9L);
   if(Math.floorMod(h,rarity)>2)continue;
   int veins=1+(int)Math.floorMod(h>>8,3);
   for(int v=0;v<veins;v++){
    long vh=hash(x0+v*29,z0-v*37,h);
    int x=x0+2+(int)Math.floorMod(vh,12), z=z0+2+(int)Math.floorMod(vh>>9,12);
    int minY=ore.equals("sunken_core")?6:ore.equals("pharaohite")?10:18;
    int maxY=ore.equals("sunken_core")?22:ore.equals("pharaohite")?38:58;
    int y=minY+(int)Math.floorMod(vh>>18,Math.max(1,maxY-minY+1));
    int size=4+(int)Math.floorMod(vh>>27,10);
    for(int i=0;i<size;i++){
     long ch=hash(x+i*11,z-i*7,vh);
     BlockPos q=new BlockPos(x+(int)Math.floorMod(ch,5)-2,y+(int)Math.floorMod(ch>>8,5)-2,z+(int)Math.floorMod(ch>>16,5)-2);
     if(q.getY()<=w.getBottomY()+2||q.getY()>=w.getTopY()-5)continue;
     Block current=w.getBlockState(q).getBlock();
     if(isOreHost(current,b))w.setBlockState(q,ob.getDefaultState());
    }
   }
  }
 }
 private static boolean isOreHost(Block block,String b){
  if(block==Blocks.STONE||block==Blocks.DEEPSLATE||block==Blocks.SANDSTONE||block==Blocks.RED_SANDSTONE||block==Blocks.BLACKSTONE)return true;
  Block bs=SunkenSandsBiomeContent.STONE.get(b); return bs!=null&&block==bs;
 }
 private static void tick(ServerWorld w){
  if(!isStorm(w))return;
  for(ServerPlayerEntity p:w.getPlayers()){
   applyEquipmentBonuses(p);
   if(w.getTime()%100==0)guideToTrueShrine(p,w);
   if(w.getTime()%20==0)applyHeldAbility(p,w);
   if(w.getTime()%900==0){
    long h=hash(p.getBlockX()>>4,p.getBlockZ()>>4,w.getSeed()^w.getTime());
    if(Math.floorMod(h,4)==0){w.setWeather(0,500,true,false);w.spawnParticles(ParticleTypes.FALLING_DUST,p.getX(),p.getY()+2,p.getZ(),120,6,4,6,.15);p.sendMessage(Text.literal("§6A colossal Sunken Sands storm tears across the desert!"),true);}
   }
  }
 }
 private static void applyHeldAbility(ServerPlayerEntity p,ServerWorld w){
  if(!p.isSneaking())return;
  Item held=p.getMainHandStack().getItem();
  String id=net.minecraft.registry.Registries.ITEM.getId(held).getPath();
  if(!id.startsWith("sunken_sands_"))return;
  String a=id.substring("sunken_sands_".length());
  if(!SunkenSandsItems.ABILITIES.containsKey(a))return;
  switch(a){
   case "fire_dash" -> {p.addStatusEffect(new StatusEffectInstance(StatusEffects.SPEED,50,2));p.addStatusEffect(new StatusEffectInstance(StatusEffects.FIRE_RESISTANCE,50,0));}
   case "solar_beam" -> {p.addStatusEffect(new StatusEffectInstance(StatusEffects.STRENGTH,50,2));p.addStatusEffect(new StatusEffectInstance(StatusEffects.GLOWING,50,0));}
   case "venom_strike" -> {p.addStatusEffect(new StatusEffectInstance(StatusEffects.STRENGTH,50,1));p.addStatusEffect(new StatusEffectInstance(StatusEffects.POISON,35,0));}
   case "sand_dash" -> {p.addStatusEffect(new StatusEffectInstance(StatusEffects.SPEED,50,3));p.addStatusEffect(new StatusEffectInstance(StatusEffects.JUMP_BOOST,50,1));}
   case "moon_step" -> {p.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION,80,0));p.addStatusEffect(new StatusEffectInstance(StatusEffects.SPEED,50,2));}
   case "ancient_barrier" -> p.addStatusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE,50,2));
   case "sandstorm" -> {p.addStatusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE,50,1));p.addStatusEffect(new StatusEffectInstance(StatusEffects.SPEED,50,1));}
   case "dune_explosion" -> p.addStatusEffect(new StatusEffectInstance(StatusEffects.STRENGTH,50,3));
   case "serpent_summon" -> {p.addStatusEffect(new StatusEffectInstance(StatusEffects.POISON,30,1));p.addStatusEffect(new StatusEffectInstance(StatusEffects.POISON,30,0));}
   case "pharaohs_wrath" -> {p.addStatusEffect(new StatusEffectInstance(StatusEffects.STRENGTH,60,3));p.addStatusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE,60,1));p.addStatusEffect(new StatusEffectInstance(StatusEffects.HASTE,60,2));}
  }
 }
 private static void applyEquipmentBonuses(ServerPlayerEntity p){
  if(p.age%40!=0)return;
  String set=null;
  for(ItemStack s:p.getArmorItems()){
   String id=net.minecraft.registry.Registries.ITEM.getId(s.getItem()).getPath();
   if(!id.startsWith("sunken_sands_")||!id.endsWith("_helmet")&&!id.endsWith("_chestplate")&&!id.endsWith("_leggings")&&!id.endsWith("_boots")){set=null;break;}
   String path=id.substring("sunken_sands_".length());
   String candidate=path.substring(0,path.lastIndexOf('_'));
   if(set==null)set=candidate;else if(!set.equals(candidate)){set=null;break;}
  }
  if(set==null)return;
  switch(set){
   case "sandsteel" -> p.addStatusEffect(new StatusEffectInstance(StatusEffects.HASTE,60,0));
   case "sun_crystal" -> p.addStatusEffect(new StatusEffectInstance(StatusEffects.FIRE_RESISTANCE,80,0));
   case "scorpite" -> p.addStatusEffect(new StatusEffectInstance(StatusEffects.POISON,40,0));
   case "duneite" -> {p.addStatusEffect(new StatusEffectInstance(StatusEffects.SPEED,80,1));p.addStatusEffect(new StatusEffectInstance(StatusEffects.JUMP_BOOST,80,1));}
   case "moon_crystal" -> p.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION,100,0));
   case "serpentium" -> p.addStatusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE,80,0));
   case "pharaohite" -> p.addStatusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE,80,1));
   case "sunken_core" -> p.addStatusEffect(new StatusEffectInstance(StatusEffects.REGENERATION,80,0));
  }
 }

 private SunkenSandsWorldSystems(){} }
