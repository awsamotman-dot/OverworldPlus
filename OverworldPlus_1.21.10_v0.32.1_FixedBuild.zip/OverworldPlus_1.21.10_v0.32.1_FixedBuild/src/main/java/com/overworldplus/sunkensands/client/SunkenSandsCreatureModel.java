package com.overworldplus.sunkensands.client;

import com.overworldplus.sunkensands.SunkenSandsCreatureEntity;
import com.overworldplus.sunkensands.SunkenSandsCreatureKind;
import net.minecraft.client.model.*;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.MathHelper;

/** Fully custom procedural creature silhouettes; every kind gets a different body kit. */
public class SunkenSandsCreatureModel extends EntityModel<SunkenSandsCreatureEntity> {
    private final ModelPart root, body, head, leftLeg, rightLeg, leftArm, rightArm, extra1, extra2, tail;
    private final SunkenSandsCreatureKind kind;
    public SunkenSandsCreatureModel(ModelPart root, SunkenSandsCreatureKind kind) {
        super(root); this.root=root; this.kind=kind;
        body=root.getChild("body"); head=root.getChild("head"); leftLeg=root.getChild("left_leg"); rightLeg=root.getChild("right_leg");
        leftArm=root.getChild("left_arm"); rightArm=root.getChild("right_arm"); extra1=root.getChild("extra1"); extra2=root.getChild("extra2"); tail=root.getChild("tail");
    }
    public static TexturedModelData create(SunkenSandsCreatureKind k) {
        ModelData d=new ModelData(); ModelPartData r=d.getRoot();
        r.addChild("body",ModelPartBuilder.create().uv(0,0).cuboid(-5,-8,-4,10,14,8),ModelTransform.pivot(0,8,0));
        r.addChild("head",ModelPartBuilder.create().uv(0,24).cuboid(-5,-5,-5,10,10,10),ModelTransform.pivot(0,-2,-2));
        r.addChild("left_leg",ModelPartBuilder.create().uv(40,0).cuboid(-2,0,-2,4,10,4),ModelTransform.pivot(3,14,0));
        r.addChild("right_leg",ModelPartBuilder.create().uv(40,14).cuboid(-2,0,-2,4,10,4),ModelTransform.pivot(-3,14,0));
        r.addChild("left_arm",ModelPartBuilder.create().uv(56,0).cuboid(-2,-1,-2,4,11,4),ModelTransform.pivot(7,2,0));
        r.addChild("right_arm",ModelPartBuilder.create().uv(56,15).cuboid(-2,-1,-2,4,11,4),ModelTransform.pivot(-7,2,0));
        r.addChild("extra1",ModelPartBuilder.create().uv(0,44).cuboid(-7,-12,-1,14,4,2),ModelTransform.pivot(0,0,0));
        r.addChild("extra2",ModelPartBuilder.create().uv(0,50).cuboid(-6,-4,-7,12,5,3),ModelTransform.pivot(0,0,0));
        r.addChild("tail",ModelPartBuilder.create().uv(64,34).cuboid(-2,0,-2,4,12,4),ModelTransform.pivot(0,9,4));
        return TexturedModelData.of(d,128,128);
    }
    @Override public void setAngles(SunkenSandsCreatureEntity e,float limb,float distance,float age,float yaw,float pitch){
        head.yaw=yaw*MathHelper.RADIANS_PER_DEGREE; head.pitch=pitch*MathHelper.RADIANS_PER_DEGREE;
        float walk=MathHelper.cos(limb*0.8f)*distance*0.9f; leftLeg.pitch=walk; rightLeg.pitch=-walk; leftArm.pitch=-walk*.55f; rightArm.pitch=walk*.55f;
        float bob=MathHelper.sin(age*.12f)*.12f; body.pivotY=8+bob; tail.pitch=MathHelper.sin(age*.1f)*.18f;
        extra1.yaw=0; extra1.pitch=0; extra1.roll=0; extra2.yaw=0; extra2.pitch=0; extra2.roll=0;
        switch(kind){
            case CANYON_DRAKE -> { leftArm.pitch-=.35f; rightArm.pitch+=.35f; extra1.pitch=MathHelper.sin(age*.16f)*.18f; }
            case BLACK_SCORPION, POISON_SCORPION -> { tail.pitch=-.7f+MathHelper.sin(age*.12f)*.08f; extra1.yaw=MathHelper.sin(age*.18f)*.15f; }
            case SAND_VULTURE, DUNE_RAVEN -> { leftArm.roll=-.55f; rightArm.roll=.55f; leftArm.pitch=MathHelper.sin(age*.45f)*.45f; rightArm.pitch=-MathHelper.sin(age*.45f)*.45f; }
            case OBSIDIAN_BEETLE, CRYSTAL_BEETLE -> { body.pitch=.08f; extra1.roll=MathHelper.sin(age*.08f)*.08f; }
            case JUNGLE_PANTHER, SAND_JACKAL, BLACK_JACKAL -> { body.pitch=.12f; leftLeg.pitch*=1.3f; rightLeg.pitch*=1.3f; }
            case SAND_SERPENT, SINKHOLE_HORROR -> { body.pitch=.18f; tail.yaw=MathHelper.sin(age*.18f)*.25f; }
            case MOON_MOTH -> { leftArm.roll=-.9f+MathHelper.sin(age*.2f)*.15f; rightArm.roll=.9f-MathHelper.sin(age*.2f)*.15f; }
            case ROYAL_CAMEL, GOLDEN_CAMEL, RED_DROMEDARY -> { head.pitch+=.08f; tail.yaw=MathHelper.sin(age*.06f)*.12f; }
            case SAND_RAM -> { head.pitch=.18f; extra1.roll=MathHelper.sin(age*.1f)*.06f; }
            default -> {}
        }
        if(e.getSkillTimer()>0){float p=MathHelper.sin((e.getSkillTimer()/12f)*MathHelper.PI); leftArm.pitch-=.8f*p; rightArm.pitch-=.8f*p; body.pitch+=.12f*p;}
    }
    @Override public void render(MatrixStack matrices, VertexConsumer vertices,int light,int overlay,int color){root.render(matrices,vertices,light,overlay,color);}
}
