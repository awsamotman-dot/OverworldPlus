package com.overworldplus.sunkensands;
import com.overworldplus.OverworldPlus;
import net.minecraft.block.*; import net.minecraft.item.BlockItem; import net.minecraft.registry.*; import net.minecraft.util.Identifier; import java.util.*;
public final class SunkenSandsStructureBlocks {
 public static final Map<SunkenSandsStructureKind,Block> WALL=new EnumMap<>(SunkenSandsStructureKind.class);
 public static final Map<SunkenSandsStructureKind,Block> FLOOR=new EnumMap<>(SunkenSandsStructureKind.class);
 public static final Map<SunkenSandsStructureKind,Block> RELIC=new EnumMap<>(SunkenSandsStructureKind.class);
 private static Block reg(String id, Block b){return Registry.register(Registries.BLOCK,Identifier.of(OverworldPlus.MOD_ID,id),b);}
 static {
  WALL.put(SunkenSandsStructureKind.DUNE_PALACE,reg("sunken_sands_sky_citadel_wall",new Block(AbstractBlock.Settings.copy(Blocks.POLISHED_DEEPSLATE).strength(5.5f,25f))));
  FLOOR.put(SunkenSandsStructureKind.DUNE_PALACE,reg("sunken_sands_sky_citadel_floor",new Block(AbstractBlock.Settings.copy(Blocks.DEEPSLATE_TILES).strength(4.5f,20f))));
  RELIC.put(SunkenSandsStructureKind.DUNE_PALACE,reg("sunken_sands_sky_citadel_relic",new Block(AbstractBlock.Settings.copy(Blocks.AMETHYST_BLOCK).strength(3.5f,18f).luminance(s->9))));
  WALL.put(SunkenSandsStructureKind.SANDSTORM_FORTRESS,reg("sunken_sands_thunder_fortress_wall",new Block(AbstractBlock.Settings.copy(Blocks.POLISHED_DEEPSLATE).strength(5.5f,25f))));
  FLOOR.put(SunkenSandsStructureKind.SANDSTORM_FORTRESS,reg("sunken_sands_thunder_fortress_floor",new Block(AbstractBlock.Settings.copy(Blocks.DEEPSLATE_TILES).strength(4.5f,20f))));
  RELIC.put(SunkenSandsStructureKind.SANDSTORM_FORTRESS,reg("sunken_sands_thunder_fortress_relic",new Block(AbstractBlock.Settings.copy(Blocks.AMETHYST_BLOCK).strength(3.5f,18f).luminance(s->9))));
  WALL.put(SunkenSandsStructureKind.SUN_TEMPLE,reg("sunken_sands_tempest_monastery_wall",new Block(AbstractBlock.Settings.copy(Blocks.POLISHED_DEEPSLATE).strength(5.5f,25f))));
  FLOOR.put(SunkenSandsStructureKind.SUN_TEMPLE,reg("sunken_sands_tempest_monastery_floor",new Block(AbstractBlock.Settings.copy(Blocks.DEEPSLATE_TILES).strength(4.5f,20f))));
  RELIC.put(SunkenSandsStructureKind.SUN_TEMPLE,reg("sunken_sands_tempest_monastery_relic",new Block(AbstractBlock.Settings.copy(Blocks.AMETHYST_BLOCK).strength(3.5f,18f).luminance(s->9))));
  WALL.put(SunkenSandsStructureKind.FLOODED_TEMPLE,reg("sunken_sands_cloud_temple_wall",new Block(AbstractBlock.Settings.copy(Blocks.POLISHED_DEEPSLATE).strength(5.5f,25f))));
  FLOOR.put(SunkenSandsStructureKind.FLOODED_TEMPLE,reg("sunken_sands_cloud_temple_floor",new Block(AbstractBlock.Settings.copy(Blocks.DEEPSLATE_TILES).strength(4.5f,20f))));
  RELIC.put(SunkenSandsStructureKind.FLOODED_TEMPLE,reg("sunken_sands_cloud_temple_relic",new Block(AbstractBlock.Settings.copy(Blocks.AMETHYST_BLOCK).strength(3.5f,18f).luminance(s->9))));
  WALL.put(SunkenSandsStructureKind.OBSIDIAN_CITADEL,reg("sunken_sands_storm_citadel_wall",new Block(AbstractBlock.Settings.copy(Blocks.POLISHED_DEEPSLATE).strength(5.5f,25f))));
  FLOOR.put(SunkenSandsStructureKind.OBSIDIAN_CITADEL,reg("sunken_sands_storm_citadel_floor",new Block(AbstractBlock.Settings.copy(Blocks.DEEPSLATE_TILES).strength(4.5f,20f))));
  RELIC.put(SunkenSandsStructureKind.OBSIDIAN_CITADEL,reg("sunken_sands_storm_citadel_relic",new Block(AbstractBlock.Settings.copy(Blocks.AMETHYST_BLOCK).strength(3.5f,18f).luminance(s->9))));
  WALL.put(SunkenSandsStructureKind.CANYON_KEEP,reg("sunken_sands_canyon_keep_wall",new Block(AbstractBlock.Settings.copy(Blocks.POLISHED_DEEPSLATE).strength(5.5f,25f))));
  FLOOR.put(SunkenSandsStructureKind.CANYON_KEEP,reg("sunken_sands_canyon_keep_floor",new Block(AbstractBlock.Settings.copy(Blocks.DEEPSLATE_TILES).strength(4.5f,20f))));
  RELIC.put(SunkenSandsStructureKind.CANYON_KEEP,reg("sunken_sands_canyon_keep_relic",new Block(AbstractBlock.Settings.copy(Blocks.AMETHYST_BLOCK).strength(3.5f,18f).luminance(s->9))));
  WALL.put(SunkenSandsStructureKind.OASIS_SHRINE,reg("sunken_sands_marsh_shrine_wall",new Block(AbstractBlock.Settings.copy(Blocks.POLISHED_DEEPSLATE).strength(5.5f,25f))));
  FLOOR.put(SunkenSandsStructureKind.OASIS_SHRINE,reg("sunken_sands_marsh_shrine_floor",new Block(AbstractBlock.Settings.copy(Blocks.DEEPSLATE_TILES).strength(4.5f,20f))));
  RELIC.put(SunkenSandsStructureKind.OASIS_SHRINE,reg("sunken_sands_marsh_shrine_relic",new Block(AbstractBlock.Settings.copy(Blocks.AMETHYST_BLOCK).strength(3.5f,18f).luminance(s->9))));
  WALL.put(SunkenSandsStructureKind.MOON_OBSERVATORY,reg("sunken_sands_astral_observatory_wall",new Block(AbstractBlock.Settings.copy(Blocks.POLISHED_DEEPSLATE).strength(5.5f,25f))));
  FLOOR.put(SunkenSandsStructureKind.MOON_OBSERVATORY,reg("sunken_sands_astral_observatory_floor",new Block(AbstractBlock.Settings.copy(Blocks.DEEPSLATE_TILES).strength(4.5f,20f))));
  RELIC.put(SunkenSandsStructureKind.MOON_OBSERVATORY,reg("sunken_sands_astral_observatory_relic",new Block(AbstractBlock.Settings.copy(Blocks.AMETHYST_BLOCK).strength(3.5f,18f).luminance(s->9))));
  WALL.put(SunkenSandsStructureKind.GRAVE_PYRAMID,reg("sunken_sands_sky_grave_temple_wall",new Block(AbstractBlock.Settings.copy(Blocks.POLISHED_DEEPSLATE).strength(5.5f,25f))));
  FLOOR.put(SunkenSandsStructureKind.GRAVE_PYRAMID,reg("sunken_sands_sky_grave_temple_floor",new Block(AbstractBlock.Settings.copy(Blocks.DEEPSLATE_TILES).strength(4.5f,20f))));
  RELIC.put(SunkenSandsStructureKind.GRAVE_PYRAMID,reg("sunken_sands_sky_grave_temple_relic",new Block(AbstractBlock.Settings.copy(Blocks.AMETHYST_BLOCK).strength(3.5f,18f).luminance(s->9))));
  WALL.put(SunkenSandsStructureKind.SUN_GOD_SANCTUM,reg("sunken_sands_stormheart_sanctum_wall",new Block(AbstractBlock.Settings.copy(Blocks.POLISHED_DEEPSLATE).strength(5.5f,25f))));
  FLOOR.put(SunkenSandsStructureKind.SUN_GOD_SANCTUM,reg("sunken_sands_stormheart_sanctum_floor",new Block(AbstractBlock.Settings.copy(Blocks.DEEPSLATE_TILES).strength(4.5f,20f))));
  RELIC.put(SunkenSandsStructureKind.SUN_GOD_SANCTUM,reg("sunken_sands_stormheart_sanctum_relic",new Block(AbstractBlock.Settings.copy(Blocks.AMETHYST_BLOCK).strength(3.5f,18f).luminance(s->9))));
  WALL.put(SunkenSandsStructureKind.SUN_KING_PALACE,reg("sunken_sands_crown_palace_wall",new Block(AbstractBlock.Settings.copy(Blocks.POLISHED_DEEPSLATE).strength(5.5f,25f))));
  FLOOR.put(SunkenSandsStructureKind.SUN_KING_PALACE,reg("sunken_sands_crown_palace_floor",new Block(AbstractBlock.Settings.copy(Blocks.DEEPSLATE_TILES).strength(4.5f,20f))));
  RELIC.put(SunkenSandsStructureKind.SUN_KING_PALACE,reg("sunken_sands_crown_palace_relic",new Block(AbstractBlock.Settings.copy(Blocks.AMETHYST_BLOCK).strength(3.5f,18f).luminance(s->9))));
  WALL.put(SunkenSandsStructureKind.SINKHOLE_FORTRESS,reg("sunken_sands_eye_fortress_wall",new Block(AbstractBlock.Settings.copy(Blocks.POLISHED_DEEPSLATE).strength(5.5f,25f))));
  FLOOR.put(SunkenSandsStructureKind.SINKHOLE_FORTRESS,reg("sunken_sands_eye_fortress_floor",new Block(AbstractBlock.Settings.copy(Blocks.DEEPSLATE_TILES).strength(4.5f,20f))));
  RELIC.put(SunkenSandsStructureKind.SINKHOLE_FORTRESS,reg("sunken_sands_eye_fortress_relic",new Block(AbstractBlock.Settings.copy(Blocks.AMETHYST_BLOCK).strength(3.5f,18f).luminance(s->9))));
 }
 public static void register(){for(SunkenSandsStructureKind k:SunkenSandsStructureKind.values()){item(k.id+"_wall",WALL.get(k));item(k.id+"_floor",FLOOR.get(k));item(k.id+"_relic",RELIC.get(k));}}
 private static void item(String id,Block b){Registry.register(Registries.ITEM,Identifier.of(OverworldPlus.MOD_ID,id),new BlockItem(b,new net.minecraft.item.Item.Settings()));}
 private SunkenSandsStructureBlocks(){}
}