# Dimensional Nexus — v0.28.0

The Dimensional Nexus is a persistent fast-travel hub for dimensions the player has actually visited.

- 20 supported dimensions, including the Overworld.
- Visiting a dimension automatically marks it as discovered on the player.
- Right-click: next discovered dimension.
- Sneak + right-click: previous discovered dimension.
- Travel uses the target dimension's spawn position.
- Discovery is stored using persistent player command tags, so it survives relogs/restarts.
- The Nexus never unlocks a dimension merely because it exists: it must be visited first.
- Recipe: Obsidian + Ender Pearls + World Beacon + Beacon.
