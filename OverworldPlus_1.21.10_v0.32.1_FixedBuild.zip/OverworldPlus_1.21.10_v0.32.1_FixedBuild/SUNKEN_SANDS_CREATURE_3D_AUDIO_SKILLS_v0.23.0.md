# Sunken Sands v0.23.0 — 3D Creatures, Audio, Animation & Skills

This pass upgrades the hostile wildlife and encounter roster of Sunken Sands from generic Biped rendering to custom model kits.

## Custom 3D model roster
- 20 biome creatures: unique silhouettes and animation profiles.
- 10 main bosses: unique body/armor/core silhouettes and phase animations.
- 20 biome mini-bosses: custom large encounter models.
- 12 structure guardians: custom structure-themed models.
- 12 structure mini-bosses: custom large models with cores and phase motion.

## Audio
Each creature has its own ambient/hurt/death/attack sound set.
Each main boss has ambient/hurt/death/attack/phase sounds.
Biome mini-bosses and structure encounters have their own encounter sounds.
The sounds are generated placeholder assets with different timbres and durations; they are not hand-recorded voice performances or orchestral music.

## Skills
Every Sunken Sands creature receives an individual active skill selected by its kind. Examples include poison, blindness, charge, leap, darkness, levitation, area damage and mobility effects.
Main bosses already have signature abilities and now expose skill state to the custom animations.
Biome and structure mini-bosses receive individual active abilities and phase behavior.

## Animation
Models react to:
- walking/running
- head look
- idle motion
- species-specific body motion
- phase transitions
- active skill wind-up
- boss cores and extra geometry

## Important limitation
The models are implemented directly with Minecraft `ModelPart` geometry and generated textures; no GeckoLib dependency was introduced. For truly hand-authored AAA rigs, keyframed animation packs and professional sound design, authored assets would still be required.
