from pathlib import Path
import json, os, textwrap
root=Path('/tmp/owp14')
java=root/'src/main/java/com/overworldplus/stormreach'
client=java/'client'

# 12 distinct structure families, each tied to a biome cluster.
rows=[
('SKY_CITADEL','sky_citadel','Sky Citadel','stormbound_plains','stormbound_plains,thundersteppe,skyreach_isles,floating_kingdoms'),
('THUNDER_FORTRESS','thunder_fortress','Thunder Fortress','thundersteppe','thundersteppe,stormforged_mountains,eternal_tempest'),
('TEMPEST_MONASTERY','tempest_monastery','Tempest Monastery','tempest_highlands','tempest_highlands,celestial_peaks,storm_crown'),
('CLOUD_TEMPLE','cloud_temple','Cloud Temple','cloudsea','cloudsea,azure_expanse,astral_coast'),
('STORM_CITADEL','storm_citadel','Storm Citadel','lightning_forest','lightning_forest,tempest_jungle,thunderfall_valley'),
('CANYON_KEEP','canyon_keep','Canyon Keep','stormscar_canyon','stormscar_canyon,thunderfall_valley'),
('MARSH_SHRINE','marsh_shrine','Marsh Shrine','thunder_marshes','thunder_marshes,azure_expanse'),
('ASTRAL_OBSERVATORY','astral_observatory','Astral Observatory','astral_coast','astral_coast,skygrave,celestial_peaks'),
('SKY_GRAVE_TEMPLE','sky_grave_temple','Sky Grave Temple','skygrave','skygrave,eternal_tempest'),
('STORMHEART_SANCTUM','stormheart_sanctum','Stormheart Sanctum','stormheart_basin','stormheart_basin,eye_of_the_storm'),
('CROWN_PALACE','crown_palace','Crown Palace','storm_crown','storm_crown,floating_kingdoms'),
('EYE_FORTRESS','eye_fortress','Eye Fortress','eye_of_the_storm','eye_of_the_storm,eternal_tempest'),
]

kind_java='''package com.overworldplus.stormreach;\n\npublic enum StormreachStructureKind {\n%s\n; public final String id,name,anchorBiome; public final String[] biomes;\n StormreachStructureKind(String id,String name,String anchorBiome,String biomes){this.id=id;this.name=name;this.anchorBiome=anchorBiome;this.biomes=biomes.split(",");}\n public boolean matches(String biome){for(String b:biomes) if(b.equals(biome)) return true; return false;}\n public static StormreachStructureKind forBiome(String biome){for(StormreachStructureKind k:values()) if(k.matches(biome)) return k; return STORM_CITADEL;}\n}\n''' % ',\n'.join(f' {a}("{b}","{c}","{d}","{e}")' for a,b,c,d,e in rows)
(java/'StormreachStructureKind.java').write_text(kind_java)

# Structure blocks: 3 unique blocks per structure.
lines=['package com.overworldplus.stormreach;','import com.overworldplus.OverworldPlus;','import net.minecraft.block.*; import net.minecraft.item.BlockItem; import net.minecraft.registry.*; import net.minecraft.util.Identifier; import java.util.*;','public final class StormreachStructureBlocks {',' public static final Map<StormreachStructureKind,Block> WALL=new EnumMap<>(StormreachStructureKind.class);',' public static final Map<StormreachStructureKind,Block> FLOOR=new EnumMap<>(StormreachStructureKind.class);',' public static final Map<StormreachStructureKind,Block> RELIC=new EnumMap<>(StormreachStructureKind.class);',' private static Block reg(String id, Block b){return Registry.register(Registries.BLOCK,Identifier.of(OverworldPlus.MOD_ID,id),b);}',' static {']
for a,b,c,d,e in rows:
    lines += [f'  WALL.put(StormreachStructureKind.{a},reg("{b}_wall",new Block(AbstractBlock.Settings.copy(Blocks.POLISHED_DEEPSLATE).strength(5.5f,25f))));',
              f'  FLOOR.put(StormreachStructureKind.{a},reg("{b}_floor",new Block(AbstractBlock.Settings.copy(Blocks.DEEPSLATE_TILES).strength(4.5f,20f))));',
              f'  RELIC.put(StormreachStructureKind.{a},reg("{b}_relic",new Block(AbstractBlock.Settings.copy(Blocks.AMETHYST_BLOCK).strength(3.5f,18f).luminance(s->9))));']
lines += [' }',' public static void register(){for(StormreachStructureKind k:StormreachStructureKind.values()){item(k.id+"_wall",WALL.get(k));item(k.id+"_floor",FLOOR.get(k));item(k.id+"_relic",RELIC.get(k));}}',' private static void item(String id,Block b){Registry.register(Registries.ITEM,Identifier.of(OverworldPlus.MOD_ID,id),new BlockItem(b,new net.minecraft.item.Item.Settings()));}',' private StormreachStructureBlocks(){}','}']
(java/'StormreachStructureBlocks.java').write_text('\n'.join(lines))

# Structure monster
monster='''package com.overworldplus.stormreach;\nimport net.minecraft.entity.*; import net.minecraft.entity.ai.goal.*; import net.minecraft.entity.attribute.*; import net.minecraft.entity.mob.HostileEntity; import net.minecraft.entity.player.PlayerEntity; import net.minecraft.entity.effect.*; import net.minecraft.nbt.NbtCompound; import net.minecraft.text.Text; import net.minecraft.world.World;\npublic class StormreachStructureMobEntity extends HostileEntity { private StormreachStructureKind kind; public StormreachStructureMobEntity(EntityType<? extends StormreachStructureMobEntity> t,World w,StormreachStructureKind k){super(t,w);kind=k;setPersistent();experiencePoints=45;} public StormreachStructureKind getKind(){return kind;} public static DefaultAttributeContainer.Builder attributes(){return HostileEntity.createHostileAttributes().add(EntityAttributes.MAX_HEALTH,72).add(EntityAttributes.ATTACK_DAMAGE,11).add(EntityAttributes.ARMOR,6).add(EntityAttributes.MOVEMENT_SPEED,.31).add(EntityAttributes.FOLLOW_RANGE,36);} @Override protected void initGoals(){goalSelector.add(2,new MeleeAttackGoal(this,1.2,true));goalSelector.add(7,new LookAtEntityGoal(this,PlayerEntity.class,20));targetSelector.add(1,new ActiveTargetGoal<>(this,PlayerEntity.class,true));} @Override public Text getDisplayName(){return Text.literal(kind.name+" Guardian");} @Override protected void mobTick(){super.mobTick(); if(!getWorld().isClient && getTarget()!=null && age%80==0){getTarget().addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS,35,0));}} @Override public void writeCustomDataToNbt(NbtCompound n){super.writeCustomDataToNbt(n);n.putString("StructureKind",kind.id);} }\n'''
(java/'StormreachStructureMobEntity.java').write_text(monster)

boss='''package com.overworldplus.stormreach;\nimport net.minecraft.entity.*; import net.minecraft.entity.ai.goal.*; import net.minecraft.entity.attribute.*; import net.minecraft.entity.mob.HostileEntity; import net.minecraft.entity.player.PlayerEntity; import net.minecraft.entity.effect.*; import net.minecraft.nbt.NbtCompound; import net.minecraft.server.world.ServerWorld; import net.minecraft.text.Text; import net.minecraft.world.World; import net.minecraft.particle.ParticleTypes;\npublic class StormreachStructureMiniBossEntity extends HostileEntity { private StormreachStructureKind kind; private int phase=1; public StormreachStructureMiniBossEntity(EntityType<? extends StormreachStructureMiniBossEntity> t,World w,StormreachStructureKind k){super(t,w);kind=k;setPersistent();experiencePoints=180;} public StormreachStructureKind getKind(){return kind;} public static DefaultAttributeContainer.Builder attributes(){return HostileEntity.createHostileAttributes().add(EntityAttributes.MAX_HEALTH,420).add(EntityAttributes.ATTACK_DAMAGE,20).add(EntityAttributes.ARMOR,12).add(EntityAttributes.ARMOR_TOUGHNESS,5).add(EntityAttributes.KNOCKBACK_RESISTANCE,.55).add(EntityAttributes.MOVEMENT_SPEED,.34).add(EntityAttributes.FOLLOW_RANGE,48);} @Override protected void initGoals(){goalSelector.add(2,new MeleeAttackGoal(this,1.25,true));goalSelector.add(7,new LookAtEntityGoal(this,PlayerEntity.class,24));targetSelector.add(1,new ActiveTargetGoal<>(this,PlayerEntity.class,true));} @Override public Text getDisplayName(){return Text.literal(kind.name+" Warden");} @Override public void tick(){super.tick();if(!getWorld().isClient){if(getHealth()<getMaxHealth()*.55 && phase==1){phase=2;getAttributeInstance(EntityAttributes.ATTACK_DAMAGE).setBaseValue(27);getAttributeInstance(EntityAttributes.MOVEMENT_SPEED).setBaseValue(.40);}if(getTarget()!=null&&age%50==0){getTarget().addStatusEffect(new StatusEffectInstance(StatusEffects.WEAKNESS,50,0));getTarget().addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS,35,1));}if(age%30==0&&getWorld() instanceof ServerWorld sw)sw.spawnParticles(ParticleTypes.ELECTRIC_SPARK,getX(),getY()+1,getZ(),18,1.2,.8,1.2,.08);}} @Override public void writeCustomDataToNbt(NbtCompound n){super.writeCustomDataToNbt(n);n.putString("StructureKind",kind.id);n.putInt("Phase",phase);} }\n'''
(java/'StormreachStructureMiniBossEntity.java').write_text(boss)

# Add registrations to OverworldPlus
op=root/'src/main/java/com/overworldplus/OverworldPlus.java'
s=op.read_text()
s=s.replace('public static EntityType<StormreachNPCEntity> STORMREACH_NPC;','public static EntityType<StormreachNPCEntity> STORMREACH_NPC;\n    public static final Map<StormreachStructureKind, EntityType<StormreachStructureMobEntity>> STORMREACH_STRUCTURE_MOBS = new EnumMap<>(StormreachStructureKind.class);\n    public static final Map<StormreachStructureKind, EntityType<StormreachStructureMiniBossEntity>> STORMREACH_STRUCTURE_MINI_BOSSES = new EnumMap<>(StormreachStructureKind.class);')
needle='        Identifier stormNpcId=Identifier.of(MOD_ID,"stormreach_npc");'
insert='''        for (StormreachStructureKind kind : StormreachStructureKind.values()) {\n            Identifier mobId=Identifier.of(MOD_ID,"stormreach_structure_mob_"+kind.id);\n            EntityType<StormreachStructureMobEntity> mob=Registry.register(Registries.ENTITY_TYPE,mobId,EntityType.Builder.create((type,world)->new StormreachStructureMobEntity(type,world,kind),SpawnGroup.MONSTER).dimensions(1.0f,2.0f).maxTrackingRange(96).trackingTickInterval(1).build(RegistryKey.of(RegistryKeys.ENTITY_TYPE,mobId)));\n            STORMREACH_STRUCTURE_MOBS.put(kind,mob);\n            Identifier bossId=Identifier.of(MOD_ID,"stormreach_structure_miniboss_"+kind.id);\n            EntityType<StormreachStructureMiniBossEntity> boss=Registry.register(Registries.ENTITY_TYPE,bossId,EntityType.Builder.create((type,world)->new StormreachStructureMiniBossEntity(type,world,kind),SpawnGroup.MONSTER).dimensions(1.8f,3.2f).maxTrackingRange(128).trackingTickInterval(1).build(RegistryKey.of(RegistryKeys.ENTITY_TYPE,bossId)));\n            STORMREACH_STRUCTURE_MINI_BOSSES.put(kind,boss);\n        }\n'''
s=s.replace(needle,insert+needle)
s=s.replace('StormreachBlocks.register();','StormreachBlocks.register();\n        StormreachStructureBlocks.register();')
s=s.replace('FabricDefaultAttributeRegistry.register(STORMREACH_NPC, StormreachNPCEntity.attributes());','FabricDefaultAttributeRegistry.register(STORMREACH_NPC, StormreachNPCEntity.attributes());\n        for (EntityType<StormreachStructureMobEntity> type : STORMREACH_STRUCTURE_MOBS.values()) FabricDefaultAttributeRegistry.register(type, StormreachStructureMobEntity.attributes());\n        for (EntityType<StormreachStructureMiniBossEntity> type : STORMREACH_STRUCTURE_MINI_BOSSES.values()) FabricDefaultAttributeRegistry.register(type, StormreachStructureMiniBossEntity.attributes());')
op.write_text(s)

# client render registrations
cp=root/'src/main/java/com/overworldplus/client/OverworldPlusClient.java'
s=cp.read_text()
s=s.replace('EntityRendererRegistry.register(OverworldPlus.STORMREACH_NPC, StormreachNPCRenderer::new);','EntityRendererRegistry.register(OverworldPlus.STORMREACH_NPC, StormreachNPCRenderer::new);\n        for (StormreachStructureKind kind : StormreachStructureKind.values()) EntityRendererRegistry.register(OverworldPlus.STORMREACH_STRUCTURE_MOBS.get(kind), ctx -> new StormreachStructureRenderer(ctx, new BipedEntityModel<>(ctx.getPart(EntityModelLayers.ZOMBIE))));\n        for (StormreachStructureKind kind : StormreachStructureKind.values()) EntityRendererRegistry.register(OverworldPlus.STORMREACH_STRUCTURE_MINI_BOSSES.get(kind), ctx -> new StormreachStructureMiniBossRenderer(ctx, new BipedEntityModel<>(ctx.getPart(EntityModelLayers.ZOMBIE))));')
cp.write_text(s)

(java/'client/StormreachStructureRenderer.java').write_text('''package com.overworldplus.stormreach.client; import com.overworldplus.OverworldPlus; import com.overworldplus.stormreach.*; import net.minecraft.client.render.entity.*; import net.minecraft.client.render.entity.model.BipedEntityModel; import net.minecraft.util.Identifier; public class StormreachStructureRenderer extends MobEntityRenderer<StormreachStructureMobEntity,BipedEntityModel<StormreachStructureMobEntity>>{public StormreachStructureRenderer(EntityRendererFactory.Context c,BipedEntityModel<StormreachStructureMobEntity> m){super(c,m,.55f);} @Override public Identifier getTexture(StormreachStructureMobEntity e){return Identifier.of(OverworldPlus.MOD_ID,"textures/entity/stormreach/structure_mob_"+e.getKind().id+".png");}}''')
(java/'client/StormreachStructureMiniBossRenderer.java').write_text('''package com.overworldplus.stormreach.client; import com.overworldplus.OverworldPlus; import com.overworldplus.stormreach.*; import net.minecraft.client.render.entity.*; import net.minecraft.client.render.entity.model.BipedEntityModel; import net.minecraft.client.util.math.MatrixStack; import net.minecraft.util.Identifier; public class StormreachStructureMiniBossRenderer extends MobEntityRenderer<StormreachStructureMiniBossEntity,BipedEntityModel<StormreachStructureMiniBossEntity>>{public StormreachStructureMiniBossRenderer(EntityRendererFactory.Context c,BipedEntityModel<StormreachStructureMiniBossEntity> m){super(c,m,.8f);} @Override public Identifier getTexture(StormreachStructureMiniBossEntity e){return Identifier.of(OverworldPlus.MOD_ID,"textures/entity/stormreach/structure_boss_"+e.getKind().id+".png");} @Override protected void scale(StormreachStructureMiniBossEntity e,MatrixStack m,float d){m.scale(1.65f,1.65f,1.65f);}}''')

# Replace structure method and add helpers in world systems.
wp=java/'StormreachWorldSystems.java'
s=wp.read_text()
old='private static void structure(ServerWorld w,BlockPos p,String b,long h){Block stone=StormreachBlocks.BIOME_STONE.get(b),core=StormreachBlocks.DUNGEON_CORE.get(b);int r=8+(int)Math.floorMod(h,9);for(int x=-r;x<=r;x++)for(int z=-r;z<=r;z++)if(Math.abs(x)==r||Math.abs(z)==r)w.setBlockState(p.add(x,0,z),stone.getDefaultState());for(int y=1;y<9+(h&7);y++){w.setBlockState(p.up(y),core.getDefaultState());if(y%2==0){w.setBlockState(p.add(5,y,5),stone.getDefaultState());w.setBlockState(p.add(-5,y,-5),stone.getDefaultState());}}w.setBlockState(p.up(9),StormreachBlocks.BIOME_CRYSTAL.get(b).getDefaultState());}'
new='''private static void structure(ServerWorld w,BlockPos p,String b,long h){\n  StormreachStructureKind sk=StormreachStructureKind.forBiome(b);\n  Block wall=StormreachStructureBlocks.WALL.get(sk), floor=StormreachStructureBlocks.FLOOR.get(sk), relic=StormreachStructureBlocks.RELIC.get(sk);\n  int r=10+(int)Math.floorMod(h,9), height=7+(int)Math.floorMod(h>>8,6);\n  for(int x=-r;x<=r;x++)for(int z=-r;z<=r;z++){boolean edge=Math.abs(x)==r||Math.abs(z)==r; if(edge)for(int y=0;y<=height;y++)w.setBlockState(p.add(x,y,z),wall.getDefaultState()); else w.setBlockState(p.add(x,0,z),floor.getDefaultState());}\n  for(int y=1;y<height;y+=2){for(int x=-r+2;x<=r-2;x+=4){w.setBlockState(p.add(x,y,-r+1),relic.getDefaultState());w.setBlockState(p.add(x,y,r-1),relic.getDefaultState());}for(int z=-r+2;z<=r-2;z+=4){w.setBlockState(p.add(-r+1,y,z),relic.getDefaultState());w.setBlockState(p.add(r-1,y,z),relic.getDefaultState());}}\n  for(int x=-2;x<=2;x++)for(int z=-2;z<=2;z++)w.setBlockState(p.add(x,height,z),relic.getDefaultState());\n  // Four guards + one stronger warden; every structure therefore has its own enemy family.\n  for(int i=0;i<4;i++){BlockPos q=p.add((i%2==0?-r+3:r-3),1,(i<2?-r+3:r-3));spawnStructureMob(w,q,sk);}\n  spawnStructureMiniBoss(w,p.up(1),sk);\n}'''
if old not in s: print('old structure not found')
s=s.replace(old,new)
anchor=' private static void spawnMob(ServerWorld w,BlockPos p,String b,long h){'
helpers=''' private static void spawnStructureMob(ServerWorld w,BlockPos p,StormreachStructureKind k){EntityType<StormreachStructureMobEntity> t=OverworldPlus.STORMREACH_STRUCTURE_MOBS.get(k);if(t==null)return;StormreachStructureMobEntity e=new StormreachStructureMobEntity(t,w,k);e.refreshPositionAndAngles(p.getX()+.5,p.getY()+1,p.getZ()+.5,0,0);w.spawnEntity(e);}\n private static void spawnStructureMiniBoss(ServerWorld w,BlockPos p,StormreachStructureKind k){EntityType<StormreachStructureMiniBossEntity> t=OverworldPlus.STORMREACH_STRUCTURE_MINI_BOSSES.get(k);if(t==null)return;StormreachStructureMiniBossEntity e=new StormreachStructureMiniBossEntity(t,w,k);e.refreshPositionAndAngles(p.getX()+.5,p.getY()+1,p.getZ()+.5,0,0);w.spawnEntity(e);}\n'''
s=s.replace(anchor,helpers+anchor)
wp.write_text(s)

# generate assets for 36 structure blocks + 24 entity textures using simple procedural pixel art
assets=root/'src/main/resources/assets/overworldplus'
for d in ['blockstates','models/block','models/item','textures/block','textures/item','textures/entity/stormreach']:
    (assets/d).mkdir(parents=True,exist_ok=True)
from PIL import Image, ImageDraw

def tex(path,base,accent):
    im=Image.new('RGBA',(16,16),base); dr=ImageDraw.Draw(im)
    for i in range(0,16,4):
        dr.rectangle((i,(i*3)%16,min(i+2,15),min((i*3)%16+2,15)),fill=accent)
    im.save(path)
for idx,(a,b,c,d,e) in enumerate(rows):
    for typ,base,accent in [('wall',(38+idx*7%80,45+idx*5%90,58+idx*3%100,255),(120,190,255,255)),('floor',(50+idx*6%100,45+idx*4%90,42+idx*2%80,255),(200,160,80,255)),('relic',(30+idx*8%70,50+idx*4%100,90+idx*5%120,255),(80,240,255,255))]:
        bid=f'{b}_{typ}'; tex(assets/'textures/block'/f'{bid}.png',base,accent)
        (assets/'blockstates'/f'{bid}.json').write_text(json.dumps({'variants':{'':{'model':f'overworldplus:block/{bid}'}}},indent=2))
        (assets/'models/block'/f'{bid}.json').write_text(json.dumps({'parent':'minecraft:block/cube_all','textures':{'all':f'overworldplus:block/{bid}'}},indent=2))
        (assets/'models/item'/f'{bid}.json').write_text(json.dumps({'parent':f'overworldplus:block/{bid}'},indent=2))
    tex(assets/'textures/entity/stormreach'/f'structure_mob_{b}.png',(50+idx*9%120,60+idx*7%120,70+idx*5%120,255),(220,230,255,255))
    tex(assets/'textures/entity/stormreach'/f'structure_boss_{b}.png',(80+idx*7%120,30+idx*5%80,40+idx*6%100,255),(255,210,80,255))

# docs
(root/'STORMREACH_STRUCTURE_SYSTEM_v0.15.0.md').write_text('''# Stormreach Structure System v0.15.0\n\n12 structure families. Each family has 3 exclusive blocks (wall/floor/relic), a dedicated guardian mob, and a dedicated stronger mini-boss/warden. Structures are selected by biome and generated from the world seed.\n\nStructure families: Sky Citadel, Thunder Fortress, Tempest Monastery, Cloud Temple, Storm Citadel, Canyon Keep, Marsh Shrine, Astral Observatory, Sky Grave Temple, Stormheart Sanctum, Crown Palace, Eye Fortress.\n\nMini-bosses are intentionally stronger than ordinary structure mobs (420 HP, 20 attack, 12 armor, 5 toughness) and gain a second phase below 55% HP.\n''')
