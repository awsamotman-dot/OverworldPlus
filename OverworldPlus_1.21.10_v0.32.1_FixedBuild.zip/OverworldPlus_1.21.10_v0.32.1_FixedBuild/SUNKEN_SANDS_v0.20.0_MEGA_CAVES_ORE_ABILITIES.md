# Sunken Sands v0.20.0 — Mega Caves + Ore & Ability System

## Major changes
- Deterministic procedural mega-cave networks driven by world seed.
- Multiple connected cave branches per chunk, large chambers, rare colossal chambers, underground water pockets and biome-specific cave decoration.
- Ore generation rewritten to place deterministic clusters into stone/deepslate/sandstone hosts instead of only replacing air.
- Eight new Sunken Sands progression ores: Sandsteel, Sun Crystal, Scorpite, Duneite, Moon Crystal, Serpentium, Pharaohite, Sunken Core.
- Each new ore has an ingot, sword, pickaxe, axe, shovel, hoe and four armor pieces.
- Armor sets provide different passive bonuses.
- Ten ability items can be crafted from progression materials and Echo Shards/Gold Nuggets.
- Sneak while holding an ability item to activate its effect through the server tick system.
- Main-boss site generation is now actually invoked during chunk population, preserving deterministic seed-based placement.

## Cave philosophy
The caves are not a fixed list of rooms. Their shape, branches, chamber sizes, depth, and rare mega-chambers are derived from the world seed, so two seeds produce different underground networks while the same seed remains deterministic.

## Progression
Sandsteel -> Sun Crystal / Scorpite / Duneite / Moon Crystal / Serpentium -> Pharaohite -> Sunken Core.

The existing Sunken Sands boss relics and boss weapons remain available and can be combined with the new progression system in future balancing passes.

## Verification
- JSON validation: 0 invalid files.
- Java brace scan: 0 mismatched files.
- Full Minecraft/Fabric runtime build was not available in the current environment because Gradle/Minecraft dependencies are not installed.
