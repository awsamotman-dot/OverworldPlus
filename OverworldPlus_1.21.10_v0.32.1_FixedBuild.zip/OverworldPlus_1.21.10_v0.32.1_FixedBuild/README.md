# Overworld Plus v0.27.0

A large-scale Fabric 1.21.10 adventure project with 20 dimensions, custom biome families, procedural structures, caves, ores, settlements, creatures, animals, bosses, escalating gates and a new RPG systems layer.

### New in v0.27.0
- 6 player builds
- 4 factions and reputation memory
- living-world events and invasions
- randomized branching dungeons
- larger cities and named residents
- terrain sculpting and grouped ecosystems
- lore discovery
- World Beacon bases
- boss consequences and mythic loot
- New Game+ / Nightmare progression

See `ALL_NEW_SYSTEMS_v0.27.0.md` for details.
