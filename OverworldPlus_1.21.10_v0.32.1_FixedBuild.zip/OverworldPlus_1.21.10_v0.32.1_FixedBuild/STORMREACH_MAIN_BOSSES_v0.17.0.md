# Stormreach Main Boss System v0.17.0

Implemented the 10 Stormreach main bosses with five health phases, boss-specific signature abilities, passive phase effects, arena construction, unique relic drops, unique boss weapons, boss bar persistence, and Heart of Stormreach gate reward.

Bosses: Thunder King, Sky Serpent, Storm Titan, Cloud Empress, Tempest Warlord, Lightning Dragon, Astral Stormcaller, Eye Guardian, Forgotten Sky King, Heart of Stormreach.

Each boss is spawned from Stormreach dungeon generation and receives a themed arena profile based on its identity. Loot includes a material bundle, Stormblade, unique relic and unique boss weapon. Heart of Stormreach additionally drops the Stormheart Sigil used for progression.

Note: the current project environment cannot perform a real Fabric/Gradle build because Gradle/dependencies are unavailable; static JSON/brace checks are performed instead.
