# v0.17.0 Boss Audit

- 10 main boss types retained and enhanced.
- 5 health phases per boss.
- Unique signature ability switch for every boss.
- Passive phase effects for every boss.
- Themed boss arena generation.
- Unique relic and weapon drops.
- Heart of Stormreach grants Stormheart Sigil.
- Boss bar state and phase/cooldown persisted in NBT.
- Boss renderer scaling differentiated by boss identity.
