# Overworld Plus v0.29.0 — Universal RPG UI

The mod now includes an English-first RPG interface inspired by the usability of popular Bedrock adventure mods, with original Overworld Plus styling and systems.

## Open the menu
- The RPG menu **opens automatically when you enter a world** — no button press is required.
- Press **O** at any time to reopen it after closing.
- Use the Ancient Codex.
- Use the Dimensional Nexus.

## Tabs
- Worlds — discovered dimensions and fast travel.
- Character — class, faction, health, level and position.
- Codex — lore, boss memories and world memories.
- Progress — adventure completion and New Game+ state.

## Fast travel
The Worlds tab only lists dimensions already discovered by the player. The server validates discovery before teleporting.

## Language
All new UI labels and messages are English so the interface is broadly understandable internationally.

Build note: the environment used to prepare this archive does not contain Gradle/Minecraft dependency caches, so a full Gradle build was not possible here.
