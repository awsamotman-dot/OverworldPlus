# Overworld Plus v0.26.0 — All 20 Dimensions Expansion

This pass upgrades the full 20-dimension roadmap in one package.

## World content
- All 20 dimensions have 20 named biomes in their dimension biome source.
- Each biome has unique biome blocks: stone, soil, trim and crystal.
- Every dimension has 8 exclusive ore blocks and dense ore generation in generated cave/underground pockets.
- Vanilla Overworld noise is retained as the base terrain/cave generator; deterministic chunk dressing adds biome surfaces, cave chambers, dungeons, cities and villages.
- Each biome can receive a biome-themed structure, settlement, dungeon and creatures.
- Villages are real Villager entities inside generated settlements.
- 20 biome creature identities per dimension and 10 boss identities per dimension are driven by a shared 3D renderer/entity system, with per-identity textures and dedicated sound events.
- Bosses have 3 phases and signature skills; creatures have unique skill rolls based on identity.

## Gate progression
- Crystal Abyss -> Deadlands starts the universal gate chain.
- Deadlands through Moonfall use distinct gate conditions (relics plus night/day, altitude, low health, mounted state, sneaking, etc.).
- Voidlands is the final dimension and has no outgoing gate.
- Bosses drop the relic used by their dimension's gate.

## Random exploration
- Biome selection is seed-driven through multi-noise climate sampling.
- Chunk decoration is seed-hashed, so structure/city/dungeon/cave/ore placement changes with the world seed.
- The base Minecraft noise generator remains responsible for large-scale terrain and vanilla cave networks, while the expansion layer adds large themed underground rooms and tunnels.

## Assets
- 1,780 new block/gate IDs are registered for the expansion layer.
- 600 unique creature/boss texture identities are generated, plus animal identities reuse the same biome-specific visual family.
- 1,000 unique creature/boss/animal audio tracks are generated and exposed through 3,600 sound events.
- Dedicated 3D model geometry and animation states are used for the universal creature and boss entities.

## Verification
- JSON parse check: 0 errors.
- Java brace check: 0 errors.
- Full Gradle/Minecraft compilation was not possible in this environment because Gradle/Minecraft dependencies are not installed locally.
