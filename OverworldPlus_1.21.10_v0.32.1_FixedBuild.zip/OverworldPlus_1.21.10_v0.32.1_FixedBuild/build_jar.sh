#!/bin/sh
set -e
./gradlew clean build
printf '\nBuilt JARs:\n'
find build/libs -maxdepth 1 -type f -name '*.jar' -print
