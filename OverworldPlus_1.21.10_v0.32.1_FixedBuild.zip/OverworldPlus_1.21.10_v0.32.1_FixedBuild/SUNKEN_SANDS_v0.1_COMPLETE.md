# Overworld Plus — Sunken Sands v0.1 Complete World Build

World #5: Sunken Sands — الرمال الغارقة

## Included in this all-at-once build
- 20 custom biomes and biome JSON definitions.
- Seed-dependent procedural terrain signatures for dunes, buried kingdoms, canyons, sinkholes, flooded ruins, crystal sands, jungle, black sand and the Sunken Throne.
- 20 biome-specific material families (8 registered blocks per biome) plus legacy world blocks and ores.
- 20 unique creature types, elite variants, 20 biome mini-bosses.
- 12 structure families with unique structure blocks, guards and structure mini-bosses.
- Cities, landmarks, multi-room underground dungeons and cave networks.
- 10 main bosses with seed-dependent deterministic world sites and boss arenas.
- Boss phases, abilities, relics, weapons and endgame sigil.
- Sandstorm-style world events and particles.
- Sunken Sands gate for Stormreach ↔ Sunken Sands travel, with Stormheart Sigil protection on first entry.
- Client renderers and generated placeholder textures/models for all new registered visual assets.

## Main Bosses
1. The Sun King
2. Scorpion Emperor
3. The Sand Serpent
4. Pharaoh of the Lost Kingdom
5. The Dune Tyrant
6. The Buried Lich
7. The Ancient Colossus
8. The Drowned Guardian
9. The Moon Queen
10. The Sunken God

## Important technical note
The project targets Minecraft Java 1.21.10 + Fabric + Java 21. Static source/JSON validation is performed in this environment. A full Gradle/Minecraft runtime build cannot be claimed here because the environment does not contain Gradle/Minecraft/Fabric dependency caches.
