# Overworld Plus — Project Status v0.27.0

## Target
- Minecraft Java 1.21.10
- Fabric Loader 0.17.2
- Fabric API 0.138.4+1.21.10
- Java 21

## Dimensions
All 20 planned dimensions are represented in the project and share the expansion framework for procedural biomes, structures, villages, dungeons, caves, ores, creatures, animals, bosses and escalating gates.

## v0.27.0 New RPG Layer
- Six player classes/builds.
- Four factions with persistent command-tag reputation.
- World discovery memory.
- Ancient Codex lore.
- World Beacon base system.
- Periodic world events and invasions.
- Dynamic/randomized dungeon layouts.
- Expanded cities and resident villagers.
- Grouped animal/creature ecosystems.
- Terrain sculpting on expansion chunks.
- Boss reputation consequences.
- Mythic Core boss loot.
- Class Sigil from Ashen Abyss boss.
- Nightmare Core from Voidlands boss.
- New Game+ toggle.
- Animal renderer registration fixed.

## Verification
- JSON parsing: 0 errors.
- Java brace balance: 0 errors.
- Java source files: 149.
- PNG assets: 5521.
- Full Gradle/Minecraft compilation was not run because Gradle/Minecraft dependencies are unavailable in the execution environment.
