# Stormreach Structure System v0.15.0

12 structure families. Each family has 3 exclusive blocks (wall/floor/relic), a dedicated guardian mob, and a dedicated stronger mini-boss/warden. Structures are selected by biome and generated from the world seed.

Structure families: Sky Citadel, Thunder Fortress, Tempest Monastery, Cloud Temple, Storm Citadel, Canyon Keep, Marsh Shrine, Astral Observatory, Sky Grave Temple, Stormheart Sanctum, Crown Palace, Eye Fortress.

Mini-bosses are intentionally stronger than ordinary structure mobs (420 HP, 20 attack, 12 armor, 5 toughness) and gain a second phase below 55% HP.
