# Crystal Abyss Gate — v0.25.0

## World 7 entry flow
1. Explore Umbral Wilds.
2. Defeat the seven shard-linked bosses to obtain: Wild Shard, Wraith Shard, Crystal Shard, Moon Shard, Blood Shard, Shadow Shard and Crown Shard.
3. A single seed-deterministic Prismatic Deep is generated far from spawn.
4. The Prismatic Deep contains a large crystal/obsidian arena and a 5x5 Abyssal Crystal Gate framed by crystal pillars.
5. Right-clicking the gate with all seven shards triggers The Prismatic Awakening and spawns the Crystal Warden.
6. Crystal Warden has three combat phases, custom 3D renderer, particles, damage/status skills and gate binding persisted in NBT.
7. Killing the Crystal Warden permanently opens the gate frame and triggers a particle burst + gate sound.
8. Right-clicking any open gate block consumes one of each shard (unless creative) and teleports the player to `overworldplus:crystal_abyss` at Y=120.
9. The open gate uses a dedicated visual texture and light level 15.

## Persistence / safety
- Gate activation is stored in block states, not only a static runtime set.
- Crystal Warden stores the gate position in NBT, so death after reload can still unlock the correct gate.
- The Prismatic Deep location is derived from the world seed, giving one deterministic target chunk per seed.

## Validation
- JSON parse check: PASS
- Java brace check: PASS
- Full Gradle/Minecraft compilation: NOT RUNNABLE in this environment because Gradle is not installed.
